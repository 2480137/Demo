# Bitcoin Rate API Test Automation

This is a Maven-based Java project that uses **REST Assured** and **TestNG** to verify the Bitcoin Rate API endpoints from CoinDesk.

## Project Structure

```
BitcoinRateAPITest/
├── pom.xml                          # Maven configuration with all dependencies
├── testng.xml                       # TestNG suite file
├── README.md                        # This file
└── src/
    └── test/
        └── java/
            └── com/
                └── bitcoin/
                    └── tests/
                        ├── BitcoinRateSuccessTest.java   # Scenario 1: Verify 200
                        └── BitcoinRateFailureTest.java   # Scenario 2: Verify 404
```

## Scenarios Covered

### Scenario 1: Verify Success Status Code 200
- **API:** `GET https://api.coindesk.com/v1/bpi/currentprice.json`
- **Expected:** Status code `200`
- **Test Class:** `BitcoinRateSuccessTest`
- Also verifies USD and Non-USD currencies (GBP, EUR) are present in response.

### Scenario 2: Verify Failure Status Code 404
- **API:** `GET https://api.coindesk.com/v1/bpi/currentprice/invalidcurrency.json`
- **Expected:** Status code `404`
- **Test Class:** `BitcoinRateFailureTest`

## Prerequisites

1. **Java JDK 11 or higher** installed
2. **Apache Maven 3.6+** installed
3. Active internet connection (to call the live API)

## Dependencies (already configured in pom.xml)

- TestNG `7.8.0`
- Rest Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1: Run via Maven (command line)

Open a terminal in the project root folder and run:

```bash
mvn clean test
```

This will:
1. Download all dependencies
2. Compile the test classes
3. Execute all tests defined in `testng.xml`

### Option 2: Run from IDE (IntelliJ IDEA / Eclipse)

1. Open the project as a Maven project (`File > Open` and select the `pom.xml`).
2. Wait for Maven to download all dependencies.
3. Right-click on `testng.xml` → **Run 'testng.xml'**
   OR
   Right-click on any test class → **Run As > TestNG Test**

### Option 3: Run a specific test class via Maven

```bash
mvn clean test -Dtest=BitcoinRateSuccessTest
mvn clean test -Dtest=BitcoinRateFailureTest
```

## Expected Output

After running, you should see something similar to:

```
[TEST START] Verifying success status code 200 for Bitcoin Rate API
Request URL    : https://api.coindesk.com/v1/bpi/currentprice.json
Status Code    : 200
[TEST PASSED] Status code 200 verified successfully.

[TEST START] Verifying failure status code 404 for Bitcoin Rate API
Request URL    : https://api.coindesk.com/v1/bpi/currentprice/invalidcurrency.json
Status Code    : 404
[TEST PASSED] Status code 404 verified successfully.

===============================================
Total tests run: 4, Passes: 4, Failures: 0
===============================================
```

## Test Reports

After execution, TestNG reports are generated at:
- `target/surefire-reports/index.html`
- `target/surefire-reports/emailable-report.html`

Open these in a browser to view the results.

## Notes

- The CoinDesk API is **public** and does not require authentication.
- For Scenario 2 (404), the test deliberately hits an invalid endpoint, since a valid URL always returns 200.
- If the CoinDesk API ever becomes unavailable, the tests may fail due to network/server errors.
