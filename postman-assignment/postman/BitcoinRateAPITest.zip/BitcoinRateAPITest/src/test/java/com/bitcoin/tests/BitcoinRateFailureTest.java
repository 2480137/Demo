package com.bitcoin.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Scenario 2: Verify the Failure Status code 404 for the Bitcoin rate
 * against USD and Non-USD currencies.
 *
 * Steps:
 * 1. Create a maven project and import all the necessary dependencies for testng and rest assured
 * 2. Create Test class and test method to execute the scenario
 * 3. Send GET request for the URI through RestAssured:
 *    https://api.coindesk.com/v1/bpi/currentprice.json
 * 4. Verify whether the Status Code 404 displayed by using TestNG assertion.
 *
 * Note: To trigger a 404, an INVALID endpoint is used (the original valid URL would return 200).
 *       This simulates the failure scenario for the same base API.
 */
public class BitcoinRateFailureTest {

    private static final String BASE_URI = "https://api.coindesk.com";
    // Invalid endpoint to trigger 404 Not Found
    private static final String INVALID_ENDPOINT = "/v1/bpi/currentprice/invalidcurrency.json";
    private static final int EXPECTED_STATUS_CODE = 404;

    @BeforeClass
    public void setUp() {
        // Set the base URI for RestAssured
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test Setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Test method to verify Status Code 404 by hitting an invalid endpoint.
     */
    @Test(priority = 1, description = "Verify 404 status code for invalid Bitcoin rate API endpoint")
    public void verifyBitcoinRateStatusCode404() {

        System.out.println("\n[TEST START] Verifying failure status code 404 for Bitcoin Rate API");

        // Step 3: Send GET request to an invalid URI through RestAssured
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                .when()
                    .get(INVALID_ENDPOINT)
                .then()
                    .extract()
                    .response();

        int actualStatusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + INVALID_ENDPOINT);
        System.out.println("Response Time  : " + response.getTime() + " ms");
        System.out.println("Status Code    : " + actualStatusCode);

        // Step 4: Verify Status Code 404 using TestNG Assertion
        Assert.assertEquals(actualStatusCode, EXPECTED_STATUS_CODE,
                "FAILED: Expected status code 404 but got " + actualStatusCode);

        System.out.println("[TEST PASSED] Status code 404 verified successfully.\n");
    }

    /**
     * Additional test - verify 404 with a different invalid path.
     */
    @Test(priority = 2, description = "Verify 404 status for invalid currency path")
    public void verifyInvalidCurrencyPathReturns404() {

        System.out.println("\n[TEST START] Verifying 404 for invalid currency endpoint");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                .when()
                    .get("/v1/bpi/historical/invalidpath.json")
                .then()
                    .extract()
                    .response();

        int actualStatusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + "/v1/bpi/historical/invalidpath.json");
        System.out.println("Status Code    : " + actualStatusCode);

        Assert.assertEquals(actualStatusCode, 404,
                "FAILED: Expected status code 404 but got " + actualStatusCode);

        System.out.println("[TEST PASSED] 404 verified for invalid currency path.\n");
    }
}
