package com.bitcoin.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Scenario 1: Verify the Success Status code 200 for the Bitcoin rate
 * against USD and Non-USD currencies.
 *
 * Steps:
 * 1. Create a maven project and import all the necessary dependencies for testng and rest assured
 * 2. Create Test class and test method to execute the scenario
 * 3. Send GET request for the URI through RestAssured:
 *    https://api.coindesk.com/v1/bpi/currentprice.json
 * 4. Verify whether the Status Code 200 displayed by using TestNG assertion.
 */
public class BitcoinRateSuccessTest {

    private static final String BASE_URI = "https://api.coindesk.com";
    private static final String ENDPOINT = "/v1/bpi/currentprice.json";
    private static final int EXPECTED_STATUS_CODE = 200;

    @BeforeClass
    public void setUp() {
        // Set the base URI for RestAssured
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test Setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Test method to verify Status Code 200 for Bitcoin rate
     * against USD and Non-USD currencies (GBP, EUR are returned by default).
     */
    @Test(priority = 1, description = "Verify 200 status code for Bitcoin rate API")
    public void verifyBitcoinRateStatusCode200() {

        System.out.println("\n[TEST START] Verifying success status code 200 for Bitcoin Rate API");

        // Step 3: Send GET request through RestAssured
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        // Capture status code
        int actualStatusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Response Time  : " + response.getTime() + " ms");
        System.out.println("Status Code    : " + actualStatusCode);
        System.out.println("Response Body  : " + response.getBody().asPrettyString());

        // Step 4: Verify Status Code 200 using TestNG Assertion
        Assert.assertEquals(actualStatusCode, EXPECTED_STATUS_CODE,
                "FAILED: Expected status code 200 but got " + actualStatusCode);

        System.out.println("[TEST PASSED] Status code 200 verified successfully.\n");
    }

    /**
     * Additional test to verify Bitcoin rates contain USD and Non-USD currencies.
     */
    @Test(priority = 2, description = "Verify Bitcoin rates for USD and Non-USD currencies")
    public void verifyUSDAndNonUSDCurrencies() {

        System.out.println("\n[TEST START] Verifying Bitcoin rates for USD and Non-USD currencies");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 200, "Expected status code 200");

        // Verify USD currency exists
        String usdCode = response.jsonPath().getString("bpi.USD.code");
        Assert.assertEquals(usdCode, "USD", "USD currency not found in response");
        System.out.println("USD rate found: " + response.jsonPath().getString("bpi.USD.rate"));

        // Verify Non-USD currencies (GBP, EUR)
        String gbpCode = response.jsonPath().getString("bpi.GBP.code");
        Assert.assertEquals(gbpCode, "GBP", "GBP currency not found in response");
        System.out.println("GBP rate found: " + response.jsonPath().getString("bpi.GBP.rate"));

        String eurCode = response.jsonPath().getString("bpi.EUR.code");
        Assert.assertEquals(eurCode, "EUR", "EUR currency not found in response");
        System.out.println("EUR rate found: " + response.jsonPath().getString("bpi.EUR.rate"));

        System.out.println("[TEST PASSED] USD and Non-USD currencies verified successfully.\n");
    }
}
