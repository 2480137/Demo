# Bitcoin Rate API Test Automation

Maven + Java project using **REST Assured** and **TestNG** to automate test scenarios against the CoinDesk Bitcoin Price Index API.

## Project Structure

```
BitcoinRateAPITest/
├── pom.xml                          # Maven dependencies
├── testng.xml                       # TestNG suite (runs all 5 scenarios)
├── README.md
└── src/test/java/com/bitcoin/tests/
    ├── BitcoinRateSuccessTest.java  # Scenario 1: Verify 200
    ├── BitcoinRateFailureTest.java  # Scenario 2: Verify 404
    ├── BitcoinRateUSDTest.java      # Scenario 3: Print USD rate
    ├── BitcoinRateGBPTest.java      # Scenario 4: Print GBP rate
    └── BitcoinRateEURTest.java      # Scenario 5: Print EUR rate
```

## Scenarios Covered

| # | Scenario                                       | Class                       |
|---|-----------------------------------------------|-----------------------------|
| 1 | Verify 200 status code                        | `BitcoinRateSuccessTest`    |
| 2 | Verify 404 status code (invalid endpoint)     | `BitcoinRateFailureTest`    |
| 3 | Print Bitcoin rate against **USD** currency   | `BitcoinRateUSDTest`        |
| 4 | Print Bitcoin rate against **GBP** currency   | `BitcoinRateGBPTest`        |
| 5 | Print Bitcoin rate against **EUR** currency   | `BitcoinRateEURTest`        |

For Scenarios 3-5, the following fields are printed:
- code, symbol, rate, description, currency rate, rate_float

**API Endpoint:** `GET https://api.coindesk.com/v1/bpi/currentprice.json`

## Prerequisites

- Java JDK 11 or higher
- Apache Maven 3.6+
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- Rest Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### From command line (Maven):

```bash
mvn clean test
```

### Run a specific scenario:

```bash
mvn clean test -Dtest=BitcoinRateUSDTest
mvn clean test -Dtest=BitcoinRateGBPTest
mvn clean test -Dtest=BitcoinRateEURTest
```

### From IDE (IntelliJ / Eclipse):

1. Open project as Maven project (select `pom.xml`).
2. Wait for dependencies to download.
3. Right-click `testng.xml` → **Run 'testng.xml'**, or
   right-click any individual test class → **Run As > TestNG Test**.

## Sample Output (Scenario 3 - USD)

```
[TEST START] Print Bitcoin Rate Details for USD currency
---------- BITCOIN RATE - USD ----------
Step 4 -> Code        : USD
Step 5 -> Symbol      : &#36;
Step 6 -> Rate        : 65,432.1234
Step 7 -> Description : United States Dollar
Step 8 -> USD Rate    : 65,432.1234
Step 9 -> Rate Float  : 65432.1234
----------------------------------------
[TEST PASSED] USD Bitcoin rate details printed successfully.
```

## Test Reports

After execution, reports are generated under:
- `target/surefire-reports/index.html`
- `target/surefire-reports/emailable-report.html`

## Notes

- The CoinDesk API is public and requires no authentication.
- Scenario 2 hits an invalid endpoint to legitimately return 404.
- If the CoinDesk endpoint is unreachable, all live tests will fail with connection errors — this indicates an API/network issue rather than a code issue.
