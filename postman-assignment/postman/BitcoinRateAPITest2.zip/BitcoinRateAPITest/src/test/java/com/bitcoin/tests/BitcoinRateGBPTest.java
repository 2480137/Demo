package com.bitcoin.tests;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Scenario 4: Print Bitcoin rate against GBP currency.
 *
 * Steps:
 * 1. Create a maven project and import all the necessary dependencies for testng and rest assured.
 * 2. Create Test class and test method to execute the scenario.
 * 3. Send GET request for the URI through RestAssured:
 *    https://api.coindesk.com/v1/bpi/currentprice.json
 * 4. Print code
 * 5. Print Symbol
 * 6. Print rate
 * 7. Print Description
 * 8. Print GBP rate
 * 9. Print rate_float
 */
public class BitcoinRateGBPTest {

    private static final String BASE_URI = "https://api.coindesk.com";
    private static final String ENDPOINT = "/v1/bpi/currentprice.json";

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test Setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    @Test(description = "Print Bitcoin rate against GBP currency")
    public void printBitcoinRateForGBP() {

        System.out.println("\n[TEST START] Print Bitcoin Rate Details for GBP currency");

        // Step 3: Send GET request through RestAssured
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        // Verify status code first
        int statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 200, "Expected status code 200 but got " + statusCode);

        // Parse response body
        JsonPath jsonPath = response.jsonPath();

        // Extract values from the JSON response under bpi.GBP
        String code        = jsonPath.getString("bpi.GBP.code");
        String symbol      = jsonPath.getString("bpi.GBP.symbol");
        String rate        = jsonPath.getString("bpi.GBP.rate");
        String description = jsonPath.getString("bpi.GBP.description");
        Float  rateFloat   = jsonPath.getFloat("bpi.GBP.rate_float");

        // Steps 4 - 9: Print all required fields
        System.out.println("---------- BITCOIN RATE - GBP ----------");
        System.out.println("Step 4 -> Code        : " + code);
        System.out.println("Step 5 -> Symbol      : " + symbol);
        System.out.println("Step 6 -> Rate        : " + rate);
        System.out.println("Step 7 -> Description : " + description);
        System.out.println("Step 8 -> GBP Rate    : " + rate);
        System.out.println("Step 9 -> Rate Float  : " + rateFloat);
        System.out.println("----------------------------------------");

        // Assertions to confirm the data was retrieved correctly
        Assert.assertEquals(code, "GBP", "Expected currency code GBP");
        Assert.assertNotNull(symbol, "Symbol should not be null");
        Assert.assertNotNull(rate, "Rate should not be null");
        Assert.assertNotNull(description, "Description should not be null");
        Assert.assertNotNull(rateFloat, "Rate Float should not be null");

        System.out.println("[TEST PASSED] GBP Bitcoin rate details printed successfully.\n");
    }
}
