# GoRest Create User & Capture Id - REST Assured + TestNG

Maven-based Java project that automates the **"Set the environment variables
in Postman"** scenario using **REST Assured** and **TestNG**. The test sends
a POST request to GoRest's `/users` endpoint, captures the new user's `id`
from the response into a static class-level field (the REST Assured
parallel of Postman's `pm.globals.set("APIID", id)`), and verifies the
response.

## Scenario

1. Configure the GoRest base URI.
2. POST to `https://gorest.co.in/public/v2/users` with:
   - **Bearer Token** header (your personal GoRest token)
   - JSON body: `{ name, email, gender, status }`
3. Capture the returned `id` into the public static field `APIID`.
4. Verify the response is `201 Created` and every echoed field matches what
   was sent.
5. Read the captured `APIID` from a follow-up test that performs
   `GET /users/{APIID}` - proving the variable is reusable in chained tests.

## Postman → REST Assured Concept Mapping

| Postman                                  | REST Assured (Java)                                  |
|------------------------------------------|------------------------------------------------------|
| `pm.globals.set("APIID", id)`            | `APIID = response.jsonPath().getInt("id");`          |
| `pm.globals.get("APIID")`                | Read the static `APIID` field directly               |
| `{{APIID}}` in URL                       | `pathParam("id", APIID).get("/users/{id}")`          |
| Bearer token in Auth tab                 | `header("Authorization", "Bearer " + token)`         |
| Sample body in Body tab                  | `given().body("{...}")`                              |
| Tests/Scripts tab                        | TestNG `Assert.*` calls                              |

## IMPORTANT - GoRest Requires a Personal Access Token

GoRest is a real public API, not a sandbox. **Every** request must include
a Bearer token from a registered user account. Without it, `POST /users`
returns `401 Unauthorized`.

### How to get a token

1. Sign up for a free account at <https://gorest.co.in/>.
2. Click your profile (top-right) and open **Access Tokens**.
3. Click **Generate Access Token** - copy the resulting string.

### How to supply the token to the test

**Option A - Maven system property:**

```bash
mvn clean test -Dgorest.token=YOUR_TOKEN_HERE
```

**Option B - Environment variable:**

```bash
export GOREST_TOKEN=YOUR_TOKEN_HERE
mvn clean test
```

**Option C - From an IDE:** add `-Dgorest.token=YOUR_TOKEN_HERE` to the VM
options of the run configuration, or set `GOREST_TOKEN` in the environment
variables panel of the run config.

If no token is supplied, the `@BeforeClass` method skips the entire suite
(via `SkipException`) with a clear error message - rather than failing
with a confusing 401 from GoRest.

## Sample Request Body

The test builds a unique-email body each run (to avoid GoRest's duplicate-
email validation):

```json
{
  "name":   "Tenali Ramakrishna",
  "email":  "tenali_<timestamp>@example.com",
  "gender": "male",
  "status": "active"
}
```

## About the Response

GoRest returns `201 Created` and the full user object including the new id:

```json
{
    "id": 7779726,
    "name": "Tenali Ramakrishna",
    "email": "tenali_1714765432@example.com",
    "gender": "male",
    "status": "active"
}
```

The `id` field is what gets captured into the `APIID` static variable for
reuse in subsequent tests.

## Project Structure

```
GoRestCreateUserCaptureIdTest/
├── pom.xml                              # Maven dependencies + token forwarding
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/gorest/tests/
    └── GoRestCreateUserCaptureIdTest.java
```

## What the Test Class Does

| # | Method                            | Purpose                                                                       |
|---|-----------------------------------|-------------------------------------------------------------------------------|
| 1 | `createUserAndCaptureId`          | Main: POST a user, capture the id into `APIID`, verify 201 + all echoed fields. |
| 2 | `readCapturedIdAndGetUser`        | Bonus - reads `APIID` and uses it to GET the user back (chained request).      |
| 3 | `createUserWithFluentStyle`       | Bonus - same POST asserted with REST Assured's fluent `then().body()` style.   |

## Key REST Assured Patterns

```java
// 1. The "global variable" - a static class-level field
public static int APIID;

// 2. POST with Bearer token + JSON body
Response response = given()
        .header("Content-Type",  "application/json")
        .header("Authorization", "Bearer " + token)
        .body("{ \"name\": ..., \"email\": ..., ... }")
    .when().post("/public/v2/users")
    .then().extract().response();

// 3. Capture id - parallel to pm.globals.set("APIID", id)
APIID = response.jsonPath().getInt("id");

// 4. Read the captured id later (parallel to pm.globals.get("APIID"))
given().pathParam("id", APIID).get("/public/v2/users/{id}");
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection
- **Personal GoRest access token** (see above)

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven (recommended)

```bash
mvn clean test -Dgorest.token=YOUR_TOKEN_HERE
```

### Option 2 - With env variable

```bash
export GOREST_TOKEN=YOUR_TOKEN_HERE
mvn clean test
```

### Option 3 - From IDE

Open as a Maven project, set the system property `-Dgorest.token=YOUR_TOKEN_HERE`
in the VM options of the run configuration, then right-click `testng.xml`
and **Run 'testng.xml'**.

### Option 4 - Single test method

```bash
mvn clean test -Dgorest.token=YOUR_TOKEN_HERE -Dtest=GoRestCreateUserCaptureIdTest#createUserAndCaptureId
```

## Expected Output (abridged)

```
Test setup: Base URI configured -> https://gorest.co.in
Token loaded (length): 64 chars

[TEST START] createUserAndCaptureId
Request URL    : https://gorest.co.in/public/v2/users
Method         : POST
Auth           : Bearer ********
Status code    : 201

--- Pretty-printed response body ---
{
    "id": 7779726,
    "name": "Tenali Ramakrishna",
    "email": "tenali_1714765432@example.com",
    "gender": "male",
    "status": "active"
}

--- Captured global variable ---
APIID = 7779726    (parallel of Postman pm.globals.set("APIID", 7779726))

--- Echoed response fields ---
name   : Tenali Ramakrishna
email  : tenali_1714765432@example.com
gender : male
status : active
[TEST PASSED] User created with id=7779726 and captured into the APIID global variable.

[TEST START] readCapturedIdAndGetUser
Reading global APIID = 7779726
GET /users/7779726 returned id = 7779726
[TEST PASSED] Captured global APIID was reusable in a follow-up request.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- GoRest's "user" data is real and persistent across runs (within the limits
  of free tier rate limits). Each test run creates real records on the server
  using a unique timestamp-based email.
- The token has scoped permissions and a daily request limit on the free
  tier - if you hit `429 Too Many Requests`, wait a few minutes or upgrade.
- Never commit real tokens to version control. Pass them via environment
  variable or system property at run time.
- If the network is unavailable or the token is invalid, the tests will
  fail with clear error messages.
