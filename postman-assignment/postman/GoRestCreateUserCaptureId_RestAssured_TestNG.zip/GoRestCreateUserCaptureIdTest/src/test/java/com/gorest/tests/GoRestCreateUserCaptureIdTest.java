package com.gorest.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hands-On 12: Set the environment variables in Postman - automated with
 * REST Assured.
 *
 * Postman scenario (automated equivalent below):
 *   Method   : POST
 *   URL      : https://gorest.co.in/public/v2/users
 *   Auth     : Bearer Token (personal access token from gorest.co.in profile)
 *   Body     : { name, email, gender, status } (sample user payload)
 *   Action   : POST -> capture id from response into a global variable -> verify 201
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. baseURI configured to https://gorest.co.in
 *  4. POST sent to /public/v2/users with Bearer token + JSON body.
 *  5. The 'id' field is captured from the response into a static class-level
 *     field 'APIID' (the REST Assured equivalent of a Postman global variable).
 *  6. Status code asserted to be 201 Created.
 *  7. Echoed response fields verified.
 *
 * Postman -> REST Assured concept mapping:
 *   pm.globals.set("APIID", id)        - static field assignment in Java
 *   pm.globals.get("APIID")            - read the static field
 *   {{APIID}} in URL                   - Java string concatenation / pathParam
 *
 * IMPORTANT - GoRest requires a personal access token:
 *   GoRest is a real public API, not a sandbox. Every request to it must
 *   include a Bearer token from a user account at https://gorest.co.in.
 *   To run this test, sign up for a free account, generate a token from
 *   the Access Tokens page, and pass it via system property:
 *
 *       mvn clean test -Dgorest.token=YOUR_TOKEN_HERE
 *
 *   Or via environment variable:
 *
 *       export GOREST_TOKEN=YOUR_TOKEN_HERE
 *       mvn clean test
 *
 *   If no token is supplied, the @BeforeClass will skip the entire suite
 *   with a clear error message (rather than failing with a 401 from GoRest).
 */
public class GoRestCreateUserCaptureIdTest {

    private static final String BASE_URI = "https://gorest.co.in";
    private static final String ENDPOINT = "/public/v2/users";

    /**
     * The "global variable" - parallel to Postman's pm.globals.set("APIID", id).
     * Static so any other test class in the same JVM run can read it.
     */
    public static int APIID;

    /** Personal access token loaded once at @BeforeClass time. */
    private String bearerToken;

    @BeforeClass
    public void setUp() {
        // Step 3 - Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;

        // Resolve the token from -Dgorest.token=... or env var GOREST_TOKEN
        bearerToken = System.getProperty("gorest.token");
        if (bearerToken == null || bearerToken.isEmpty() || "${gorest.token}".equals(bearerToken)) {
            bearerToken = System.getenv("GOREST_TOKEN");
        }
        if (bearerToken == null || bearerToken.isEmpty()) {
            throw new SkipException(
                "GoRest token not configured. Sign up at https://gorest.co.in, "
              + "generate an access token, and pass it via "
              + "-Dgorest.token=YOUR_TOKEN_HERE or the GOREST_TOKEN env var.");
        }

        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("Token loaded (length): " + bearerToken.length() + " chars");
        System.out.println("=========================================================");
    }

    /**
     * Steps 4-7 - POST to /users with Bearer token + body, capture id into
     * the APIID global variable, verify status 201, and verify the response.
     */
    @Test(priority = 1,
          description = "POST /public/v2/users with Bearer token - capture id into APIID global variable")
    public void createUserAndCaptureId() {

        System.out.println("\n[TEST START] createUserAndCaptureId");

        // Step 7a - Build a unique-email body. GoRest rejects duplicate emails,
        // so each run uses a timestamp-based email to avoid 422 collisions.
        String name   = "Tenali Ramakrishna";
        String email  = "tenali_" + System.currentTimeMillis() + "@example.com";
        String gender = "male";
        String status = "active";

        String body = "{\n"
                + "  \"name\":   \"" + name   + "\",\n"
                + "  \"email\":  \"" + email  + "\",\n"
                + "  \"gender\": \"" + gender + "\",\n"
                + "  \"status\": \"" + status + "\"\n"
                + "}";

        // Step 4 - Send the POST with Bearer token + body
        Response response = RestAssured
                .given()
                    .header("Content-Type",  "application/json")
                    .header("Accept",        "application/json")
                    .header("Authorization", "Bearer " + bearerToken)
                    .body(body)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Method         : POST");
        System.out.println("Auth           : Bearer ********");
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        // Step 6 - Status assertion
        Assert.assertEquals(statusCode, 201,
                "FAILED: expected 201 Created but got " + statusCode
                + " - response was: " + response.getBody().asString());

        // Step 5 - Capture id into the APIID global variable.
        // This is the REST Assured parallel of:
        //   pm.globals.set("APIID", pm.response.json().id);
        APIID = response.jsonPath().getInt("id");
        Assert.assertTrue(APIID > 0,
                "FAILED: response 'id' was not a positive integer");

        System.out.println("\n--- Captured global variable ---");
        System.out.println("APIID = " + APIID
                + "    (parallel of Postman pm.globals.set(\"APIID\", " + APIID + "))");

        // Step 7 - Verify echoed fields
        String  rName   = response.jsonPath().getString("name");
        String  rEmail  = response.jsonPath().getString("email");
        String  rGender = response.jsonPath().getString("gender");
        String  rStatus = response.jsonPath().getString("status");

        System.out.println("\n--- Echoed response fields ---");
        System.out.println("name   : " + rName);
        System.out.println("email  : " + rEmail);
        System.out.println("gender : " + rGender);
        System.out.println("status : " + rStatus);

        Assert.assertEquals(rName,   name,   "FAILED: name did not round-trip");
        Assert.assertEquals(rEmail,  email,  "FAILED: email did not round-trip");
        Assert.assertEquals(rGender, gender, "FAILED: gender did not round-trip");
        Assert.assertEquals(rStatus, status, "FAILED: status did not round-trip");

        System.out.println("[TEST PASSED] User created with id=" + APIID
                + " and captured into the APIID global variable.\n");
    }

    /**
     * Bonus - proves the captured APIID global is reusable in subsequent tests
     * (request chaining). Uses the captured id to GET the freshly-created user.
     * This is the REST Assured parallel of Postman's:
     *   var id = pm.globals.get("APIID");  pm.sendRequest("/users/" + id, ...)
     */
    @Test(priority = 2,
          description = "Read APIID global variable and use it to GET the user back",
          dependsOnMethods = "createUserAndCaptureId")
    public void readCapturedIdAndGetUser() {

        System.out.println("\n[TEST START] readCapturedIdAndGetUser");

        Assert.assertTrue(APIID > 0,
                "Pre-condition failed: APIID was not set by the previous test");

        System.out.println("Reading global APIID = " + APIID);

        Response response = RestAssured
                .given()
                    .header("Authorization", "Bearer " + bearerToken)
                    .pathParam("id", APIID)
                .when()
                    .get(ENDPOINT + "/{id}")
                .then()
                    .extract().response();

        Assert.assertEquals(response.getStatusCode(), 200,
                "FAILED: expected 200 OK on follow-up GET but got " + response.getStatusCode());

        Integer returnedId = response.jsonPath().getInt("id");
        System.out.println("GET /users/" + APIID + " returned id = " + returnedId);

        Assert.assertEquals(returnedId, Integer.valueOf(APIID),
                "FAILED: returned user id does not match captured APIID");

        System.out.println("[TEST PASSED] Captured global APIID was reusable in a follow-up request.\n");
    }

    /**
     * Bonus - same scenario expressed using REST Assured's fluent
     * then().body() Hamcrest assertions for a more compact idiom.
     */
    @Test(priority = 3,
          description = "Create user with fluent then().body() style assertions")
    public void createUserWithFluentStyle() {

        System.out.println("\n[TEST START] createUserWithFluentStyle");

        String email = "fluent_" + System.currentTimeMillis() + "@example.com";
        String body = "{ \"name\": \"Fluent User\", \"email\": \"" + email
                + "\", \"gender\": \"female\", \"status\": \"active\" }";

        RestAssured
                .given()
                    .header("Content-Type",  "application/json")
                    .header("Authorization", "Bearer " + bearerToken)
                    .body(body)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(201)
                    .contentType(org.hamcrest.Matchers.containsString("json"))
                    .body("id",     org.hamcrest.Matchers.greaterThan(0))
                    .body("name",   org.hamcrest.Matchers.equalTo("Fluent User"))
                    .body("email",  org.hamcrest.Matchers.equalTo(email))
                    .body("gender", org.hamcrest.Matchers.equalTo("female"))
                    .body("status", org.hamcrest.Matchers.equalTo("active"));

        System.out.println("[TEST PASSED] Fluent-style POST assertions succeeded.\n");
    }
}
