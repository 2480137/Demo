# GoRest Read User by APIID - REST Assured + TestNG

Maven-based Java project that automates the **"Get the values of the
environment variables in Postman"** scenario using **REST Assured** and
**TestNG**. The test reads the previously-captured `APIID` global variable
and uses it on a `GET /public/v2/users/{APIID}` request, verifying the
response.

This is the **read-back companion** to the previous Hands-On 12 project
(which captured the `id` into `APIID`). Together they form the complete
Postman global-variable round-trip: write in one request, read in another.

## Scenario

1. Read the previously-stored `APIID` global variable.
2. GET `https://gorest.co.in/public/v2/users/{APIID}` with:
   - **Bearer Token** in the `Authorization` header
3. Verify the response is `200 OK` and the returned user matches the one
   that was created.

## Postman → REST Assured Concept Mapping

| Postman                                  | REST Assured (Java)                                  |
|------------------------------------------|------------------------------------------------------|
| `pm.globals.get("APIID")`                | Read the static `APIID` field                        |
| `{{APIID}}` in URL                       | `pathParam("id", APIID).get("/users/{id}")`          |
| Pre-request script reading APIID         | First lines of `@Test` method (or `@BeforeClass`)    |
| Bearer token in Auth tab                 | `header("Authorization", "Bearer " + token)`         |
| Tests/Scripts tab                        | TestNG `Assert.*` calls                              |

## How the Test Stays Self-Contained

In Postman, the `APIID` global is set by Hands-On 12 and persists in the
workspace until cleared. A REST Assured suite has no persistent storage
between JVM runs - if the test relied on a static field set by another
class, it could not be run in isolation. To make the suite self-contained,
`@BeforeClass` performs the same POST that Hands-On 12 does and stores the
returned id in the static `APIID` field. After that point the test
behaves exactly like a Postman request that reads a pre-existing global.

```java
public static int APIID;       // the "global variable"

// @BeforeClass populates it:
APIID = createResp.jsonPath().getInt("id");

// @Test reads it:
.pathParam("id", APIID).get("/public/v2/users/{id}");
```

## IMPORTANT - GoRest Requires a Personal Access Token

Same as Hands-On 12. Sign up at <https://gorest.co.in>, generate a token
from the **Access Tokens** page, and supply it via:

```bash
mvn clean test -Dgorest.token=YOUR_TOKEN_HERE
```

Or:

```bash
export GOREST_TOKEN=YOUR_TOKEN_HERE
mvn clean test
```

Without a token the suite is skipped with a clear message.

## Project Structure

```
GoRestReadUserByGlobalIdTest/
├── pom.xml                              # Maven dependencies + token forwarding
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/gorest/tests/
    └── GoRestReadUserByGlobalIdTest.java
```

## What the Test Class Does

`@BeforeClass` configures the base URI, loads the GoRest token, then POSTs
a fresh user and stores the returned id in the static field `APIID` -
exactly mirroring what Hands-On 12 does on its own.

| # | Method                                 | Purpose                                                                                |
|---|----------------------------------------|----------------------------------------------------------------------------------------|
| 1 | `getUserUsingGlobalApiId`              | Main: read `APIID`, GET `/users/{APIID}`, verify status 200 and every field.            |
| 2 | `getUserUsingGlobalApiIdFluentStyle`   | Bonus - same checks expressed in REST Assured's fluent `then().body()` Hamcrest style. |
| 3 | `getUserUsingApiIdViaConcatenation`    | Bonus - URL built via concatenation instead of `pathParam()`; iterates response Map.   |

## Key REST Assured Patterns

```java
// 1. Reading the global variable (parallel of pm.globals.get("APIID"))
int idFromGlobal = APIID;

// 2. Two ways to use the value in the URL:

//   a) pathParam (preferred - encoding, readability, request logging)
given().pathParam("id", APIID).get("/users/{id}");

//   b) Direct concatenation (works but less idiomatic)
given().get("/users/" + APIID);

// 3. Bearer token + Accept header
.given()
    .header("Accept",        "application/json")
    .header("Authorization", "Bearer " + bearerToken)
```

## Sample Response Body

```json
{
    "id": 7779726,
    "name": "Read Variable User",
    "email": "read_var_1714765432@example.com",
    "gender": "male",
    "status": "active"
}
```

The test verifies that `id` in the response equals `APIID` and that every
other field matches what was sent on creation.

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection
- **Personal GoRest access token**

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test -Dgorest.token=YOUR_TOKEN_HERE
```

### Option 2 - Environment variable

```bash
export GOREST_TOKEN=YOUR_TOKEN_HERE
mvn clean test
```

### Option 3 - From IDE

Open as a Maven project, set `-Dgorest.token=YOUR_TOKEN_HERE` in the VM
options of the run configuration, then right-click `testng.xml` →
**Run 'testng.xml'**.

### Option 4 - Single test method

```bash
mvn clean test -Dgorest.token=YOUR_TOKEN_HERE \
    -Dtest=GoRestReadUserByGlobalIdTest#getUserUsingGlobalApiId
```

## Expected Output (abridged)

```
Test setup: Base URI configured -> https://gorest.co.in
Token loaded (length): 64 chars
[BeforeClass] Captured APIID = 7779726  (the parallel of pm.globals.set("APIID", 7779726))

[TEST START] getUserUsingGlobalApiId
Read APIID from global (pre-step) -> 7779726
Request URL    : https://gorest.co.in/public/v2/users/7779726
Method         : GET
Auth           : Bearer ********
Status code    : 200

--- Pretty-printed response body ---
{
    "id": 7779726,
    "name": "Read Variable User",
    "email": "read_var_1714765432@example.com",
    "gender": "male",
    "status": "active"
}

--- Field-by-field values ---
id     : 7779726
name   : Read Variable User
email  : read_var_1714765432@example.com
gender : male
status : active
[TEST PASSED] APIID=7779726 was read and used; response matches the user that was created.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- This project complements Hands-On 12. Together they demonstrate the full
  Postman global-variable round-trip: capture an id from one response, use
  it in a later request.
- The test is self-contained: it does not depend on Hands-On 12 having run
  first. It performs its own POST to populate `APIID` so it can be run in
  isolation.
- If the network is unavailable or the token is invalid, the tests will
  fail with clear error messages.
