package com.gorest.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

/**
 * Hands-On 13: Get the values of the environment variables in Postman -
 * automated with REST Assured.
 *
 * Postman scenario (automated equivalent below):
 *   Method   : GET
 *   URL      : https://gorest.co.in/public/v2/users/{{APIID}}
 *   Pre-req  : Read APIID from globals (set by Hands-On 12 / POST /users)
 *   Auth     : Bearer Token (personal access token from gorest.co.in)
 *   Action   : Send and verify status 200 + response body
 *
 * Postman -> REST Assured concept mapping:
 *   {{APIID}} in URL                 -> pathParam("id", APIID).get("/users/{id}")
 *   pm.globals.get("APIID")          -> read the static APIID field directly
 *   Pre-request script reads APIID   -> @BeforeClass / first lines of @Test method
 *   Bearer token in Authorization    -> header("Authorization", "Bearer " + token)
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. baseURI configured to https://gorest.co.in
 *  4. APIID populated by chaining a POST /users in @BeforeClass (the
 *     equivalent of having Hands-On 12 run first to set the variable).
 *  5. The captured APIID is read and used on a GET /public/v2/users/{APIID}.
 *  6. Bearer token applied.
 *  7. Status 200 verified, response body verified field-by-field.
 *
 * Why we POST a fresh user in @BeforeClass:
 *   Postman's APIID global persists between Postman sessions - it can sit
 *   in the workspace for hours. A REST Assured suite has no persistent
 *   storage between JVM runs, so the test creates a fresh user and stores
 *   its id in the static APIID field. This makes the suite self-contained:
 *   it does not depend on any other test class having already set APIID.
 *
 * IMPORTANT - GoRest requires a personal access token:
 *   Pass it via -Dgorest.token=YOUR_TOKEN_HERE or env var GOREST_TOKEN.
 *   Without a token the suite is skipped with a clear message (see setUp).
 */
public class GoRestReadUserByGlobalIdTest {

    private static final String BASE_URI = "https://gorest.co.in";
    private static final String ENDPOINT = "/public/v2/users";

    /**
     * The "global variable" - parallel to Postman's pm.globals.set("APIID", id).
     * Public + static so it is reachable by any other test class in this JVM.
     */
    public static int APIID;

    /** Personal GoRest access token loaded once at @BeforeClass time. */
    private String bearerToken;

    /** Body used to chain a fresh user creation in @BeforeClass. */
    private String createdName;
    private String createdEmail;
    private String createdGender;
    private String createdStatus;

    @BeforeClass
    public void setUp() {

        // Step 3 - Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;

        // Resolve the token from -Dgorest.token=... or env var GOREST_TOKEN
        bearerToken = System.getProperty("gorest.token");
        if (bearerToken == null || bearerToken.isEmpty() || "${gorest.token}".equals(bearerToken)) {
            bearerToken = System.getenv("GOREST_TOKEN");
        }
        if (bearerToken == null || bearerToken.isEmpty()) {
            throw new SkipException(
                "GoRest token not configured. Sign up at https://gorest.co.in, "
              + "generate an access token, and pass it via "
              + "-Dgorest.token=YOUR_TOKEN_HERE or the GOREST_TOKEN env var.");
        }

        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("Token loaded (length): " + bearerToken.length() + " chars");
        System.out.println("=========================================================");

        // Step 4 - Chain to Hands-On 12 by POSTing a fresh user and capturing
        // its id into APIID. After this, APIID behaves exactly like a Postman
        // global that was set by a previous request.
        createdName   = "Read Variable User";
        createdEmail  = "read_var_" + System.currentTimeMillis() + "@example.com";
        createdGender = "male";
        createdStatus = "active";

        String body = "{\n"
                + "  \"name\":   \"" + createdName   + "\",\n"
                + "  \"email\":  \"" + createdEmail  + "\",\n"
                + "  \"gender\": \"" + createdGender + "\",\n"
                + "  \"status\": \"" + createdStatus + "\"\n"
                + "}";

        Response createResp = RestAssured
                .given()
                    .header("Content-Type",  "application/json")
                    .header("Authorization", "Bearer " + bearerToken)
                    .body(body)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract().response();

        Assert.assertEquals(createResp.getStatusCode(), 201,
                "FAILED: pre-condition - POST /users returned "
                        + createResp.getStatusCode() + " (expected 201). "
                        + "Body: " + createResp.getBody().asString());

        APIID = createResp.jsonPath().getInt("id");
        Assert.assertTrue(APIID > 0,
                "FAILED: pre-condition - captured APIID was not positive");

        System.out.println("[BeforeClass] Captured APIID = " + APIID
                + "  (the parallel of pm.globals.set(\"APIID\", " + APIID + "))");
    }

    /**
     * Steps 5-7 - Read the captured APIID, GET /public/v2/users/{APIID} with
     * Bearer auth, verify 200 and the response body.
     */
    @Test(priority = 1,
          description = "GET /public/v2/users/{APIID} - read global APIID and use it on a GET")
    public void getUserUsingGlobalApiId() {

        System.out.println("\n[TEST START] getUserUsingGlobalApiId");

        // Step 4 (the assignment's pre-script equivalent): read the previously
        // captured global. In Postman this is:
        //     var id = pm.globals.get("APIID");
        // Here it is just a static field access.
        int idFromGlobal = APIID;
        System.out.println("Read APIID from global (pre-step) -> " + idFromGlobal);
        Assert.assertTrue(idFromGlobal > 0,
                "Pre-condition failed: APIID is not set. Did setUp() run successfully?");

        // Step 5+6 - Send GET with the captured id as a path parameter and
        // the Bearer token in the Authorization header
        Response response = RestAssured
                .given()
                    .header("Accept",        "application/json")
                    .header("Authorization", "Bearer " + bearerToken)
                    .pathParam("id", idFromGlobal)         // {{APIID}} substitution
                .when()
                    .get(ENDPOINT + "/{id}")
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT + "/" + idFromGlobal);
        System.out.println("Method         : GET");
        System.out.println("Auth           : Bearer ********");
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        // Step 6 - Status assertion
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK but got " + statusCode);

        // Step 7 - Response body verification
        Integer rId     = response.jsonPath().getInt("id");
        String  rName   = response.jsonPath().getString("name");
        String  rEmail  = response.jsonPath().getString("email");
        String  rGender = response.jsonPath().getString("gender");
        String  rStatus = response.jsonPath().getString("status");

        System.out.println("\n--- Field-by-field values ---");
        System.out.println("id     : " + rId);
        System.out.println("name   : " + rName);
        System.out.println("email  : " + rEmail);
        System.out.println("gender : " + rGender);
        System.out.println("status : " + rStatus);

        // The id in the response must equal the APIID we used in the URL
        Assert.assertEquals(rId, Integer.valueOf(idFromGlobal),
                "FAILED: response id does not match the APIID used in the URL");
        Assert.assertEquals(rName,   createdName,   "FAILED: name did not round-trip");
        Assert.assertEquals(rEmail,  createdEmail,  "FAILED: email did not round-trip");
        Assert.assertEquals(rGender, createdGender, "FAILED: gender did not round-trip");
        Assert.assertEquals(rStatus, createdStatus, "FAILED: status did not round-trip");

        System.out.println("[TEST PASSED] APIID=" + idFromGlobal
                + " was read and used; response matches the user that was created.\n");
    }

    /**
     * Bonus - same scenario expressed using REST Assured's fluent
     * then().body() Hamcrest assertions for a more compact idiom.
     */
    @Test(priority = 2,
          description = "GET using APIID with fluent then().body() style")
    public void getUserUsingGlobalApiIdFluentStyle() {

        System.out.println("\n[TEST START] getUserUsingGlobalApiIdFluentStyle");

        RestAssured
                .given()
                    .header("Authorization", "Bearer " + bearerToken)
                    .pathParam("id", APIID)
                .when()
                    .get(ENDPOINT + "/{id}")
                .then()
                    .assertThat()
                    .statusCode(200)
                    .contentType(org.hamcrest.Matchers.containsString("json"))
                    .body("id",     org.hamcrest.Matchers.equalTo(APIID))
                    .body("name",   org.hamcrest.Matchers.equalTo(createdName))
                    .body("email",  org.hamcrest.Matchers.equalTo(createdEmail))
                    .body("gender", org.hamcrest.Matchers.equalTo(createdGender))
                    .body("status", org.hamcrest.Matchers.equalTo(createdStatus));

        System.out.println("[TEST PASSED] Fluent-style read-via-APIID succeeded.\n");
    }

    /**
     * Bonus - alternative URL construction using string concatenation instead
     * of pathParam(). Both produce the same wire-level request; pathParam()
     * is preferred (URL encoding, readability, parameter logging) but the
     * concat form is shown for completeness.
     */
    @Test(priority = 3,
          description = "GET using APIID via string concatenation instead of pathParam()")
    public void getUserUsingApiIdViaConcatenation() {

        System.out.println("\n[TEST START] getUserUsingApiIdViaConcatenation");

        Response response = RestAssured
                .given()
                    .header("Authorization", "Bearer " + bearerToken)
                .when()
                    .get(ENDPOINT + "/" + APIID)        // direct concatenation
                .then()
                    .extract().response();

        Assert.assertEquals(response.getStatusCode(), 200,
                "FAILED: expected 200 OK with concatenated URL");

        // Iterate every field of the response body as a Map, mirroring how
        // the Postman scenario suggests printing/inspecting the response
        Map<String, Object> all = response.jsonPath().getMap("$");
        System.out.println("Response fields via Map iteration:");
        all.forEach((k, v) -> System.out.println("  " + k + " : " + v));

        System.out.println("[TEST PASSED] Concatenation form works equivalently.\n");
    }
}
