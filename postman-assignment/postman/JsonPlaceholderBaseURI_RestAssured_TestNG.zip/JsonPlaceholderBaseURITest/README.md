# JSONPlaceholder BaseURI - REST Assured + TestNG

Maven-based Java project that uses **REST Assured** and **TestNG** to call the
`GET /posts/{id}` endpoint of the public **JSONPlaceholder** API while
demonstrating the proper use of **`baseURI`** in REST Assured. The test
fetches post id 5 using a path parameter, parses the JSON response, and
prints the values.

## Scenario

Send a **GET** request to:

```
https://jsonplaceholder.typicode.com/posts/5
```

The host portion (`https://jsonplaceholder.typicode.com`) is configured once
through `RestAssured.baseURI`. Individual requests then use only the
relative endpoint path (`/{id}`).

## Why use baseURI?

Real test suites need to point at multiple environments (dev / staging /
prod) without rewriting every request. `baseURI` is the canonical place to
put the host so that individual tests stay environment-agnostic - in
production code it is typically loaded from a properties file, environment
variable, or system property.

```java
// One-liner setup - usually in @BeforeClass or @BeforeSuite
RestAssured.baseURI  = "https://jsonplaceholder.typicode.com";
RestAssured.basePath = "/posts";

// Tests then specify only the endpoint
given().pathParam("id", 5).get("/{id}");      // → /posts/5
given().get("");                              // → /posts
given().pathParam("id", 1).get("/{id}/comments");  // → /posts/1/comments
```

## URL Resolution Order

A REST Assured request URL is built by concatenating four parts:

```
[baseURI] + [basePath] + [endpoint path] + ?[query params]
```

Example:

| Configuration                                        | Final URL                                          |
|------------------------------------------------------|----------------------------------------------------|
| baseURI = `https://jsonplaceholder.typicode.com`     | host portion                                       |
| basePath = `/posts`                                  | common path prefix                                 |
| endpoint = `/{id}`                                   | relative request path                              |
| pathParam("id", 5)                                   | binds {id} → 5                                     |
| **Result**                                           | `https://jsonplaceholder.typicode.com/posts/5`     |

## About the Response

`GET /posts/5` returns a single post object:

```json
{
    "userId": 1,
    "id": 5,
    "title": "nesciunt quas odio",
    "body": "repudiandae veniam quaerat sunt sed alias..."
}
```

JSONPlaceholder is a fully open public API - **no authentication required**.

## Project Structure

```
JsonPlaceholderBaseURITest/
├── pom.xml                                        # Maven dependencies
├── testng.xml                                     # TestNG suite file
├── README.md
└── src/test/java/com/jsonplaceholder/tests/
    └── JsonPlaceholderBaseURITest.java
```

## What the Test Class Does

The `JsonPlaceholderBaseURITest` class contains three test methods:

| # | Method                            | Purpose                                                                                  |
|---|-----------------------------------|------------------------------------------------------------------------------------------|
| 1 | `getPostUsingBaseUri`             | Main: globally configured `RestAssured.baseURI` + `basePath`, fetches `/posts/5`.        |
| 2 | `overrideBaseUriPerRequest`       | Bonus - per-request override using `given().baseUri(...)` inside the chain.              |
| 3 | `verifyResponseWithFluentStyle`   | Bonus - response checked with REST Assured's fluent `then().body()` Hamcrest assertions. |

## Three Ways to Configure baseURI in REST Assured

```java
// 1. GLOBAL (most common) - set once for the whole test class or suite
RestAssured.baseURI  = "https://jsonplaceholder.typicode.com";
RestAssured.basePath = "/posts";

given().pathParam("id", 5).get("/{id}");
//   -> https://jsonplaceholder.typicode.com/posts/5

// 2. PER REQUEST - override the global value for one specific call
given()
    .baseUri("https://staging.example.com")        // overrides class-level value
    .basePath("/v2/posts")
    .pathParam("id", 5)
    .get("/{id}");
//   -> https://staging.example.com/v2/posts/5

// 3. EXPLICIT URL (no baseURI used) - hard-coded full URL in the get() call
given().get("https://jsonplaceholder.typicode.com/posts/5");
```

Pattern (1) is the standard for environment-driven test suites.

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to download,
then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=JsonPlaceholderBaseURITest#getPostUsingBaseUri
```

## Expected Output (abridged)

```
Test setup:
  baseURI  = https://jsonplaceholder.typicode.com
  basePath = /posts

[TEST START] getPostUsingBaseUri
Effective URL  : https://jsonplaceholder.typicode.com/posts/5
Status code    : 200

--- Pretty-printed JSON response ---
{
    "userId": 1,
    "id": 5,
    "title": "nesciunt quas odio",
    "body": "repudiandae veniam quaerat sunt sed alias aut fugiat sit autem sed est..."
}

--- Individual field values ---
userId : 1
id     : 5
title  : nesciunt quas odio
body   : repudiandae veniam quaerat sunt sed alias aut fugiat sit autem sed est...

[TEST PASSED] Response parsed and printed successfully.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- JSONPlaceholder always returns the same data set (100 posts, ids 1-100),
  so the response for `/posts/5` is stable and deterministic.
- `RestAssured.baseURI` is a **global** static field. If multiple test
  classes set it to different values, the order of test execution matters.
  In production code, it is good practice to either set it in
  `@BeforeSuite` (once per run) or use `given().baseUri(...)` per request
  to avoid cross-test contamination.
- No authentication or API key is required.
