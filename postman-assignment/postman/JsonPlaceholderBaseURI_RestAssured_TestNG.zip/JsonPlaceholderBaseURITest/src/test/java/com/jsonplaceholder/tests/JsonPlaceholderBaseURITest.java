package com.jsonplaceholder.tests;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

/**
 * Hands-On: Get the API response with baseURI in REST Assured.
 *
 * Scenario:
 *  Send a GET request to https://jsonplaceholder.typicode.com/posts/5,
 *  using REST Assured's baseURI to hold the protocol+host so individual
 *  requests can use just the endpoint path. Path parameter id = 5.
 *  Retrieve the response body, parse it, and print the values.
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. GET request sent to /posts/{id} (endpoint relative to baseURI).
 *  4. Path parameter 'id' set to 5.
 *  5. Endpoint URL passed via RestAssured.baseURI - so given().get("/posts/{id}")
 *     resolves to https://jsonplaceholder.typicode.com/posts/{id} at send time.
 *  6. Response values printed to the console.
 *
 * Why use baseURI?
 *   Real test suites need to point at multiple environments (dev / staging /
 *   prod) without rewriting every request. baseURI is the standard place to
 *   put the host so individual tests stay environment-agnostic - typically
 *   it is loaded from a config file or system property in production code.
 *
 * About the response (single object):
 *      {
 *          "userId": 1,
 *          "id": 5,
 *          "title": "nesciunt quas odio",
 *          "body":  "repudiandae veniam quaerat sunt sed alias..."
 *      }
 */
public class JsonPlaceholderBaseURITest {

    // Step 5 - the host portion is configured once as RestAssured.baseURI
    private static final String BASE_URI  = "https://jsonplaceholder.typicode.com";
    private static final String BASE_PATH = "/posts";    // common prefix for all post endpoints
    private static final int    POST_ID   = 5;

    @BeforeClass
    public void setUp() {
        // Step 5 - Configure baseURI globally for this class.
        // Every subsequent request that does not specify its own host will
        // resolve against this value.
        RestAssured.baseURI  = BASE_URI;
        RestAssured.basePath = BASE_PATH;   // optional - common path prefix

        System.out.println("=========================================================");
        System.out.println("Test setup:");
        System.out.println("  baseURI  = " + BASE_URI);
        System.out.println("  basePath = " + BASE_PATH);
        System.out.println("=========================================================");
    }

    /**
     * Step 3 + 4 + 6 - Send GET using the globally-configured baseURI,
     * with id=5 supplied as a path parameter, then parse and print the values.
     *
     * Because baseURI and basePath are already set, the request only needs
     * to specify the relative endpoint "/{id}".
     */
    @Test(priority = 1,
          description = "GET /posts/{id} via baseURI - parse and print response")
    public void getPostUsingBaseUri() {

        System.out.println("\n[TEST START] getPostUsingBaseUri");

        // Step 3 + 4 - Send GET; baseURI + basePath + endpoint combine to form
        // the full URL: https://jsonplaceholder.typicode.com/posts/5
        Response response = RestAssured
                .given()
                    .header("Accept", "application/json")
                    .pathParam("id", POST_ID)
                .when()
                    .get("/{id}")               // resolves against baseURI + basePath
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();
        System.out.println("Effective URL  : " + BASE_URI + BASE_PATH + "/" + POST_ID);
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("Content-Type   : " + response.getContentType());

        // Sanity check
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK but got " + statusCode);

        // Step 6a - Print the pretty-formatted body
        System.out.println("\n--- Pretty-printed JSON response ---");
        System.out.println(response.getBody().asPrettyString());

        // Step 6b - Parse with JsonPath and print individual values
        JsonPath jsonPath = response.jsonPath();

        Integer userId = jsonPath.getInt("userId");
        Integer id     = jsonPath.getInt("id");
        String  title  = jsonPath.getString("title");
        String  body   = jsonPath.getString("body");

        System.out.println("\n--- Individual field values ---");
        System.out.println("userId : " + userId);
        System.out.println("id     : " + id);
        System.out.println("title  : " + title);
        System.out.println("body   : " + body);

        // Verify the right post was returned
        Assert.assertEquals(id, Integer.valueOf(POST_ID),
                "FAILED: expected id=" + POST_ID + " but got " + id);

        // Step 6c - Print every field as a Map
        Map<String, Object> all = jsonPath.getMap("$");
        System.out.println("\n--- All fields via Map iteration ---");
        all.forEach((k, v) -> System.out.println("  " + k + " : " + v));

        // Sanity assertions
        Assert.assertNotNull(title,  "FAILED: title was null");
        Assert.assertFalse(title.isEmpty(),
                "FAILED: title was empty");
        Assert.assertNotNull(body,   "FAILED: body was null");
        Assert.assertTrue(userId > 0,
                "FAILED: userId should be positive, got " + userId);

        System.out.println("[TEST PASSED] Response parsed and printed successfully.\n");
    }

    /**
     * Bonus - per-request baseUri() inside the given() chain. This overrides
     * the global RestAssured.baseURI for a single call - useful when one
     * test in a class needs to hit a different host than the rest.
     */
    @Test(priority = 2,
          description = "Override baseURI per request using given().baseUri(...)")
    public void overrideBaseUriPerRequest() {

        System.out.println("\n[TEST START] overrideBaseUriPerRequest");

        Response response = RestAssured
                .given()
                    .baseUri(BASE_URI)              // explicit per-request override
                    .basePath(BASE_PATH)
                    .pathParam("id", POST_ID)
                .when()
                    .get("/{id}")
                .then()
                    .extract().response();

        Assert.assertEquals(response.getStatusCode(), 200,
                "FAILED: expected 200 OK");

        System.out.println("Effective URL : " + BASE_URI + BASE_PATH + "/" + POST_ID);
        System.out.println("title         : " + response.jsonPath().getString("title"));

        System.out.println("[TEST PASSED] Per-request baseUri override succeeded.\n");
    }

    /**
     * Bonus - same response checked with REST Assured's fluent
     * then().body() Hamcrest assertions for a more compact idiom.
     */
    @Test(priority = 3,
          description = "Fluent Hamcrest assertions on the /posts/{id} response")
    public void verifyResponseWithFluentStyle() {

        System.out.println("\n[TEST START] verifyResponseWithFluentStyle");

        RestAssured
                .given()
                    .pathParam("id", POST_ID)
                .when()
                    .get("/{id}")
                .then()
                    .assertThat()
                    .statusCode(200)
                    .contentType(org.hamcrest.Matchers.containsString("json"))
                    .body("id",     org.hamcrest.Matchers.equalTo(POST_ID))
                    .body("userId", org.hamcrest.Matchers.greaterThan(0))
                    .body("title",  org.hamcrest.Matchers.not(org.hamcrest.Matchers.emptyString()))
                    .body("body",   org.hamcrest.Matchers.not(org.hamcrest.Matchers.emptyString()));

        System.out.println("[TEST PASSED] Fluent style assertions succeeded.\n");
    }
}
