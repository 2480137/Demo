# JSONPlaceholder Create Post - REST Assured + TestNG

Maven-based Java project that automates the **"Get the ID of the given API
in Postman"** scenario using **REST Assured** and **TestNG**. The test sends
a POST request to JSONPlaceholder's `/posts` endpoint with a sample JSON
body, asserts the response status is `201 Created`, and verifies that the
response includes the newly-assigned `id` field along with the echoed
title, body, and userId.

## Scenario

Send a **POST** request to:

```
https://jsonplaceholder.typicode.com/posts
```

with a JSON body containing `title`, `body`, and `userId`. Verify the
response is `201 Created` and that the body contains a new `id` plus the
echoed fields.

## About JSONPlaceholder

JSONPlaceholder (`jsonplaceholder.typicode.com`) is a free fake REST API
for testing and prototyping. It ships with 100 pre-loaded posts and
requires **no authentication**.

### Important - simulated persistence

Write operations on JSONPlaceholder are **simulated**. The server
responds as if the resource was created, but nothing is actually
persisted. Specifically:

- A POST to `/posts` always returns `id = 101` (one greater than the 100
  pre-loaded posts).
- A subsequent `GET /posts/101` returns `404 Not Found` - the new
  resource only exists in the response of the POST itself.
- The same POST can be sent a million times and always returns
  `id = 101`.

This is the documented behaviour of the API and **not a defect**. The
test asserts on `id == 101` to match the actual server behaviour.

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request                           | New `@Test` method                                   |
| Set the method to POST                      | `given().when().post(ENDPOINT)`                      |
| Set the URL                                 | `RestAssured.baseURI` + endpoint path                |
| Set raw JSON body                           | `given().body(POST_BODY)`                            |
| (No auth needed)                            | (no Authorization header)                            |
| Click Send → verify response                | `Assert.assertEquals(...)` / fluent `then().body()`  |

## Sample Request Body

The assignment refers to a request body "from the input file column". One
was not provided, so the project ships with this representative payload:

```json
{
  "title":  "API Testing with REST Assured",
  "body":   "Sample post body for assignment 14",
  "userId": 1
}
```

The values can be anything - only the field names need to match. `title`
and `body` are strings, `userId` is a positive integer (1-10 are valid
pre-loaded user ids on JSONPlaceholder).

## About the Response

JSONPlaceholder returns `201 Created` and a JSON body that echoes the
submitted fields plus a new `id`:

```json
{
    "title":  "API Testing with REST Assured",
    "body":   "Sample post body for assignment 14",
    "userId": 1,
    "id":     101
}
```

## Project Structure

```
JsonPlaceholderCreatePostTest/
├── pom.xml                                     # Maven dependencies
├── testng.xml                                  # TestNG suite file
├── README.md
└── src/test/java/com/jsonplaceholder/tests/
    └── JsonPlaceholderCreatePostTest.java
```

## What the Test Class Does

| # | Method                              | Purpose                                                                       |
|---|-------------------------------------|-------------------------------------------------------------------------------|
| 1 | `createPostAndVerifyResponse`       | Main: POST sample body, assert 201 Created, verify all 4 response fields.     |
| 2 | `createPostWithFluentStyle`         | Bonus - same checks expressed in REST Assured's fluent matcher style.         |
| 3 | `verifyResponseShapeAsMap`          | Bonus - iterates response as a `Map<String, Object>` and checks all 4 keys.   |

## Key REST Assured Patterns

```java
// Send POST with JSON body, no auth needed
Response response = given()
        .header("Content-Type", "application/json")
        .body("{ \"title\": \"...\", \"body\": \"...\", \"userId\": 1 }")
    .when()
        .post("/posts")
    .then()
        .extract().response();

// Verify status
assertEquals(response.getStatusCode(), 201);

// Extract individual fields
Integer id     = response.jsonPath().getInt("id");
String  title  = response.jsonPath().getString("title");
Integer userId = response.jsonPath().getInt("userId");
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=JsonPlaceholderCreatePostTest#createPostAndVerifyResponse
```

## Expected Output (abridged)

```
[TEST START] createPostAndVerifyResponse
Request URL    : https://jsonplaceholder.typicode.com/posts
Method         : POST
Status code    : 201
Content-Type   : application/json; charset=utf-8

--- Pretty-printed response body ---
{
    "title":  "API Testing with REST Assured",
    "body":   "Sample post body for assignment 14",
    "userId": 1,
    "id":     101
}

--- Field-by-field values ---
id     : 101    (server-assigned)
title  : API Testing with REST Assured
body   : Sample post body for assignment 14
userId : 1
[TEST PASSED] Post created with id=101 and all fields verified.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- JSONPlaceholder is fully open and stable; no signup, API keys, or rate
  limit concerns.
- Because writes are simulated, this test is repeatable and idempotent -
  running it many times has no side effects on the server.
- If the network is unavailable, all tests will fail with connection errors
  - this is an infrastructure issue, not a code defect.
