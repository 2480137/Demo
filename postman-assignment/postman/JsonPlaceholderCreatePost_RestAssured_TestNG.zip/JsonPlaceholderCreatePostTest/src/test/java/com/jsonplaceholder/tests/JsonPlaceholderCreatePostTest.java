package com.jsonplaceholder.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

/**
 * Hands-On 14: Get the ID of the given API in Postman - automated with
 * REST Assured.
 *
 * Postman scenario (automated equivalent below):
 *   Method   : POST
 *   URL      : https://jsonplaceholder.typicode.com/posts
 *   Auth     : none (public fake API)
 *   Body     : { title, body, userId }
 *   Action   : POST -> verify 201 Created -> verify the assigned id
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. baseURI configured to https://jsonplaceholder.typicode.com
 *  4. POST sent to /posts with a sample JSON body.
 *  5. Status code asserted to be 201 Created.
 *  6. Response body verified - echoes the submitted fields and includes a
 *     newly-assigned id.
 *
 * About JSONPlaceholder behaviour:
 *  JSONPlaceholder is a fake REST API: write operations are simulated.
 *  The server responds as if the resource was created, but nothing is
 *  actually persisted. As a result:
 *    - The new resource always gets id = 101 (one greater than the 100
 *      pre-loaded posts).
 *    - A subsequent GET /posts/101 returns 404 Not Found.
 *    - The same POST can be sent a million times and always returns
 *      id = 101.
 *  This is the documented behaviour of the API and not a defect.
 */
public class JsonPlaceholderCreatePostTest {

    private static final String BASE_URI = "https://jsonplaceholder.typicode.com";
    private static final String ENDPOINT = "/posts";

    /** Sample request body - the assignment refers to an "input file column"
     *  that was not provided, so this representative payload is supplied.
     *  Title and body are strings; userId is an integer (1-10 are valid
     *  pre-loaded user ids on JSONPlaceholder). */
    private static final String POST_BODY = "{\n"
            + "  \"title\":  \"API Testing with REST Assured\",\n"
            + "  \"body\":   \"Sample post body for assignment 14\",\n"
            + "  \"userId\": 1\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Step 3 - Configure RestAssured base URI for the class
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Steps 4-6 - Send POST /posts with the sample body, assert 201 Created,
     * and verify the response body (echoed fields + newly-assigned id).
     */
    @Test(priority = 1,
          description = "POST /posts - send sample body and verify status 201 + assigned id")
    public void createPostAndVerifyResponse() {

        System.out.println("\n[TEST START] createPostAndVerifyResponse");

        // Step 4 - Send POST with JSON body. No auth header is needed -
        // JSONPlaceholder is a fully open fake API.
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(POST_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Method         : POST");
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("Content-Type   : " + response.getContentType());
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        // Step 5 - Status assertion
        Assert.assertEquals(statusCode, 201,
                "FAILED: expected 201 Created but got " + statusCode);

        // Step 6 - Response body verification
        Integer assignedId = response.jsonPath().getInt("id");
        String  title      = response.jsonPath().getString("title");
        String  body       = response.jsonPath().getString("body");
        Integer userId     = response.jsonPath().getInt("userId");

        System.out.println("\n--- Field-by-field values ---");
        System.out.println("id     : " + assignedId   + "    (server-assigned)");
        System.out.println("title  : " + title);
        System.out.println("body   : " + body);
        System.out.println("userId : " + userId);

        // Echoed fields must round-trip exactly
        Assert.assertEquals(title,  "API Testing with REST Assured",
                "FAILED: title did not round-trip");
        Assert.assertEquals(body,   "Sample post body for assignment 14",
                "FAILED: body did not round-trip");
        Assert.assertEquals(userId, Integer.valueOf(1),
                "FAILED: userId did not round-trip");

        // The id must exist and be positive. JSONPlaceholder always returns
        // 101 for any POST, but the test asserts only that it is a valid
        // positive integer in case the API behaviour evolves.
        Assert.assertNotNull(assignedId,
                "FAILED: 'id' field was missing from the response");
        Assert.assertTrue(assignedId > 0,
                "FAILED: 'id' should be a positive integer, got " + assignedId);
        Assert.assertEquals(assignedId, Integer.valueOf(101),
                "FAILED: JSONPlaceholder is documented to always return id=101 for new posts");

        System.out.println("[TEST PASSED] Post created with id=" + assignedId
                + " and all fields verified.\n");
    }

    /**
     * Bonus - same scenario expressed using REST Assured's fluent
     * then().body() Hamcrest assertions for a more compact idiom.
     */
    @Test(priority = 2,
          description = "POST /posts - fluent then().body() style assertions")
    public void createPostWithFluentStyle() {

        System.out.println("\n[TEST START] createPostWithFluentStyle");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(POST_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(201)
                    .contentType(org.hamcrest.Matchers.containsString("json"))
                    .body("id",     org.hamcrest.Matchers.equalTo(101))
                    .body("title",  org.hamcrest.Matchers.equalTo("API Testing with REST Assured"))
                    .body("body",   org.hamcrest.Matchers.equalTo("Sample post body for assignment 14"))
                    .body("userId", org.hamcrest.Matchers.equalTo(1));

        System.out.println("[TEST PASSED] Fluent-style POST assertions succeeded.\n");
    }

    /**
     * Bonus - iterate the response body as a Map. Useful when the JSON shape
     * is dynamic or unknown ahead of time. Asserts that the response contains
     * EXACTLY the four expected keys (title, body, userId, id) and nothing
     * unexpected.
     */
    @Test(priority = 3,
          description = "POST /posts - iterate response as Map<String, Object>")
    public void verifyResponseShapeAsMap() {

        System.out.println("\n[TEST START] verifyResponseShapeAsMap");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(POST_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract().response();

        Assert.assertEquals(response.getStatusCode(), 201,
                "FAILED: pre-condition status code");

        Map<String, Object> all = response.jsonPath().getMap("$");

        System.out.println("Response keys       : " + all.keySet());
        System.out.println("Number of keys      : " + all.size());
        all.forEach((k, v) -> System.out.println("  " + k + " : " + v));

        // The four expected keys must all be present
        Assert.assertTrue(all.containsKey("id"),
                "FAILED: 'id' key missing from response");
        Assert.assertTrue(all.containsKey("title"),
                "FAILED: 'title' key missing from response");
        Assert.assertTrue(all.containsKey("body"),
                "FAILED: 'body' key missing from response");
        Assert.assertTrue(all.containsKey("userId"),
                "FAILED: 'userId' key missing from response");

        System.out.println("[TEST PASSED] Response contains all four expected keys.\n");
    }
}
