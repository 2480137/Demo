# JSONPlaceholder CSV Parameterization - REST Assured + TestNG

Maven-based Java project that automates the **"Data Parameterization using
CSV in Postman"** scenario using **REST Assured**, **TestNG's
`@DataProvider`**, and **OpenCSV**. The test reads test data from a CSV
file and runs the same `POST /posts` request once per row - the REST
Assured parallel of Postman's Collection Runner with a CSV data file.

## Scenario

Drive a parameterized `POST` request to:

```
https://jsonplaceholder.typicode.com/posts
```

with `title`, `body`, and `userId` values supplied by a CSV file. The
test runs **once per row** and verifies that each iteration returns
`201 Created` with the echoed fields.

## Postman → REST Assured Concept Mapping

| Postman                                        | REST Assured / TestNG equivalent                            |
|------------------------------------------------|-------------------------------------------------------------|
| Collection variables (`{{title}}`, etc.)       | `@DataProvider` supplies values to method parameters        |
| Request body templating `{{title}}`            | `String.format` / concatenation with the parameter values   |
| Collection Runner > Select File                | `getResourceAsStream("/posts_data.csv")` + OpenCSV          |
| "Iterations" count                             | Number of data rows in the CSV                              |
| Collection Runner > Preview                    | TestNG console output - one log block per iteration         |
| "Persist responses for a session"              | TestNG HTML reports under `target/surefire-reports/`        |
| Click "Run Collection"                         | `mvn test`                                                  |
| Per-iteration test result                      | Per-invocation `@Test` result in the TestNG report          |

## How TestNG @DataProvider Works

A `@DataProvider` method returns `Object[][]` - one inner array per data
row. TestNG invokes any `@Test` method with `dataProvider=` on it once per
row, passing the inner array elements as arguments:

```java
@DataProvider(name = "postsData")
public Object[][] postsData() {
    return new Object[][] {
        {"Title 1", "Body 1", 1},
        {"Title 2", "Body 2", 2},
        // ...
    };
}

@Test(dataProvider = "postsData")
public void createPost(String title, String body, int userId) {
    // runs once per row above
}
```

This project's `postsData` provider reads its rows from a CSV file at
`src/test/resources/posts_data.csv` instead of returning a hard-coded array.

## CSV File Format

The CSV's **first row** is the header and must match the expected column
names. Every subsequent row is one iteration's data:

```csv
title,body,userId
First post created via REST Assured CSV,This is the body...,1
Second post created via REST Assured CSV,Body content...,2
Third post created via REST Assured CSV,Third post body...,3
Automation in API testing,REST Assured supports data-driven testing...,4
Parameterization works for any field,Title body and user id...,5
```

5 data rows = 5 iterations of the parameterized `@Test` method.

The file lives at `src/test/resources/posts_data.csv` so it is on the
classpath at test time. To use a different CSV, edit that file or change
the `CSV_RESOURCE` constant in the test class.

## Why OpenCSV (not String.split)

A naive `line.split(",")` breaks as soon as the CSV contains:

- Quoted fields with commas inside them, e.g. `"Hello, world",something`
- Fields containing the delimiter character literally
- Escape sequences like `""` for an embedded double-quote

OpenCSV is the canonical Java CSV parser for tests - it handles all of
these correctly. The dependency is added in `pom.xml`.

## Project Structure

```
JsonPlaceholderCsvParamTest/
├── pom.xml                                              # Maven dependencies
├── testng.xml                                           # TestNG suite file
├── README.md
└── src/test/
    ├── java/com/jsonplaceholder/tests/
    │   └── JsonPlaceholderCsvParamTest.java
    └── resources/
        └── posts_data.csv                               # 5 data rows
```

## What the Test Class Does

| # | Method                              | Purpose                                                                            |
|---|-------------------------------------|------------------------------------------------------------------------------------|
| - | `postsData` (@DataProvider)         | Reads `posts_data.csv` from the classpath via OpenCSV; returns 5 rows.             |
| 1 | `createPostFromCsvRow`              | Parameterized: POST per row, asserts 201 + echoed fields, runs **5 times**.         |
| 2 | `createPostFromCsvRowFluent`        | Bonus - same iterations expressed in fluent `then().body()` style.                  |

So a single `mvn test` run dispatches **10 HTTP requests** (5 per @Test method).

## Key REST Assured / TestNG Patterns

```java
// 1. CSV-backed DataProvider
@DataProvider(name = "postsData")
public Object[][] postsData() throws Exception {
    try (CSVReader r = new CSVReader(new InputStreamReader(
                getClass().getResourceAsStream("/posts_data.csv"), UTF_8))) {
        List<String[]> rows = r.readAll();
        // skip header, convert each remaining row to {title, body, userId}
        ...
    }
}

// 2. Parameterized test method
@Test(dataProvider = "postsData")
public void createPostFromCsvRow(String title, String body, int userId) {
    String json = String.format(
        "{\"title\":\"%s\",\"body\":\"%s\",\"userId\":%d}",
        title, body, userId);

    given().header("Content-Type", "application/json")
           .body(json)
       .when().post("/posts")
       .then().statusCode(201)
              .body("title",  equalTo(title))
              .body("body",   equalTo(body))
              .body("userId", equalTo(userId));
}
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`
- **OpenCSV `5.9`** - CSV reader

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method (still iterates the CSV)

```bash
mvn clean test -Dtest=JsonPlaceholderCsvParamTest#createPostFromCsvRow
```

## Expected Output (abridged)

```
CSV columns detected: title, body, userId
Data rows loaded     : 5

[ITERATION] title="First post created via REST Assured CSV", userId=1
  Status code   : 201
  [PASSED] iteration verified, id=101

[ITERATION] title="Second post created via REST Assured CSV", userId=2
  Status code   : 201
  [PASSED] iteration verified, id=101

[ITERATION] title="Third post created via REST Assured CSV", userId=3
  Status code   : 201
  [PASSED] iteration verified, id=101

[ITERATION] title="Automation in API testing", userId=4
  Status code   : 201
  [PASSED] iteration verified, id=101

[ITERATION] title="Parameterization works for any field", userId=5
  Status code   : 201
  [PASSED] iteration verified, id=101

===============================================
Total tests run: 10, Passes: 10, Failures: 0
===============================================
```

(10 total = 5 iterations of the standard test + 5 iterations of the fluent variant.)

## Reports

After execution, TestNG / Surefire reports are generated under
`target/surefire-reports/`:

- `index.html` - top-level run summary
- `emailable-report.html` - condensed report
- Per-test result XML for CI tooling (Jenkins, GitHub Actions, etc.)

Each row of the CSV appears as its own row in these reports - the parallel
of "Persist responses for a session" in Postman.

## Notes

- JSONPlaceholder always returns `id = 101` for any POST regardless of
  the input - simulated persistence (see Hands-On 14 README for the full
  explanation). This means the `id` column of every iteration's response
  is `101`. The test asserts only that `id > 0` to avoid coupling to this
  quirk.
- To add or remove iterations, edit `src/test/resources/posts_data.csv`.
  No code changes are needed - the test re-reads the CSV on every run.
- OpenCSV handles quoted fields and embedded commas correctly, so values
  like `"Hello, world"` are safe to put in the CSV.
- If the network is unavailable, all iterations will fail with connection
  errors - this is an infrastructure issue, not a code defect.
