package com.jsonplaceholder.tests;

import com.opencsv.CSVReader;
import com.opencsv.exceptions.CsvException;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;

/**
 * Hands-On 15: Data Parameterization using CSV in Postman - automated with
 * REST Assured.
 *
 * Postman scenario (automated equivalent below):
 *   Method   : POST
 *   URL      : https://jsonplaceholder.typicode.com/posts
 *   Body     : Parameterized {{title}}, {{body}}, {{userId}}
 *   Runner   : Postman Collection Runner with CSV import + iterations
 *   Action   : Run once per CSV row, verify each iteration returns 201
 *
 * Postman -> REST Assured concept mapping:
 *   Postman concept                  | REST Assured / TestNG equivalent
 *   ---------------------------------|--------------------------------------------------
 *   {{title}}, {{body}}, {{userId}}  | Method parameters (String title, String body, ...)
 *   Collection variables             | DataProvider supplies per-iteration values
 *   CSV file imported into Runner    | CSV read by @DataProvider via OpenCSV
 *   Number of iterations             | Number of rows in the CSV (TestNG runs the @Test once per row)
 *   "Persist responses for a session"| TestNG generates HTML reports under target/surefire-reports
 *   Run Collection                   | mvn test
 *
 * Steps covered:
 *  1. Maven project with TestNG, RestAssured, and OpenCSV (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. POST to https://jsonplaceholder.typicode.com/posts.
 *  4-9. CSV file (src/test/resources/posts_data.csv) holds title, body, userId
 *       across 5 rows; @DataProvider reads it.
 *  10-14. TestNG runs the @Test method once per row (the equivalent of clicking
 *         Run Collection in Postman). Each iteration asserts 201 + the echoed
 *         fields.
 */
public class JsonPlaceholderCsvParamTest {

    private static final String BASE_URI    = "https://jsonplaceholder.typicode.com";
    private static final String ENDPOINT    = "/posts";
    private static final String CSV_RESOURCE = "/posts_data.csv";

    @BeforeClass
    public void setUp() {
        // Step 3 - Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * DataProvider that reads posts_data.csv from the classpath and returns
     * one Object[] per data row. The CSV's first row is treated as a header
     * and skipped.
     *
     * This is the REST Assured / TestNG parallel of "Select File" and
     * "Preview" in Postman's Collection Runner.
     */
    @DataProvider(name = "postsData")
    public Object[][] postsData() throws IOException, CsvException {

        InputStream in = getClass().getResourceAsStream(CSV_RESOURCE);
        if (in == null) {
            throw new IOException("CSV resource not found on classpath: "
                    + CSV_RESOURCE
                    + " (should be at src/test/resources/posts_data.csv)");
        }

        // OpenCSV handles quoted fields, embedded commas, and escapes
        // correctly - a naive String.split(",") would not.
        try (CSVReader reader = new CSVReader(
                new InputStreamReader(in, StandardCharsets.UTF_8))) {

            List<String[]> rows = reader.readAll();
            if (rows.isEmpty()) {
                throw new IOException("CSV is empty: " + CSV_RESOURCE);
            }

            // First row is the header. Skip it and convert each data row to
            // {title, body, userId}. userId is parsed to int.
            String[] header = rows.get(0);
            System.out.println("CSV columns detected: " + String.join(", ", header));

            List<Object[]> data = new ArrayList<>();
            for (int i = 1; i < rows.size(); i++) {
                String[] r = rows.get(i);
                if (r.length < 3) continue;          // skip blank or malformed rows
                String title  = r[0];
                String body   = r[1];
                int    userId = Integer.parseInt(r[2].trim());
                data.add(new Object[]{title, body, userId});
            }

            System.out.println("Data rows loaded     : " + data.size());
            return data.toArray(new Object[0][]);
        }
    }

    /**
     * Steps 10-14 - The parameterized test method. TestNG invokes it once
     * per row from the postsData provider. On each invocation, POST is
     * sent with that row's data, status 201 is asserted, and the echoed
     * fields are verified.
     */
    @Test(dataProvider = "postsData",
          description = "POST /posts with CSV-driven body - iteration per row")
    public void createPostFromCsvRow(String title, String body, int userId) {

        System.out.println("\n[ITERATION] title=\"" + title
                + "\", userId=" + userId);

        // Build the JSON body for THIS iteration. We escape any double-quotes
        // that may appear in the CSV content so the JSON stays valid.
        String json = "{\n"
                + "  \"title\":  \"" + escapeJson(title) + "\",\n"
                + "  \"body\":   \"" + escapeJson(body)  + "\",\n"
                + "  \"userId\": "   + userId            + "\n"
                + "}";

        // Send POST and extract the response (REST Assured's parallel of
        // 'Click Send' in the Postman Runner)
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(json)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();

        System.out.println("  Status code   : " + statusCode);
        System.out.println("  Response body : " + response.getBody().asString());

        // Per-iteration assertions
        Assert.assertEquals(statusCode, 201,
                "FAILED: expected 201 Created for row title=\"" + title
                        + "\" but got " + statusCode);

        // Verify echoed fields round-trip
        String  rTitle  = response.jsonPath().getString("title");
        String  rBody   = response.jsonPath().getString("body");
        Integer rUserId = response.jsonPath().getInt("userId");
        Integer rId     = response.jsonPath().getInt("id");

        Assert.assertEquals(rTitle, title,
                "FAILED: title did not round-trip for this iteration");
        Assert.assertEquals(rBody, body,
                "FAILED: body did not round-trip for this iteration");
        Assert.assertEquals(rUserId, Integer.valueOf(userId),
                "FAILED: userId did not round-trip for this iteration");
        Assert.assertNotNull(rId,
                "FAILED: response was missing 'id' field");
        Assert.assertTrue(rId > 0,
                "FAILED: 'id' should be positive, got " + rId);

        System.out.println("  [PASSED] iteration verified, id=" + rId);
    }

    /**
     * Bonus - also expose the same iteration in fluent style. This shows the
     * compact then().body(...) idiom that real-world data-driven test suites
     * tend to use.
     */
    @Test(dataProvider = "postsData",
          description = "POST /posts via DataProvider - fluent then().body() style")
    public void createPostFromCsvRowFluent(String title, String body, int userId) {

        System.out.println("\n[FLUENT ITERATION] title=\"" + title + "\"");

        String json = "{\"title\":\"" + escapeJson(title)
                    + "\",\"body\":\"" + escapeJson(body)
                    + "\",\"userId\":" + userId + "}";

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(json)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(201)
                    .body("title",  org.hamcrest.Matchers.equalTo(title))
                    .body("body",   org.hamcrest.Matchers.equalTo(body))
                    .body("userId", org.hamcrest.Matchers.equalTo(userId))
                    .body("id",     org.hamcrest.Matchers.greaterThan(0));

        System.out.println("  [FLUENT PASSED]");
    }

    /** Minimal JSON-string escaper for the values pulled out of the CSV. */
    private static String escapeJson(String raw) {
        if (raw == null) return "";
        return raw
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }
}
