# JSONPlaceholder Path Parameter - REST Assured + TestNG

Maven-based Java project that uses **REST Assured** and **TestNG** to call the
`GET /posts/{id}` endpoint of the public **JSONPlaceholder** API using a
**path parameter** (`id = 5`), retrieve the response body, parse it, and print
the values to the console.

## Scenario

Send a **GET** request to:

```
https://jsonplaceholder.typicode.com/posts/5
```

Parse the JSON response and print every field value (userId, id, title, body).

## About the Response

`GET /posts/5` returns a single post object:

```json
{
    "userId": 1,
    "id": 5,
    "title": "nesciunt quas odio",
    "body": "repudiandae veniam quaerat sunt sed alias..."
}
```

JSONPlaceholder is a fully open public API - **no authentication required**.

## Project Structure

```
JsonPlaceholderPathParamTest/
├── pom.xml                                        # Maven dependencies
├── testng.xml                                     # TestNG suite file
├── README.md
└── src/test/java/com/jsonplaceholder/tests/
    └── JsonPlaceholderPathParamTest.java
```

## What the Test Class Does

The `JsonPlaceholderPathParamTest` class contains three test methods:

| # | Method                                | Purpose                                                                                  |
|---|---------------------------------------|------------------------------------------------------------------------------------------|
| 1 | `getPostByIdAsPathParam`              | Main: GETs `/posts/{id}` with id=5 using `pathParam()`, prints every field value.        |
| 2 | `verifyResponseWithFluentStyle`       | Bonus - same response checked with REST Assured's fluent `then().body()` assertions.     |
| 3 | `demonstratePathParamVsQueryParam`    | Bonus - shows the semantic difference: `/posts/5` returns one object, `/posts?id=5` an array. |

## Key REST Assured Pattern - Path Parameters

```java
// Define a URL with a placeholder
private static final String ENDPOINT = "/posts/{id}";

// Bind a value to the placeholder, then send the request
.given()
    .pathParam("id", 5)             // {id} -> 5
.when()
    .get(ENDPOINT)                  // sends GET /posts/5
```

The placeholder is defined once in the URL string with curly braces, then
populated via `pathParam(name, value)`. RestAssured handles URL encoding so
special characters in the value are escaped automatically.

## Path Parameter vs Query Parameter

This is the most common confusion in REST API testing - here is the difference:

| Aspect              | Query Parameter                  | Path Parameter                       |
|---------------------|----------------------------------|--------------------------------------|
| URL position        | After `?`, separated by `&`      | Inside the URL path                  |
| URL syntax          | `/posts?id=5`                    | `/posts/5`                           |
| RestAssured method  | `.queryParam("id", 5)`           | `.pathParam("id", 5)`                |
| URL placeholder     | none                             | `/posts/{id}`                        |
| Typical purpose     | Filtering, pagination, sorting   | Identifying a specific resource      |
| JSONPlaceholder     | `/posts?id=5` returns an array   | `/posts/5` returns a single object   |

Both forms work for fetching post 5 on JSONPlaceholder, but they return
different shapes - this is illustrated by the bonus test
`demonstratePathParamVsQueryParam`.

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to download,
then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=JsonPlaceholderPathParamTest#getPostByIdAsPathParam
```

## Expected Output (abridged)

```
[TEST START] getPostByIdAsPathParam
Request URL    : https://jsonplaceholder.typicode.com/posts/5
Status code    : 200

--- Pretty-printed JSON response ---
{
    "userId": 1,
    "id": 5,
    "title": "nesciunt quas odio",
    "body": "repudiandae veniam quaerat sunt sed alias aut fugiat sit autem sed est..."
}

--- Individual field values ---
userId : 1
id     : 5
title  : nesciunt quas odio
body   : repudiandae veniam quaerat sunt sed alias aut fugiat sit autem sed est...

--- All fields via Map iteration ---
  userId : 1
  id : 5
  title : nesciunt quas odio
  body : repudiandae veniam quaerat sunt sed alias aut fugiat sit autem sed est...
[TEST PASSED] Response parsed and printed successfully.

[TEST START] demonstratePathParamVsQueryParam
Path-param URL : https://jsonplaceholder.typicode.com/posts/5
  Status  : 200
  Body    : {  "userId": 1, "id": 5, ... }
Query-param URL: https://jsonplaceholder.typicode.com/posts?id=5
  Status  : 200
  Body    : [ { "userId": 1, "id": 5, ... } ]    <-- note the array wrapper

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- JSONPlaceholder always returns the same data set (100 posts, ids 1-100),
  so the response for `/posts/5` is stable and deterministic.
- No authentication or API key is required.
- If the network is unavailable, all tests will fail with connection errors -
  this is an infrastructure issue, not a code defect.
