package com.jsonplaceholder.tests;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

/**
 * Hands-On: Get the API response with a path parameter in REST Assured.
 *
 * Scenario:
 *  Send a GET request to https://jsonplaceholder.typicode.com/posts/5
 *  using a path parameter (id = 5), retrieve the response body, parse it,
 *  and print the values.
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. GET request sent through RestAssured to /posts (with id appended as
 *     a path parameter).
 *  4. Path parameter 'id' set to 5 using RestAssured's pathParam().
 *  5. Response values printed to the console.
 *
 * About the response:
 *  GET /posts/5 returns a single post object:
 *      {
 *          "userId": 1,
 *          "id": 5,
 *          "title": "nesciunt quas odio",
 *          "body": "repudiandae veniam quaerat sunt sed alias..."
 *      }
 */
public class JsonPlaceholderPathParamTest {

    private static final String BASE_URI = "https://jsonplaceholder.typicode.com";
    private static final String ENDPOINT = "/posts/{id}";   // {id} is a placeholder
    private static final int    POST_ID  = 5;

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI once for the whole class
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 3 + 4 + 5 - Send GET with a path parameter, parse the response,
     * and print the values.
     *
     * Demonstrates the canonical usage of pathParam() in RestAssured:
     * a {placeholder} in the URL is replaced by the bound value at send time.
     */
    @Test(priority = 1,
          description = "GET /posts/{id} with id=5 - parse and print response values")
    public void getPostByIdAsPathParam() {

        System.out.println("\n[TEST START] getPostByIdAsPathParam");

        // Step 3 + 4 - Send GET; pathParam("id", 5) replaces {id} in the URL
        Response response = RestAssured
                .given()
                    .header("Accept", "application/json")
                    .pathParam("id", POST_ID)
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();
        System.out.println("Request URL    : " + BASE_URI + "/posts/" + POST_ID);
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("Content-Type   : " + response.getContentType());

        // Sanity check
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK but got " + statusCode);

        // Step 5a - Print the pretty-formatted body for visibility
        System.out.println("\n--- Pretty-printed JSON response ---");
        System.out.println(response.getBody().asPrettyString());

        // Step 5b - Parse with JsonPath and pull out individual values.
        // /posts/{id} returns a single post object - a flat JSON map.
        JsonPath jsonPath = response.jsonPath();

        Integer userId = jsonPath.getInt("userId");
        Integer id     = jsonPath.getInt("id");
        String  title  = jsonPath.getString("title");
        String  body   = jsonPath.getString("body");

        System.out.println("\n--- Individual field values ---");
        System.out.println("userId : " + userId);
        System.out.println("id     : " + id);
        System.out.println("title  : " + title);
        System.out.println("body   : " + body);

        // The id in the response should match the id we asked for via path param
        Assert.assertEquals(id, Integer.valueOf(POST_ID),
                "FAILED: server returned id=" + id
                        + " but we asked for id=" + POST_ID);

        // Bonus - print every field of the response as a Map (handy when the
        // schema is unknown ahead of time)
        Map<String, Object> all = jsonPath.getMap("$");
        System.out.println("\n--- All fields via Map iteration ---");
        all.forEach((k, v) -> System.out.println("  " + k + " : " + v));

        // Sanity assertions
        Assert.assertNotNull(title,    "FAILED: title was null");
        Assert.assertFalse(title.isEmpty(),
                "FAILED: title was empty");
        Assert.assertNotNull(body,     "FAILED: body was null");
        Assert.assertTrue(userId > 0,
                "FAILED: userId should be positive, got " + userId);

        System.out.println("[TEST PASSED] Response parsed and printed successfully.\n");
    }

    /**
     * Bonus - same scenario expressed in REST Assured's fluent then().body()
     * Hamcrest style for a more compact test idiom.
     */
    @Test(priority = 2,
          description = "Verify GET /posts/5 with fluent then().body() assertions")
    public void verifyResponseWithFluentStyle() {

        System.out.println("\n[TEST START] verifyResponseWithFluentStyle");

        RestAssured
                .given()
                    .pathParam("id", POST_ID)
                .when()
                    .get(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(200)
                    .contentType(org.hamcrest.Matchers.containsString("json"))
                    .body("id",     org.hamcrest.Matchers.equalTo(POST_ID))
                    .body("userId", org.hamcrest.Matchers.greaterThan(0))
                    .body("title",  org.hamcrest.Matchers.not(org.hamcrest.Matchers.emptyString()))
                    .body("body",   org.hamcrest.Matchers.not(org.hamcrest.Matchers.emptyString()));

        System.out.println("[TEST PASSED] Fluent style assertions succeeded.\n");
    }

    /**
     * Bonus - demonstrates the difference between path params and query
     * params, which is one of the most common sources of confusion in
     * REST API testing. Calling /posts?id=5 (query) returns an array,
     * calling /posts/5 (path) returns a single object.
     */
    @Test(priority = 3,
          description = "Demonstrate path-param vs query-param semantic difference")
    public void demonstratePathParamVsQueryParam() {

        System.out.println("\n[TEST START] demonstratePathParamVsQueryParam");

        // Path-param form -> single object response
        Response pathResp = RestAssured
                .given()
                    .pathParam("id", POST_ID)
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract().response();

        // Query-param form -> filtered array response (JSONPlaceholder honours
        // ?id=N as a filter on /posts and returns an array of matching posts)
        Response queryResp = RestAssured
                .given()
                    .queryParam("id", POST_ID)
                .when()
                    .get("/posts")
                .then()
                    .extract().response();

        System.out.println("Path-param URL : " + BASE_URI + "/posts/" + POST_ID);
        System.out.println("  Status  : " + pathResp.getStatusCode());
        System.out.println("  Body    : " + pathResp.getBody().asString());

        System.out.println("Query-param URL: " + BASE_URI + "/posts?id=" + POST_ID);
        System.out.println("  Status  : " + queryResp.getStatusCode());
        System.out.println("  Body    : " + queryResp.getBody().asString());

        // Path-param response is a JSON object starting with '{'
        Assert.assertTrue(pathResp.getBody().asString().trim().startsWith("{"),
                "FAILED: path-param response should be a JSON object");

        // Query-param response is a JSON array starting with '['
        Assert.assertTrue(queryResp.getBody().asString().trim().startsWith("["),
                "FAILED: query-param response should be a JSON array");

        System.out.println("[TEST PASSED] Path-param vs query-param difference demonstrated.\n");
    }
}
