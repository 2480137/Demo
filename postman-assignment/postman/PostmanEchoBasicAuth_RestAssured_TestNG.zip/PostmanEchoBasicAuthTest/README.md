# Postman Echo Basic Auth - REST Assured + TestNG

Maven-based Java project that uses **REST Assured** and **TestNG** to verify the
`GET /basic-auth` endpoint of the public **Postman Echo** API.

## Scenario

Send a **GET** request to `https://postman-echo.com/basic-auth` with HTTP **Basic
Auth** credentials (`postman` / `password`) and verify:

1. The HTTP status code is **200 OK**.
2. The response body contains `{"authenticated": true}`.
3. *(Bonus)* Sending the same request without credentials returns **401 Unauthorized**.

## Project Structure

```
PostmanEchoBasicAuthTest/
├── pom.xml                          # Maven dependencies
├── testng.xml                       # TestNG suite file
├── README.md                        # This file
└── src/
    └── test/
        └── java/
            └── com/
                └── postmanecho/
                    └── tests/
                        └── PostmanEchoBasicAuthTest.java
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection (the test calls a live public API)

## Dependencies (already declared in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven (command line)

From the project root:

```bash
mvn clean test
```

This downloads dependencies, compiles the test class, and runs the suite
defined in `testng.xml`.

### Option 2 - From IntelliJ / Eclipse

1. Open the project as a Maven project (select `pom.xml`).
2. Wait for dependencies to download.
3. Right-click `testng.xml` → **Run 'testng.xml'**, or right-click the test
   class → **Run As → TestNG Test**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=PostmanEchoBasicAuthTest#verifyStatusCodeIs200
```

## Expected Output

```
[TEST START] verifyStatusCodeIs200
Request URL    : https://postman-echo.com/basic-auth
Username       : postman
Status code    : 200
Response body  : {
                   "authenticated": true
                 }
[TEST PASSED] Status code 200 verified successfully.

[TEST START] verifyResponseBody
authenticated  : true
Content-Type   : application/json; charset=utf-8
[TEST PASSED] Response body verified successfully.

[TEST START] verifyUnauthorizedWithoutCredentials
Status code (no auth): 401
[TEST PASSED] 401 Unauthorized verified for missing credentials.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Reports

After execution, TestNG / Surefire reports are generated under:

- `target/surefire-reports/index.html`
- `target/surefire-reports/emailable-report.html`

## Notes

- Postman Echo is a free public API and requires no signup.
- The endpoint always returns the same JSON `{"authenticated": true}` for
  any successful Basic Auth call.
- If the network is unavailable, all live tests will fail with connection
  errors - this indicates an infrastructure issue, not a code defect.
