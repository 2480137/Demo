package com.postmanecho.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hands-On 1: Verify the response of the GET API.
 *
 * Scenario:
 *  Send a GET request to https://postman-echo.com/basic-auth using
 *  Basic Auth (username = postman, password = password) and verify
 *  the response.
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. GET request sent through RestAssured to
 *     https://postman-echo.com/basic-auth.
 *  4. Basic auth applied with credentials postman / password.
 *  5. Status code asserted to be 200.
 *  6. Response body asserted to contain {"authenticated": true}.
 */
public class PostmanEchoBasicAuthTest {

    private static final String BASE_URI    = "https://postman-echo.com";
    private static final String ENDPOINT    = "/basic-auth";
    private static final String USERNAME    = "postman";
    private static final String PASSWORD    = "password";
    private static final int    EXPECTED_SC = 200;

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI once for the whole class
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 5: Verifies that the basic-auth endpoint returns HTTP 200
     * when correct credentials are supplied.
     */
    @Test(priority = 1,
          description = "Verify status code 200 for GET /basic-auth with correct credentials")
    public void verifyStatusCodeIs200() {

        System.out.println("\n[TEST START] verifyStatusCodeIs200");

        Response response = RestAssured
                .given()
                    .auth().preemptive().basic(USERNAME, PASSWORD)
                    .header("Accept", "application/json")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int actualStatusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Username       : " + USERNAME);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("Status code    : " + actualStatusCode);
        System.out.println("Response body  : " + response.getBody().asPrettyString());

        // TestNG assertion - Step 5
        Assert.assertEquals(actualStatusCode, EXPECTED_SC,
                "FAILED: expected status code " + EXPECTED_SC + " but got " + actualStatusCode);

        System.out.println("[TEST PASSED] Status code 200 verified successfully.\n");
    }

    /**
     * Step 6: Verifies the response body contains {"authenticated": true}.
     */
    @Test(priority = 2,
          description = "Verify response body has authenticated:true")
    public void verifyResponseBody() {

        System.out.println("\n[TEST START] verifyResponseBody");

        Response response = RestAssured
                .given()
                    .auth().preemptive().basic(USERNAME, PASSWORD)
                    .header("Accept", "application/json")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        // Status code must still be 200 before checking body
        Assert.assertEquals(response.getStatusCode(), EXPECTED_SC,
                "Pre-condition failed: status code is not 200");

        // Pull the boolean field 'authenticated' from the JSON body
        Boolean authenticated = response.jsonPath().getBoolean("authenticated");

        System.out.println("Response body  : " + response.getBody().asPrettyString());
        System.out.println("authenticated  : " + authenticated);

        Assert.assertNotNull(authenticated,
                "FAILED: 'authenticated' field is missing from the response body");
        Assert.assertTrue(authenticated,
                "FAILED: expected 'authenticated' = true, got " + authenticated);

        // Content-Type sanity check
        String contentType = response.getContentType();
        System.out.println("Content-Type   : " + contentType);
        Assert.assertTrue(contentType != null && contentType.toLowerCase().contains("application/json"),
                "FAILED: expected JSON Content-Type, got " + contentType);

        System.out.println("[TEST PASSED] Response body verified successfully.\n");
    }

    /**
     * Negative scenario - sending a GET without credentials must return 401.
     * Demonstrates that the endpoint actually requires Basic Auth.
     */
    @Test(priority = 3,
          description = "Verify 401 Unauthorized when no credentials are sent")
    public void verifyUnauthorizedWithoutCredentials() {

        System.out.println("\n[TEST START] verifyUnauthorizedWithoutCredentials");

        Response response = RestAssured
                .given()
                    .header("Accept", "application/json")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int actualStatusCode = response.getStatusCode();
        System.out.println("Status code (no auth): " + actualStatusCode);

        Assert.assertEquals(actualStatusCode, 401,
                "FAILED: expected 401 Unauthorized when no credentials are sent, got " + actualStatusCode);

        System.out.println("[TEST PASSED] 401 Unauthorized verified for missing credentials.\n");
    }
}
