# Cookie Validation - REST Assured + TestNG

GET https://postman-echo.com/cookies/set?skill=Communication, validate the response cookies.

## Cookie API in REST Assured

```java
// Extract from response
Map<String, String> all  = response.getCookies();          // all cookies as Map
String value             = response.getCookie("skill");    // single cookie value
Cookie detailed          = response.getDetailedCookie("skill"); // attributes (domain, path, secure...)

// In-chain validation
.then()
    .cookie("skill", notNullValue())
    .cookie("skill", equalTo("Communication"))
    .cookie("skill", "Communication");  // literal value shorthand
```

## Note on Redirects

`/cookies/set` returns 302 redirect to `/cookies`. REST Assured follows redirects by default - we disable that in `@BeforeClass` so the 302 response (with the `Set-Cookie` header) is what we inspect.

```java
RestAssured.config = RestAssuredConfig.config().redirect(
    RedirectConfig.redirectConfig().followRedirects(false));
```

## Test Methods

| # | Method                       | Purpose                                                                    |
|---|------------------------------|----------------------------------------------------------------------------|
| 1 | `getCookiesAndValidate`      | Extract all + specific cookie, print, validate value, validate existence.  |
| 2 | `validateCookieInChain`      | `.cookie(name, matcher)` in-chain idiom.                                   |
| 3 | `inspectDetailedCookie`      | `getDetailedCookie()` shows domain/path/secure/httpOnly attributes.        |

## Run

```bash
mvn clean test
```
