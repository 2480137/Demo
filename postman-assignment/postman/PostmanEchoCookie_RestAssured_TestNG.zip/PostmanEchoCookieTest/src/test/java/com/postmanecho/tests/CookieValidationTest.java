package com.postmanecho.tests;

import io.restassured.RestAssured;
import io.restassured.config.RedirectConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Hands-On 20: Validate cookies in REST Assured.
 *
 * URL  : https://postman-echo.com/cookies/set?skill=Communication
 * Cookie key   : skill
 * Cookie value : Communication
 *
 * Steps:
 *  1. GET /cookies/set?skill=Communication
 *  2. Extract ALL cookies from the response and print them
 *  3. Extract the specific "skill" cookie and print it
 *  4. Validate the specific cookie value
 *  5. Validate the specific cookie EXISTS
 *
 * Note about postman-echo:
 *   /cookies/set redirects (302) to /cookies. By default REST Assured
 *   follows redirects. The cookie set by /cookies/set is sent back via
 *   Set-Cookie on the redirect response and is visible in
 *   response.getDetailedCookies() (and getCookies()) after the chain
 *   finishes. To make the cookie visible reliably we disable redirect
 *   following so the 302 itself is what we inspect.
 */
public class CookieValidationTest {

    private static final String BASE_URI = "https://postman-echo.com";
    private static final String ENDPOINT = "/cookies/set";

    private static final String COOKIE_NAME  = "skill";
    private static final String COOKIE_VALUE = "Communication";

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URI;

        // Disable automatic redirect following so the 302 response (with
        // Set-Cookie headers) is the one we validate.
        RestAssured.config = RestAssuredConfig.config().redirect(
                RedirectConfig.redirectConfig().followRedirects(false));

        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI = " + BASE_URI);
        System.out.println("Redirect following disabled so we can inspect the 302");
        System.out.println("=========================================================");
    }

    /**
     * Steps 1-7: GET /cookies/set, extract & validate cookies.
     */
    @Test(priority = 1, description = "GET /cookies/set?skill=Communication - cookies extracted, printed, validated")
    public void getCookiesAndValidate() {

        System.out.println("\n[TEST START] getCookiesAndValidate");

        // Step 3 - GET the cookies/set endpoint with the skill cookie param
        Response response = RestAssured
                .given()
                    .queryParam(COOKIE_NAME, COOKIE_VALUE)
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract().response();

        System.out.println("Request URL : " + BASE_URI + ENDPOINT
                + "?" + COOKIE_NAME + "=" + COOKIE_VALUE);
        System.out.println("Status code : " + response.getStatusCode());

        // Step 4 - Extract ALL cookies from the response, print them
        Map<String, String> allCookies = response.getCookies();
        System.out.println("\n--- ALL cookies in the response (response.getCookies()) ---");
        if (allCookies.isEmpty()) {
            System.out.println("  (no cookies)");
        } else {
            allCookies.forEach((k, v) -> System.out.println("  " + k + " : " + v));
        }

        // Step 5 - Extract a SPECIFIC cookie and print it
        String skillCookie = response.getCookie(COOKIE_NAME);
        System.out.println("\n--- Specific cookie via response.getCookie(\"" + COOKIE_NAME + "\") ---");
        System.out.println("  " + COOKIE_NAME + " = " + skillCookie);

        // Step 6 - Validate the specific cookie value
        Assert.assertEquals(skillCookie, COOKIE_VALUE,
                "FAILED: cookie '" + COOKIE_NAME + "' value mismatch - expected '"
                        + COOKIE_VALUE + "' but got '" + skillCookie + "'");
        System.out.println("Cookie value validated : '" + COOKIE_VALUE + "' == '" + skillCookie + "'");

        // Step 7 - Validate the specific cookie EXISTS
        Assert.assertTrue(allCookies.containsKey(COOKIE_NAME),
                "FAILED: cookie '" + COOKIE_NAME + "' should exist in the response");
        Assert.assertNotNull(skillCookie,
                "FAILED: cookie '" + COOKIE_NAME + "' should not be null");
        System.out.println("Cookie existence validated : '" + COOKIE_NAME + "' is present");

        System.out.println("\n[TEST PASSED] All cookie steps succeeded.\n");
    }

    /**
     * Bonus - same validation expressed in the REST Assured fluent chain
     * via .cookie(name, matcher).
     */
    @Test(priority = 2, description = "GET /cookies/set - validate cookie in chain via .cookie(name, matcher)")
    public void validateCookieInChain() {

        System.out.println("\n[TEST START] validateCookieInChain");

        RestAssured
                .given()
                    .queryParam(COOKIE_NAME, COOKIE_VALUE)
                .when()
                    .get(ENDPOINT)
                .then()
                    // exists + equals in the chain
                    .cookie(COOKIE_NAME, notNullValue())
                    .cookie(COOKIE_NAME, equalTo(COOKIE_VALUE))
                    // shorthand literal value form
                    .cookie(COOKIE_NAME, COOKIE_VALUE);

        System.out.println("[TEST PASSED] Cookie validated via .cookie(name, matcher).\n");
    }

    /**
     * Bonus - getDetailedCookie(name) returns a Cookie object with all
     * attributes (value, domain, path, expires, secure, etc.).
     */
    @Test(priority = 3, description = "GET /cookies/set - getDetailedCookie shows full attributes")
    public void inspectDetailedCookie() {

        System.out.println("\n[TEST START] inspectDetailedCookie");

        Response response = RestAssured
                .given()
                    .queryParam(COOKIE_NAME, COOKIE_VALUE)
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract().response();

        var detailed = response.getDetailedCookie(COOKIE_NAME);
        if (detailed != null) {
            System.out.println("Detailed cookie attributes for '" + COOKIE_NAME + "':");
            System.out.println("  name    : " + detailed.getName());
            System.out.println("  value   : " + detailed.getValue());
            System.out.println("  domain  : " + detailed.getDomain());
            System.out.println("  path    : " + detailed.getPath());
            System.out.println("  secure  : " + detailed.isSecured());
            System.out.println("  httpOnly: " + detailed.isHttpOnly());
        } else {
            System.out.println("(detailed cookie not available)");
        }
        System.out.println("[TEST PASSED]\n");
    }
}
