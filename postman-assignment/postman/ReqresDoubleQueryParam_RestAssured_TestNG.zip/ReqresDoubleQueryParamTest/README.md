# Reqres Double Query Parameter - REST Assured + TestNG

Maven-based Java project that uses **REST Assured** and **TestNG** to call the
`GET /api/users` endpoint of the public **reqres.in** API with **two** query
parameters (`page=2&id=5`), retrieve the response, parse it, and print the
values.

## Scenario

Send a **GET** request to:

```
https://reqres.in/api/users?page=2&id=5
```

Parse the JSON response and print every value to the console.

## IMPORTANT - Two Things to Know

### 1. reqres.in now requires an API key

Since 2024, every request to reqres.in requires an `x-api-key` header. Without
it the server responds:

```json
{ "error": "Missing API key.", "how_to_get_one": "https://reqres.in/signup" }
```

The free public test key **`reqres-free-v1`** is hardcoded in the test class
and works without any signup. If higher rate limits are required, sign up at
https://app.reqres.in to receive a personal key, then replace the constant:

```java
private static final String API_KEY = "reqres-free-v1";   // change here
```

### 2. The `id` query parameter is silently ignored on /api/users

reqres.in's list endpoint `/api/users` only honours `page` server-side. An
`id` query parameter sent against it is silently ignored - the response is the
same paginated `page=2` payload regardless of the id value. The focus of this
assignment is **how to send multiple query parameters in REST Assured**, not
server-side filtering. The test sends both parameters as the assignment
specifies and prints what comes back.

The 'correct' way to fetch a specific user by id on reqres.in is
`GET /api/users/{id}` (path parameter), which is demonstrated by the bonus
test method `getSingleUserByIdAsPathParam`.

## About the Response (page=2)

```json
{
    "page": 2,
    "per_page": 6,
    "total": 12,
    "total_pages": 2,
    "data": [
        {
            "id": 7,
            "email": "michael.lawson@reqres.in",
            "first_name": "Michael",
            "last_name": "Lawson",
            "avatar": "https://reqres.in/img/faces/7-image.jpg"
        },
        ...
    ],
    "support": { "url": "...", "text": "..." }
}
```

## Project Structure

```
ReqresDoubleQueryParamTest/
├── pom.xml                                        # Maven dependencies
├── testng.xml                                     # TestNG suite file
├── README.md
└── src/test/java/com/reqres/tests/
    └── ReqresDoubleQueryParamTest.java
```

## What the Test Class Does

The `ReqresDoubleQueryParamTest` class contains three test methods:

| # | Method                                       | Purpose                                                                                        |
|---|----------------------------------------------|------------------------------------------------------------------------------------------------|
| 1 | `getUsersWithTwoQueryParams_chainedStyle`    | Main: GETs `/api/users?page=2&id=5` using chained `.queryParam()` calls and prints every value. |
| 2 | `getUsersWithTwoQueryParams_mapStyle`        | Bonus - same request using a single `.queryParams(Map)` call.                                  |
| 3 | `getSingleUserByIdAsPathParam`               | Bonus - the 'right' way to fetch user 5 on reqres - `GET /api/users/{id}` with `pathParam()`.  |

## Two Ways to Send Multiple Query Parameters

```java
// Option A - chained queryParam calls (most common, most readable)
.given()
    .queryParam("page", 2)
    .queryParam("id",   5)
.when()
    .get("/api/users");

// Option B - single queryParams(Map) call (good for dynamic param sets)
Map<String, Object> params = new LinkedHashMap<>();
params.put("page", 2);
params.put("id",   5);

.given()
    .queryParams(params)
.when()
    .get("/api/users");
```

Both produce the same wire-level URL: `/api/users?page=2&id=5`

## Query Parameter vs Path Parameter

This is one of the most common sources of confusion in REST API testing.
RestAssured offers different methods for each:

```java
// QUERY parameter - appears after '?', no placeholder in URL
.queryParam("id", 5).get("/api/users");
//   -> GET /api/users?id=5

// PATH parameter - replaces a {placeholder} inside the URL
.pathParam("id", 5).get("/api/users/{id}");
//   -> GET /api/users/5
```

Choose based on what the API documentation says, not on personal preference.
For reqres.in, the right way to fetch a single user is the path-parameter
form.

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to download,
then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=ReqresDoubleQueryParamTest#getUsersWithTwoQueryParams_chainedStyle
```

## Expected Output (abridged)

```
[TEST START] getUsersWithTwoQueryParams_chainedStyle
Request URL    : https://reqres.in/api/users?page=2&id=5
Status code    : 200

--- Top-level pagination metadata ---
page         : 2
per_page     : 6
total        : 12
total_pages  : 2
support.url  : https://contentcaddy.io?utm_source=reqres&...
support.text : Tired of writing endless social media content?...

--- Users on page 2 (6 total) ---
  [1] id=7  email=michael.lawson@reqres.in  first_name=Michael  last_name=Lawson
  [2] id=8  email=lindsay.ferguson@reqres.in  first_name=Lindsay  last_name=Ferguson
  ...

Does user id=5 appear on page 2? false
  (server ignores the id query param on /api/users; this is not a test failure)

[TEST START] getSingleUserByIdAsPathParam
Request URL : https://reqres.in/api/users/5

--- User #5 details ---
  id : 5
  email : charles.morris@reqres.in
  first_name : Charles
  last_name : Morris
  avatar : https://reqres.in/img/faces/5-image.jpg

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- The exact field values returned by reqres.in may evolve over time, but
  the response shape is stable.
- If the test starts returning `401 Unauthorized`, the public test key may
  have been retired - sign up at https://app.reqres.in for a personal key
  and update the `API_KEY` constant.
- `429 Too Many Requests` indicates rate limiting on the public key - wait
  a minute or use a personal key.
