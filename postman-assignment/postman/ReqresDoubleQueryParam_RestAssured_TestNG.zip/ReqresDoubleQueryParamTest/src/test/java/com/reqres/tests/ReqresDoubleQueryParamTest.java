package com.reqres.tests;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Hands-On: Get the API response with double (two) query parameters in
 * REST Assured.
 *
 * Scenario:
 *  Send a GET request to https://reqres.in/api/users with TWO query
 *  parameters - page=2 and id=5 - retrieve the response body, parse it,
 *  and print the values.
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. GET request sent through RestAssured to https://reqres.in/api/users.
 *  4. Two query parameters attached: page=2 and id=5.
 *  5. Response values printed to the console.
 *
 * Important - reqres.in API key requirement:
 *  Since 2024 reqres.in requires every request to include an x-api-key
 *  header. The free public key 'reqres-free-v1' works without any signup.
 *  Replace it with a personal key from https://app.reqres.in if higher
 *  rate limits are required.
 *
 * Important - behaviour of the 'id' query parameter:
 *  /api/users only honours 'page' on the server side; an 'id' query
 *  parameter sent against the list endpoint is silently ignored. The
 *  request still goes through (the focus of this assignment is *sending*
 *  multiple query parameters in RestAssured), and the response is the
 *  same paginated page=2 result regardless of the id value. To fetch a
 *  specific user by id, the right call would be GET /api/users/{id}, not
 *  /api/users?id=...; this is illustrated by a bonus test method below.
 */
public class ReqresDoubleQueryParamTest {

    private static final String BASE_URI = "https://reqres.in";
    private static final String ENDPOINT = "/api/users";
    private static final int    PAGE_NUM = 2;
    private static final int    USER_ID  = 5;
    private static final String API_KEY  = "reqres-free-v1";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI once for the whole class
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 3 + 4 + 5 - Send GET with TWO query parameters (page=2 and id=5),
     * parse the response, and print the values.
     *
     * Demonstrates the most common way to attach multiple query params:
     * chained .queryParam(...) calls.
     */
    @Test(priority = 1,
          description = "GET /api/users?page=2&id=5 - parse and print response")
    public void getUsersWithTwoQueryParams_chainedStyle() {

        System.out.println("\n[TEST START] getUsersWithTwoQueryParams_chainedStyle");

        // Step 3 + 4 - Send GET with two query parameters via chained queryParam() calls.
        // RestAssured handles encoding and joins the params with '&' automatically.
        Response response = RestAssured
                .given()
                    .header("x-api-key", API_KEY)
                    .header("Accept", "application/json")
                    .queryParam("page", PAGE_NUM)
                    .queryParam("id",   USER_ID)
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();
        System.out.println("Request URL    : "
                + BASE_URI + ENDPOINT + "?page=" + PAGE_NUM + "&id=" + USER_ID);
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("Content-Type   : " + response.getContentType());

        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK but got " + statusCode);

        // Step 5a - Print the pretty-formatted body
        System.out.println("\n--- Pretty-printed JSON response ---");
        System.out.println(response.getBody().asPrettyString());

        // Step 5b - Parse with JsonPath and print individual values
        JsonPath jsonPath = response.jsonPath();

        Integer page        = jsonPath.getInt("page");
        Integer perPage     = jsonPath.getInt("per_page");
        Integer total       = jsonPath.getInt("total");
        Integer totalPages  = jsonPath.getInt("total_pages");
        String  supportUrl  = jsonPath.getString("support.url");
        String  supportText = jsonPath.getString("support.text");

        System.out.println("\n--- Top-level pagination metadata ---");
        System.out.println("page         : " + page);
        System.out.println("per_page     : " + perPage);
        System.out.println("total        : " + total);
        System.out.println("total_pages  : " + totalPages);
        System.out.println("support.url  : " + supportUrl);
        System.out.println("support.text : " + supportText);

        // The 'page' from the server should match what we asked for
        Assert.assertEquals(page, Integer.valueOf(PAGE_NUM),
                "FAILED: server returned page " + page
                        + " but we asked for page " + PAGE_NUM);

        // Step 5c - Print every user
        List<Map<String, Object>> users = jsonPath.getList("data");
        Assert.assertNotNull(users, "FAILED: 'data' array was missing");
        Assert.assertFalse(users.isEmpty(), "FAILED: 'data' array was empty");

        System.out.println("\n--- Users on page " + PAGE_NUM + " ("
                + users.size() + " total) ---");
        for (int i = 0; i < users.size(); i++) {
            Map<String, Object> u = users.get(i);
            System.out.println("  [" + (i + 1) + "] id="           + u.get("id")
                                +     "  email="      + u.get("email")
                                +     "  first_name=" + u.get("first_name")
                                +     "  last_name="  + u.get("last_name"));
        }

        // Note - reqres /api/users does not actually filter by 'id' on the
        // list endpoint; the response is the full page=2 page. This is
        // expected and documented in the class-level comment.
        boolean idAppearsOnPage = users.stream()
                .map(u -> ((Number) u.get("id")).intValue())
                .anyMatch(id -> id == USER_ID);
        System.out.println("\nDoes user id=" + USER_ID
                + " appear on page " + PAGE_NUM + "? " + idAppearsOnPage
                + "  (server ignores the id query param on /api/users; "
                + "this is not a test failure)");

        System.out.println("[TEST PASSED] Response parsed and printed successfully.\n");
    }

    /**
     * Bonus - same scenario, but uses .queryParams(Map) to send all
     * parameters in a single call. Useful when the parameter set is built
     * dynamically (e.g. read from a CSV or constructed in a helper method).
     */
    @Test(priority = 2,
          description = "GET /api/users with two query params using queryParams(Map)")
    public void getUsersWithTwoQueryParams_mapStyle() {

        System.out.println("\n[TEST START] getUsersWithTwoQueryParams_mapStyle");

        // Build the parameters as a Map
        Map<String, Object> params = new LinkedHashMap<>();
        params.put("page", PAGE_NUM);
        params.put("id",   USER_ID);

        Response response = RestAssured
                .given()
                    .header("x-api-key", API_KEY)
                    .queryParams(params)        // single call, multiple params
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        Assert.assertEquals(response.getStatusCode(), 200,
                "FAILED: expected 200 OK");

        System.out.println("Request URL: " + BASE_URI + ENDPOINT
                + "?page=" + PAGE_NUM + "&id=" + USER_ID);
        System.out.println("page (echoed): " + response.jsonPath().getInt("page"));
        System.out.println("data size    : " + response.jsonPath().getList("data").size());

        System.out.println("[TEST PASSED] queryParams(Map) variant succeeded.\n");
    }

    /**
     * Bonus - the 'right' way to fetch a single user by id on reqres.in is
     * GET /api/users/{id} (path parameter). This test demonstrates the
     * difference between query params and path params in RestAssured.
     */
    @Test(priority = 3,
          description = "GET /api/users/{id} - fetch a single user by id (path param)")
    public void getSingleUserByIdAsPathParam() {

        System.out.println("\n[TEST START] getSingleUserByIdAsPathParam");

        Response response = RestAssured
                .given()
                    .header("x-api-key", API_KEY)
                    .pathParam("id", USER_ID)         // {id} is a path placeholder
                .when()
                    .get("/api/users/{id}")
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();
        System.out.println("Request URL : " + BASE_URI + "/api/users/" + USER_ID);
        System.out.println("Status code : " + statusCode);

        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK for /api/users/" + USER_ID);

        // Single-user endpoint shape is { "data": { ... }, "support": {...} }
        Map<String, Object> userData = response.jsonPath().getMap("data");
        System.out.println("\n--- User #" + USER_ID + " details ---");
        userData.forEach((k, v) -> System.out.println("  " + k + " : " + v));

        // Confirm this really is the user we asked for
        Assert.assertEquals(((Number) userData.get("id")).intValue(), USER_ID,
                "FAILED: returned user id does not match requested id");

        System.out.println("[TEST PASSED] Single user fetched by path param.\n");
    }
}
