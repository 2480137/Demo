# Reqres Query Parameter - REST Assured + TestNG

Maven-based Java project that uses **REST Assured** and **TestNG** to call the
`GET /api/users` endpoint of the public **reqres.in** API with a single query
parameter (`page=2`), retrieve the response, parse it, and print the values.

## Scenario

Send a **GET** request to:

```
https://reqres.in/api/users?page=2
```

Parse the JSON response and print every value (pagination metadata, support
links, and the full list of users on page 2).

## IMPORTANT - reqres.in API Key Requirement

Since 2024, **every** request to reqres.in requires an `x-api-key` header.
Without it the server responds:

```json
{ "error": "Missing API key.", "how_to_get_one": "https://reqres.in/signup" }
```

The free public test key **`reqres-free-v1`** is hardcoded in the test class
and works without any signup. If higher rate limits are needed, sign up at
https://app.reqres.in to receive a personal key, then replace the constant:

```java
private static final String API_KEY = "reqres-free-v1";   // change here
```

## About the Response

`GET /api/users?page=2` returns a paginated JSON object:

```json
{
    "page": 2,
    "per_page": 6,
    "total": 12,
    "total_pages": 2,
    "data": [
        {
            "id": 7,
            "email": "michael.lawson@reqres.in",
            "first_name": "Michael",
            "last_name": "Lawson",
            "avatar": "https://reqres.in/img/faces/7-image.jpg"
        },
        ...
    ],
    "support": {
        "url": "...",
        "text": "..."
    }
}
```

## Project Structure

```
ReqresQueryParamTest/
├── pom.xml                          # Maven dependencies
├── testng.xml                       # TestNG suite file
├── README.md
└── src/
    └── test/
        └── java/
            └── com/
                └── reqres/
                    └── tests/
                        └── ReqresQueryParamTest.java
```

## What the Test Class Does

The `ReqresQueryParamTest` class contains three test methods:

| # | Method                              | Purpose                                                                                  |
|---|-------------------------------------|------------------------------------------------------------------------------------------|
| 1 | `getUsersWithPageQueryParam`        | Main: GETs `/api/users?page=2`, prints pagination metadata, every user, and all emails.  |
| 2 | `verifyResponseWithFluentStyle`     | Bonus - same checks expressed using REST Assured's fluent `then().body()` Hamcrest API.  |
| 3 | `verifyPageParameterAffectsResults` | Bonus - calls `?page=1` and `?page=2` and verifies the user ids differ between pages.    |

## Key REST Assured Patterns Used

```java
// 1. Add a query parameter properly
Response response = given()
        .header("x-api-key", API_KEY)
        .queryParam("page", 2)         // RestAssured handles the '?' and encoding
        .when().get("/api/users")
        .then().extract().response();

// 2. Pretty-print the body
System.out.println(response.getBody().asPrettyString());

// 3. Parse to JSON
JsonPath jsonPath = response.jsonPath();

// 4. Extract scalars
Integer page    = jsonPath.getInt("page");
Integer total   = jsonPath.getInt("total");
String  text    = jsonPath.getString("support.text");

// 5. Extract a list of maps
List<Map<String, Object>> users = jsonPath.getList("data");

// 6. Extract a single column from the array
List<String> emails = jsonPath.getList("data.email");
```

## Why use queryParam() rather than concatenating into the URL?

Both of these work, but the first one is far better:

```java
// PREFERRED - RestAssured encodes the value, handles ? / & separators
.queryParam("page", 2).get("/api/users");

// AVOID - manual stringification, no encoding, easy to misformat
.get("/api/users?page=2");
```

`queryParam()` keeps the URL clean, encodes special characters automatically,
and lets you chain multiple parameters without having to worry about
separators.

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open the project as a Maven project (select `pom.xml`), wait for dependencies
to download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=ReqresQueryParamTest#getUsersWithPageQueryParam
```

## Expected Output (abridged)

```
[TEST START] getUsersWithPageQueryParam
Status code    : 200

--- Top-level pagination metadata ---
page         : 2
per_page     : 6
total        : 12
total_pages  : 2
support.url  : https://contentcaddy.io?utm_source=reqres&...
support.text : Tired of writing endless social media content?...

--- Users on page 2 (6 total) ---
  [1] id=7  email=michael.lawson@reqres.in  first_name=Michael  last_name=Lawson
  [2] id=8  email=lindsay.ferguson@reqres.in  first_name=Lindsay  last_name=Ferguson
  [3] id=9  email=tobias.funke@reqres.in  first_name=Tobias  last_name=Funke
  [4] id=10  email=byron.fields@reqres.in  first_name=Byron  last_name=Fields
  [5] id=11  email=george.edwards@reqres.in  first_name=George  last_name=Edwards
  [6] id=12  email=rachel.howell@reqres.in  first_name=Rachel  last_name=Howell

--- All emails extracted via JsonPath ---
  michael.lawson@reqres.in
  lindsay.ferguson@reqres.in
  tobias.funke@reqres.in
  byron.fields@reqres.in
  george.edwards@reqres.in
  rachel.howell@reqres.in
[TEST PASSED] Response parsed and printed successfully.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- The exact field values returned by reqres.in may evolve over time, but
  the response shape (page / per_page / total / total_pages / data / support)
  is stable.
- If the test starts returning 401 unauthorized, the public test key may have
  been retired - sign up at https://app.reqres.in to obtain a personal key
  and update the `API_KEY` constant.
- If you hit `429 Too Many Requests`, the public key has rate limits - wait
  a minute and re-run, or use a personal key.
