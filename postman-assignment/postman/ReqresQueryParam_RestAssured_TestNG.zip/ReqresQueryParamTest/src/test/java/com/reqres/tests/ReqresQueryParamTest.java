package com.reqres.tests;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

/**
 * Hands-On: Get the API response with a single query parameter in REST Assured.
 *
 * Scenario:
 *  Send a GET request to https://reqres.in/api/users with query parameter
 *  page=2, retrieve the response body, parse it, and print the values.
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. GET request sent through RestAssured to https://reqres.in/api/users.
 *  4. Query parameter 'page' set to 2 using RestAssured's queryParam().
 *  5. Response values printed to the console.
 *
 * Important - reqres.in API key requirement:
 *  Since 2024 reqres.in requires every request to include an x-api-key header.
 *  The free public key 'reqres-free-v1' works without any signup. The test
 *  reads the key from the API_KEY constant below; replace it with a personal
 *  key from https://app.reqres.in if higher rate limits are required.
 *
 * About the response:
 *  Response shape:
 *      {
 *          "page": 2,
 *          "per_page": 6,
 *          "total": 12,
 *          "total_pages": 2,
 *          "data": [
 *              { "id": 7, "email": "...", "first_name": "...", ... },
 *              ...
 *          ],
 *          "support": { "url": "...", "text": "..." }
 *      }
 */
public class ReqresQueryParamTest {

    private static final String BASE_URI = "https://reqres.in";
    private static final String ENDPOINT = "/api/users";
    private static final int    PAGE_NUM = 2;
    private static final String API_KEY  = "reqres-free-v1";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI once for the whole class
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 3 + 4 + 5 - Send GET with page=2 query parameter, parse the
     * response, and print the values.
     */
    @Test(priority = 1,
          description = "GET /api/users?page=2 - parse response and print all values")
    public void getUsersWithPageQueryParam() {

        System.out.println("\n[TEST START] getUsersWithPageQueryParam");

        // Step 3 + 4 - Send GET request through RestAssured.
        // Note: queryParam() is the canonical way to attach a query string -
        // RestAssured handles the encoding and the '?' / '&' separators for us.
        Response response = RestAssured
                .given()
                    .header("x-api-key", API_KEY)
                    .header("Accept", "application/json")
                    .queryParam("page", PAGE_NUM)
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();
        System.out.println("Request URL    : " + BASE_URI + ENDPOINT + "?page=" + PAGE_NUM);
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("Content-Type   : " + response.getContentType());

        // Sanity check
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK but got " + statusCode);

        // Step 5a - Print the pretty-formatted body for visibility
        System.out.println("\n--- Pretty-printed JSON response ---");
        System.out.println(response.getBody().asPrettyString());

        // Step 5b - Parse into JsonPath and pull out individual values
        JsonPath jsonPath = response.jsonPath();

        Integer page        = jsonPath.getInt("page");
        Integer perPage     = jsonPath.getInt("per_page");
        Integer total       = jsonPath.getInt("total");
        Integer totalPages  = jsonPath.getInt("total_pages");
        String  supportUrl  = jsonPath.getString("support.url");
        String  supportText = jsonPath.getString("support.text");

        System.out.println("\n--- Top-level pagination metadata ---");
        System.out.println("page         : " + page);
        System.out.println("per_page     : " + perPage);
        System.out.println("total        : " + total);
        System.out.println("total_pages  : " + totalPages);
        System.out.println("support.url  : " + supportUrl);
        System.out.println("support.text : " + supportText);

        // Verify the query parameter actually took effect on the server
        Assert.assertEquals(page, Integer.valueOf(PAGE_NUM),
                "FAILED: server returned page " + page
                        + " but we asked for page " + PAGE_NUM);

        // Step 5c - Iterate the data array and print every user
        List<Map<String, Object>> users = jsonPath.getList("data");
        Assert.assertNotNull(users, "FAILED: 'data' array was missing");
        Assert.assertFalse(users.isEmpty(),
                "FAILED: 'data' array was empty");

        System.out.println("\n--- Users on page " + PAGE_NUM + " (" + users.size() + " total) ---");
        for (int i = 0; i < users.size(); i++) {
            Map<String, Object> u = users.get(i);
            System.out.println("  [" + (i + 1) + "] id="          + u.get("id")
                                +    "  email="     + u.get("email")
                                +    "  first_name=" + u.get("first_name")
                                +    "  last_name=" + u.get("last_name"));
        }

        // Bonus - extract just one column using JsonPath's GPath syntax
        List<String> emails = jsonPath.getList("data.email");
        System.out.println("\n--- All emails extracted via JsonPath ---");
        emails.forEach(e -> System.out.println("  " + e));

        // The size of users[] must match per_page
        Assert.assertEquals(users.size(), perPage.intValue(),
                "FAILED: data array length (" + users.size()
                        + ") does not equal per_page (" + perPage + ")");

        System.out.println("[TEST PASSED] Response parsed and printed successfully.\n");
    }

    /**
     * Bonus - same scenario expressed using REST Assured's fluent
     * then().body() Hamcrest assertions for a more compact test idiom.
     */
    @Test(priority = 2,
          description = "Verify page=2 response with fluent then().body() assertions")
    public void verifyResponseWithFluentStyle() {

        System.out.println("\n[TEST START] verifyResponseWithFluentStyle");

        RestAssured
                .given()
                    .header("x-api-key", API_KEY)
                    .queryParam("page", PAGE_NUM)
                .when()
                    .get(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(200)
                    .contentType(org.hamcrest.Matchers.containsString("json"))
                    .body("page",       org.hamcrest.Matchers.equalTo(PAGE_NUM))
                    .body("data",       org.hamcrest.Matchers.not(org.hamcrest.Matchers.empty()))
                    .body("data.email", org.hamcrest.Matchers.everyItem(
                            org.hamcrest.Matchers.containsString("@")));

        System.out.println("[TEST PASSED] Fluent style assertions succeeded.\n");
    }

    /**
     * Bonus - demonstrates that switching the page parameter actually changes
     * the data set returned by the server. Sends two requests (page=1 and
     * page=2) and confirms that the user ids differ.
     */
    @Test(priority = 3,
          description = "Verify the page query parameter actually changes the result set")
    public void verifyPageParameterAffectsResults() {

        System.out.println("\n[TEST START] verifyPageParameterAffectsResults");

        List<Integer> page1Ids = RestAssured
                .given()
                    .header("x-api-key", API_KEY)
                    .queryParam("page", 1)
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract().jsonPath().getList("data.id");

        List<Integer> page2Ids = RestAssured
                .given()
                    .header("x-api-key", API_KEY)
                    .queryParam("page", 2)
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract().jsonPath().getList("data.id");

        System.out.println("Page 1 ids: " + page1Ids);
        System.out.println("Page 2 ids: " + page2Ids);

        Assert.assertNotEquals(page1Ids, page2Ids,
                "FAILED: page=1 and page=2 returned the same ids - the query param is not taking effect");

        System.out.println("[TEST PASSED] Page parameter influences results.\n");
    }
}
