# Add Product Status Code 200 - REST Assured + TestNG

Maven-based Java project that automates the **"Verify the success status
code 200 for Add Product details request"** scenario using **REST Assured**
and **TestNG**. The test sends a POST request to `api.restful-api.dev`'s
`/objects` endpoint with the supplied MacBook Pro JSON body and verifies
the response status code is **200 OK** using a TestNG assertion.

## Scenario

Send a **POST** request to:

```
https://api.restful-api.dev/objects
```

with the following body, and assert the response status code is **200**:

```json
{
    "name": "Apple MacBook Pro 16",
    "data": {
        "year": 2019,
        "price": 1849.99,
        "CPU model": "Intel Core i9",
        "Hard disk size": "1 TB"
    }
}
```

## IMPORTANT - api.restful-api.dev quirks

Three API behaviours documented and handled by the tests:

### 1. POST returns 200, not 201

REST conventions suggest `201 Created` for resource creation. This API
returns `200 OK` instead. This is documented behaviour - the assignment
specifies status code 200 to match. A naive test asserting `statusCode(201)`
would always fail.

### 2. The `id` field is a STRING, not an integer

```json
{ "id": "ff80818193f43c4a0193f43c4b6a0001", ... }
```

Use `jsonPath().getString("id")` - `getInt("id")` would throw a parse error.

### 3. The response includes a `createdAt` timestamp

The response is **bigger** than the request - the server adds `id` and
`createdAt` on top of what was sent. The test verifies all of these.

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request                           | New `@Test` method                                   |
| Set the method to POST                      | `given().when().post(ENDPOINT)`                      |
| Set the URL                                 | `RestAssured.baseURI` + endpoint path                |
| Set raw JSON body                           | `given().body(BODY)`                                 |
| (No auth needed)                            | (no Authorization header)                            |
| Click Send                                  | Execution of the `@Test` method                      |
| Verify status code in Tests tab             | `Assert.assertEquals(response.getStatusCode(), 200)` |

## About the Response

```json
{
    "id":   "ff80818193f43c4a0193f43c4b6a0001",
    "name": "Apple MacBook Pro 16",
    "data": {
        "year": 2019,
        "price": 1849.99,
        "CPU model": "Intel Core i9",
        "Hard disk size": "1 TB"
    },
    "createdAt": "2026-05-03T11:30:42.986Z"
}
```

## Project Structure

```
RestfulApiDevAddProduct200Test/
├── pom.xml                                       # Maven dependencies
├── testng.xml                                    # TestNG suite file
├── README.md
└── src/test/java/com/restfulapidev/tests/
    └── AddProductStatusCode200Test.java
```

## What the Test Class Does

| # | Method                              | Purpose                                                                       |
|---|-------------------------------------|-------------------------------------------------------------------------------|
| 1 | `addProductAndVerifyStatusCode200`  | Main: POST the body, prints response, asserts 200 with TestNG `Assert`.       |
| 2 | `addProductFluentStyle`             | Bonus - same 200 assertion in REST Assured's fluent matcher style.            |
| 3 | `addProductVerifyResponseBody`      | Bonus - verifies status 200 AND every response field (id, echoed data, createdAt). |

## Key REST Assured Patterns

```java
// 1. Send POST with JSON body, no auth needed
Response response = given()
        .header("Content-Type", "application/json")
        .body(BODY)
    .when()
        .post("/objects")
    .then()
        .extract().response();

// 2. TestNG assertion for the status code (the assignment's specific ask)
Assert.assertEquals(response.getStatusCode(), 200);

// 3. Bonus - extract response fields. Note the syntax for keys with spaces.
String id       = response.jsonPath().getString("id");          // STRING, not int
String cpuModel = response.jsonPath().getString("data.\"CPU model\"");
String hdSize   = response.jsonPath().getString("data.\"Hard disk size\"");
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=AddProductStatusCode200Test#addProductAndVerifyStatusCode200
```

## Expected Output (abridged)

```
[TEST START] addProductAndVerifyStatusCode200
Request URL    : https://api.restful-api.dev/objects
Method         : POST
Status code    : 200
Response time  : 412 ms

--- Pretty-printed response body ---
{
    "id": "ff80818193f43c4a0193f43c4b6a0001",
    "name": "Apple MacBook Pro 16",
    "data": {
        "year": 2019,
        "price": 1849.99,
        "CPU model": "Intel Core i9",
        "Hard disk size": "1 TB"
    },
    "createdAt": "2026-05-03T11:30:42.986Z"
}
[TEST PASSED] Status code 200 verified for Add Product request.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- **Public API rate limit**: The public endpoints on api.restful-api.dev
  allow 50 requests per day per user. If a `429 Too Many Requests` is hit,
  wait 24 hours or sign up for an authenticated account.
- Each successful POST creates a new persistent record (with a new `id`),
  so the id will differ on every test run.
- No authentication or API key is required for the public `/objects`
  endpoint used in this assignment.
- If the network is unavailable, all tests will fail with connection errors
  - this is an infrastructure issue, not a code defect.
