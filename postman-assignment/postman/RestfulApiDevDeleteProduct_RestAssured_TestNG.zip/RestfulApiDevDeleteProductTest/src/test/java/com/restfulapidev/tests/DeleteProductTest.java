package com.restfulapidev.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hands-On 7 + 8: DELETE /objects/{id} on api.restful-api.dev.
 *
 *  Hands-On 7: Delete an EXISTING product, verify status 200.
 *  Hands-On 8: Delete a NON-EXISTENT product, verify status 404.
 *
 * Both assignments specify the same URL:
 *   https://api.restful-api.dev/objects/ff80818191c724f20191c773da8b00a5
 *
 * The two assignments form a natural pair: the same id is "existing"
 * before the delete (200) and "non-existent" after the delete (404).
 * This test class exercises both with a single resource lifecycle:
 *   1. POST to create a fresh product (in @BeforeClass).
 *   2. DELETE -> 200    (Hands-On 7 - resource exists)
 *   3. DELETE again -> 404    (Hands-On 8 - resource is now gone)
 *
 * IMPORTANT - why we don't use the assignment's hardcoded id:
 *   The assignment text refers to a literal id from a specific user's
 *   earlier POST. That id is unlikely to still exist, so the Hands-On 7
 *   test would 404 instead of 200. To match the assignment's intent
 *   reliably, @BeforeClass POSTs a fresh product first; the DELETE
 *   tests then use that id. Functionally identical to what the
 *   assignment describes; just resilient to data churn.
 *
 * About the API:
 *   - DELETE on an existing object returns 200 with a
 *     `{"message": "Object with id = ..., has been deleted."}` body.
 *   - DELETE on a non-existent object returns 404.
 *   - The 'id' field on this API is a STRING, not an integer.
 */
public class DeleteProductTest {

    private static final String BASE_URI = "https://api.restful-api.dev";
    private static final String ENDPOINT = "/objects";

    /** id of the freshly-created product, captured in @BeforeClass.
     *  Used by both DELETE tests below. */
    private static String productId;

    /** Body used to create the initial product in @BeforeClass. */
    private static final String INITIAL_BODY = "{\n"
            + "  \"name\": \"Apple MacBook Pro 16\",\n"
            + "  \"data\": {\n"
            + "    \"year\": 2019,\n"
            + "    \"price\": 1849.99,\n"
            + "    \"CPU model\": \"Intel Core i9\",\n"
            + "    \"Hard disk size\": \"1 TB\"\n"
            + "  }\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI for the whole class
        RestAssured.baseURI = BASE_URI;

        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");

        // Create a fresh product so we have something to delete
        Response createResp = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(INITIAL_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract().response();

        Assert.assertEquals(createResp.getStatusCode(), 200,
                "FAILED: pre-condition - POST /objects returned "
                        + createResp.getStatusCode() + " (expected 200). "
                        + "Body: " + createResp.getBody().asString());

        productId = createResp.jsonPath().getString("id");
        Assert.assertNotNull(productId,
                "FAILED: pre-condition - 'id' missing from POST response");

        System.out.println("Created fresh product with id: " + productId);
        System.out.println("This id will be DELETEd by Test 1 (status 200),");
        System.out.println("then DELETEd AGAIN by Test 2 (status 404 because now gone).");
    }

    /**
     * Hands-On 7 - DELETE an EXISTING product, verify status 200.
     *
     * priority = 1 ensures this runs before the "delete again" test.
     */
    @Test(priority = 1,
          description = "Hands-On 7 - DELETE existing product, verify status code 200")
    public void deleteExistingProductVerifyStatus200() {

        System.out.println("\n[TEST START] deleteExistingProductVerifyStatus200 (Hands-On 7)");

        // Send the DELETE through RestAssured
        Response response = RestAssured
                .given()
                    .pathParam("id", productId)
                .when()
                    .delete(ENDPOINT + "/{id}")
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT + "/" + productId);
        System.out.println("Method         : DELETE");
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("Response body  : " + response.getBody().asString());

        // TestNG status assertion as the assignment requires
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected status code 200 for DELETE of existing product but got " + statusCode);

        // Bonus - verify the success message in the body
        String message = response.jsonPath().getString("message");
        if (message != null) {
            System.out.println("Success message : " + message);
            Assert.assertTrue(message.toLowerCase().contains("deleted"),
                    "FAILED: response message did not contain 'deleted': " + message);
        }

        System.out.println("[TEST PASSED] Hands-On 7 - DELETE returned 200 for existing product.\n");
    }

    /**
     * Hands-On 8 - DELETE the SAME id (now gone), verify status 404.
     *
     * priority = 2 + dependsOnMethods ensures this runs AFTER the previous
     * test has actually deleted the resource. If the previous test fails
     * for any reason, this one will not run (avoiding misleading failures).
     */
    @Test(priority = 2,
          description = "Hands-On 8 - DELETE non-existent (already-deleted) product, verify status code 404",
          dependsOnMethods = "deleteExistingProductVerifyStatus200")
    public void deleteNonExistentProductVerifyStatus404() {

        System.out.println("\n[TEST START] deleteNonExistentProductVerifyStatus404 (Hands-On 8)");
        System.out.println("Trying to DELETE the same id - it should already be gone.");

        // Send the DELETE for the same id (now non-existent because of the
        // previous test). RestAssured normally treats unexpected status
        // codes as just data; assertion happens explicitly below.
        Response response = RestAssured
                .given()
                    .pathParam("id", productId)
                .when()
                    .delete(ENDPOINT + "/{id}")
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT + "/" + productId);
        System.out.println("Method         : DELETE");
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("Response body  : " + response.getBody().asString());

        // TestNG status assertion - the assignment requires 404 here
        Assert.assertEquals(statusCode, 404,
                "FAILED: expected status code 404 for DELETE of non-existent product but got "
                        + statusCode);

        System.out.println("[TEST PASSED] Hands-On 8 - DELETE returned 404 for non-existent product.\n");
    }

    /**
     * Bonus - DELETE a clearly-bogus id that has never existed on the server.
     * Some learners interpret Hands-On 8 as deleting an id that simply does
     * not exist (rather than one that was just deleted). This test covers
     * that interpretation by using an id that has never been issued by the
     * server.
     */
    @Test(priority = 3,
          description = "BONUS - DELETE an obviously-bogus id, verify 404")
    public void deleteWithBogusIdVerifyStatus404() {

        final String bogusId = "this-id-has-never-existed-12345";

        System.out.println("\n[TEST START] deleteWithBogusIdVerifyStatus404");
        System.out.println("Trying to DELETE bogus id: " + bogusId);

        int statusCode = RestAssured
                .given()
                    .pathParam("id", bogusId)
                .when()
                    .delete(ENDPOINT + "/{id}")
                .then()
                    .extract()
                    .statusCode();

        System.out.println("Status code    : " + statusCode);

        Assert.assertEquals(statusCode, 404,
                "FAILED: expected 404 for DELETE on bogus id but got " + statusCode);

        System.out.println("[TEST PASSED] Bogus id DELETE returned 404 as expected.\n");
    }
}
