# Print Add Product Success Response - REST Assured + TestNG

Maven-based Java project that automates the **"Print the success response
for Add Product details request"** scenario using **REST Assured** and
**TestNG**. The test sends a POST to `api.restful-api.dev`'s `/objects`
endpoint with a Dell i5 product body, and demonstrates the **full range
of REST Assured techniques for printing/inspecting a response**.

## Scenario

Send a **POST** request to:

```
https://api.restful-api.dev/objects
```

with the following body:

```json
{
    "name": "Dell I5",
    "data": {
        "year": 2023,
        "price": 20000,
        "CPU model": "Intel Core i9",
        "Hard disk size": "2 TB"
    }
}
```

…and **print** the success response in multiple formats.

## Five Ways REST Assured Can Print a Response

This project demonstrates each:

| # | Technique                                 | When to use                                                    |
|---|-------------------------------------------|----------------------------------------------------------------|
| 1 | `response.getBody().asString()`           | Raw JSON, single line - useful for piping/logging.             |
| 2 | `response.getBody().asPrettyString()`     | Indented JSON - human-readable, multi-line.                    |
| 3 | `response.prettyPrint()`                  | Prints to stdout AND returns the formatted body.               |
| 4 | `.log().all()` inside `.then()`           | One-liner inside the chain - dumps status + headers + body.    |
| 5 | `response.jsonPath().getXxx("path")`      | Extract individual fields by name.                             |

## API Quirks Documented

- **POST returns 200**, not 201. The assignment matches actual API behaviour.
- **`id` is a STRING**, not an integer (e.g. `"ff80818193..."`).
- **Response includes `createdAt`** - server adds this on top of the echoed body.

(See the previous Hands-On 1 README for the full discussion of these.)

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                               |
|---------------------------------------------|-------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                            |
| Add a new request                           | New `@Test` method                                    |
| Set the method to POST                      | `given().when().post(ENDPOINT)`                       |
| Set the URL                                 | `RestAssured.baseURI` + endpoint path                 |
| Set raw JSON body                           | `given().body(BODY)`                                  |
| Click Send → see response in Body panel     | One of the five printing techniques above             |
| Inspect headers in Headers tab              | `response.getHeaders()` iteration                     |
| Inspect status code/time at the bottom      | `response.getStatusCode()` / `response.getTime()`     |

## Project Structure

```
RestfulApiDevPrintResponseTest/
├── pom.xml                                        # Maven dependencies
├── testng.xml                                     # TestNG suite file
├── README.md
└── src/test/java/com/restfulapidev/tests/
    └── PrintAddProductResponseTest.java
```

## What the Test Class Does

| # | Method                                | Purpose                                                                            |
|---|---------------------------------------|------------------------------------------------------------------------------------|
| 1 | `addProductAndPrintResponse`          | Main: POST + comprehensive printing - 7 separate views of the response.            |
| 2 | `addProductPrintWithLogAll`           | Bonus - REST Assured's one-liner `.log().all()` printer.                           |
| 3 | `addProductPrintWithPrettyPrint`      | Bonus - `response.prettyPrint()` - prints AND returns the body in one call.        |

The first method demonstrates **seven** distinct printing views in sequence:
status metadata, raw body, pretty body, individual fields via JsonPath,
top-level Map iteration, nested data Map iteration, and full response headers.

## Key REST Assured Patterns

```java
// Send POST and capture response
Response response = given()
        .header("Content-Type", "application/json")
        .body(BODY)
    .when()
        .post("/objects")
    .then()
        .extract().response();

// Print in different ways:
System.out.println(response.getBody().asString());          // raw
System.out.println(response.getBody().asPrettyString());    // pretty
response.prettyPrint();                                     // prints AND returns

// Print metadata
System.out.println(response.getStatusLine());
System.out.println(response.getContentType());
System.out.println(response.getTime() + " ms");

// Print headers
for (Header h : response.getHeaders()) {
    System.out.println(h.getName() + ": " + h.getValue());
}

// Print individual fields
String name = response.jsonPath().getString("name");
String cpu  = response.jsonPath().getString("data.\"CPU model\"");

// Print as a Map
response.jsonPath().getMap("$").forEach(
    (k, v) -> System.out.println(k + " : " + v));

// One-liner inside the chain
given().body(BODY)
   .when().post("/objects")
   .then().log().all()             // status + headers + body all printed
          .statusCode(200);
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=PrintAddProductResponseTest#addProductAndPrintResponse
```

## Expected Output (abridged)

```
[TEST START] addProductAndPrintResponse

--- Status line and metadata ---
URL              : https://api.restful-api.dev/objects
HTTP method      : POST
Status code      : 200
Status line      : HTTP/1.1 200 OK
Content-Type     : application/json; charset=utf-8
Response time    : 412 ms
Response size    : 220 chars

--- Raw response body (single line) ---
{"id":"ff80818193f43c4a0193f43c4b6a0001","name":"Dell I5","data":{...},"createdAt":"..."}

--- Pretty-printed JSON body ---
{
    "id": "ff80818193f43c4a0193f43c4b6a0001",
    "name": "Dell I5",
    "data": {
        "year": 2023,
        "price": 20000,
        "CPU model": "Intel Core i9",
        "Hard disk size": "2 TB"
    },
    "createdAt": "2026-05-03T11:36:42.986Z"
}

--- Individual fields via JsonPath ---
id              : ff80818193f43c4a0193f43c4b6a0001    (server-assigned string)
name            : Dell I5
data.year       : 2023
data.price      : 20000
data.CPU model  : Intel Core i9
data.Hard disk size : 2 TB
createdAt       : 2026-05-03T11:36:42.986Z

--- All top-level keys via Map iteration ---
  id : ff80818193f43c4a0193f43c4b6a0001
  name : Dell I5
  data : {year=2023, price=20000, CPU model=Intel Core i9, Hard disk size=2 TB}
  createdAt : 2026-05-03T11:36:42.986Z

--- All 'data' sub-object keys via Map iteration ---
  year : 2023
  price : 20000
  CPU model : Intel Core i9
  Hard disk size : 2 TB

--- All response headers ---
  Date: ...
  Content-Type: application/json; charset=utf-8
  Content-Length: 220
  Connection: keep-alive
  ...

[TEST PASSED] Success response printed in multiple formats.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- This builds on the previous Hands-On 1 (Verify Status 200). The body and
  expected printing techniques are different, but the underlying API call
  is the same.
- **Public API rate limit**: 50 requests per day per user. Three test
  methods = 3 POSTs per `mvn test` run.
- Each successful POST creates a new persistent record (with a new `id`),
  so the id will differ on every run.
- No authentication or API key is required for the public `/objects`
  endpoint.
