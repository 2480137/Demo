package com.restfulapidev.tests;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

/**
 * Hands-On 2: Print the success response for Add Product details request -
 * automated with REST Assured.
 *
 * Scenario:
 *   Method   : POST
 *   URL      : https://api.restful-api.dev/objects
 *   Auth     : none (public endpoint)
 *   Body     : { "name": "Dell I5",
 *                "data": { "year": 2023, "price": 20000,
 *                          "CPU model": "Intel Core i9",
 *                          "Hard disk size": "2 TB" } }
 *   Goal     : Send the POST and PRINT the success response in detail.
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. The given JSON used as the request body (BODY constant below).
 *  4. POST sent through RestAssured to https://api.restful-api.dev/objects.
 *  5. Multiple ways to PRINT the success response are demonstrated -
 *     pretty-printed JSON, individual fields, full headers, status line,
 *     timing, and field iteration via Map.
 *
 * About the API:
 *  api.restful-api.dev returns 200 OK for a successful POST /objects (NOT
 *  201 Created). Response shape:
 *    {
 *      "id": "<server-assigned string id>",
 *      "name": "...",
 *      "data": { ... },
 *      "createdAt": "<ISO 8601 timestamp>"
 *    }
 *
 * Five ways REST Assured can print/inspect a response:
 *  1. response.getBody().asString()        - raw JSON, single line
 *  2. response.getBody().asPrettyString()  - JSON with indentation
 *  3. response.prettyPrint()               - prints AND returns the body
 *  4. .log().all() inside .then()          - prints request + response
 *  5. response.jsonPath().getXxx("path")   - extract individual fields
 */
public class PrintAddProductResponseTest {

    private static final String BASE_URI = "https://api.restful-api.dev";
    private static final String ENDPOINT = "/objects";

    /** Step 3 - The exact JSON body specified in the assignment. */
    private static final String BODY = "{\n"
            + "  \"name\": \"Dell I5\",\n"
            + "  \"data\": {\n"
            + "    \"year\": 2023,\n"
            + "    \"price\": 20000,\n"
            + "    \"CPU model\": \"Intel Core i9\",\n"
            + "    \"Hard disk size\": \"2 TB\"\n"
            + "  }\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI for the whole class
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Steps 4-5 - Send POST /objects and PRINT every aspect of the success
     * response. Demonstrates the full repertoire of REST Assured printing.
     */
    @Test(priority = 1,
          description = "POST /objects - send Add Product body and PRINT the success response in detail")
    public void addProductAndPrintResponse() {

        System.out.println("\n[TEST START] addProductAndPrintResponse");

        // Step 4 - Send the POST through RestAssured
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract()
                    .response();

        // Sanity check that we actually got a success
        int statusCode = response.getStatusCode();
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK but got " + statusCode);

        // ============== Step 5 - PRINT the response in multiple ways =============

        // (a) Status line + metadata
        System.out.println("\n--- Status line and metadata ---");
        System.out.println("URL              : " + BASE_URI + ENDPOINT);
        System.out.println("HTTP method      : POST");
        System.out.println("Status code      : " + statusCode);
        System.out.println("Status line      : " + response.getStatusLine());
        System.out.println("Content-Type     : " + response.getContentType());
        System.out.println("Response time    : " + response.getTime() + " ms");
        System.out.println("Response size    : " + response.getBody().asString().length() + " chars");

        // (b) Raw response body (single line - useful when piping to grep/jq)
        System.out.println("\n--- Raw response body (single line) ---");
        System.out.println(response.getBody().asString());

        // (c) Pretty-printed JSON body (multi-line indented - readable)
        System.out.println("\n--- Pretty-printed JSON body ---");
        System.out.println(response.getBody().asPrettyString());

        // (d) Individual fields extracted via JsonPath. Note that 'id' is a
        //     STRING on this API, and the keys "CPU model" and "Hard disk
        //     size" contain spaces (escaped via "..." inside the path).
        System.out.println("\n--- Individual fields via JsonPath ---");
        String  id        = response.jsonPath().getString("id");
        String  name      = response.jsonPath().getString("name");
        Integer year      = response.jsonPath().getInt("data.year");
        Integer price     = response.jsonPath().getInt("data.price");
        String  cpuModel  = response.jsonPath().getString("data.\"CPU model\"");
        String  hdSize    = response.jsonPath().getString("data.\"Hard disk size\"");
        String  createdAt = response.jsonPath().getString("createdAt");

        System.out.println("id              : " + id      + "    (server-assigned string)");
        System.out.println("name            : " + name);
        System.out.println("data.year       : " + year);
        System.out.println("data.price      : " + price);
        System.out.println("data.CPU model  : " + cpuModel);
        System.out.println("data.Hard disk size : " + hdSize);
        System.out.println("createdAt       : " + createdAt);

        // (e) Iterate the entire response as a Map (great for unknown shapes)
        System.out.println("\n--- All top-level keys via Map iteration ---");
        Map<String, Object> all = response.jsonPath().getMap("$");
        all.forEach((k, v) -> System.out.println("  " + k + " : " + v));

        // (f) Iterate the nested data object
        System.out.println("\n--- All 'data' sub-object keys via Map iteration ---");
        Map<String, Object> data = response.jsonPath().getMap("data");
        data.forEach((k, v) -> System.out.println("  " + k + " : " + v));

        // (g) Print all response headers
        System.out.println("\n--- All response headers ---");
        for (Header h : response.getHeaders()) {
            System.out.println("  " + h.getName() + ": " + h.getValue());
        }

        // Final sanity assertions on the printed values
        Assert.assertNotNull(id,       "FAILED: 'id' missing from response");
        Assert.assertEquals(name, "Dell I5", "FAILED: name did not round-trip");
        Assert.assertEquals(year, Integer.valueOf(2023), "FAILED: year did not round-trip");
        Assert.assertEquals(price, Integer.valueOf(20000), "FAILED: price did not round-trip");

        System.out.println("\n[TEST PASSED] Success response printed in multiple formats.\n");
    }

    /**
     * Bonus - the simplest one-liner way to print a success response in
     * REST Assured: log().all() inside the .then() block. This dumps both
     * the response and its headers/status to stdout in one shot, and is
     * the idiom most often seen in real test code for ad-hoc debugging.
     */
    @Test(priority = 2,
          description = "POST /objects - print response using REST Assured's built-in log().all()")
    public void addProductPrintWithLogAll() {

        System.out.println("\n[TEST START] addProductPrintWithLogAll");
        System.out.println("Using REST Assured's built-in .log().all() printer:\n");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .log().all()                  // prints status + headers + body
                    .assertThat()
                    .statusCode(200);

        System.out.println("\n[TEST PASSED] Response printed via log().all().\n");
    }

    /**
     * Bonus - response.prettyPrint() prints AND returns the body in one
     * call. Useful in the pattern: "log it, but also keep the printed
     * string for an assertion downstream".
     */
    @Test(priority = 3,
          description = "POST /objects - use response.prettyPrint() (prints AND returns the body)")
    public void addProductPrintWithPrettyPrint() {

        System.out.println("\n[TEST START] addProductPrintWithPrettyPrint");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract().response();

        Assert.assertEquals(response.getStatusCode(), 200,
                "FAILED: pre-condition status code");

        System.out.println("\nResponse body via response.prettyPrint() :");
        // prettyPrint() WRITES to stdout AND returns the formatted body
        String printedBody = response.prettyPrint();

        // The returned string can then be used for further inspection
        System.out.println("\nLength of pretty-printed body : " + printedBody.length() + " chars");
        System.out.println("Body contains 'Dell I5'        : " + printedBody.contains("Dell I5"));
        System.out.println("Body contains 'createdAt'      : " + printedBody.contains("createdAt"));

        System.out.println("[TEST PASSED] Response printed via response.prettyPrint().\n");
    }
}
