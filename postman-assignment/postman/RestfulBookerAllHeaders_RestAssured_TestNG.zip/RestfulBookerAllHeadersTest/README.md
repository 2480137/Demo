# Get All Headers from Response - REST Assured + TestNG

Maven-based Java project that automates the **"Handle the response - get
all headers in REST Assured"** scenario. It sends a POST to Restful
Booker's `/booking` endpoint, extracts the response, retrieves **all**
response headers using REST Assured's **`headers()`** method, and prints
them to the console.

## Scenario

1. Send a **POST** to `https://restful-booker.herokuapp.com/booking` with
   the given booking body.
2. Extract the response and call `.headers()` to get all headers.
3. Print the headers to the console.

```json
{
    "firstname": "Jim",
    "lastname": "Brown",
    "totalprice": 111,
    "depositpaid": true,
    "bookingdates": {
        "checkin":  "2018-01-01",
        "checkout": "2019-01-01"
    },
    "additionalneeds": "Breakfast"
}
```

## What is REST Assured's `.headers()` method?

The `Response` interface exposes two equivalent methods that return the
**complete** set of response headers:

```java
Headers headers();         // canonical
Headers getHeaders();      // alias - same thing
```

The returned `Headers` object **implements `Iterable<Header>`**, so a
for-each loop is the standard way to walk through every name/value pair:

```java
Response r = given().body(body)
        .when().post("/booking")
        .then().extract().response();

Headers all = r.headers();
for (Header h : all) {
    System.out.println(h.getName() + " : " + h.getValue());
}
```

## The Headers API at a Glance

| Method                              | Returns         | Use for                                          |
|-------------------------------------|-----------------|--------------------------------------------------|
| `headers()`  / `getHeaders()`       | `Headers`       | Get the entire collection                        |
| `Headers.size()`                    | `int`           | Count of headers                                 |
| `Headers.asList()`                  | `List<Header>`  | Standard list for stream / index ops             |
| `Headers.hasHeaderWithName(name)`   | `boolean`       | Existence check                                  |
| `Headers.getValue(name)`            | `String`        | First value of a named header                    |
| `Headers.getValues(name)`           | `List<String>`  | All values (some headers can repeat)             |
| `Headers.toString()`                | `String`        | Pretty multi-line dump - great for `System.out`  |
| For-each over `Headers`             | each `Header`   | Walk every name/value pair                       |
| `Header.getName()`/`.getValue()`    | `String`        | Inspect each individual header                   |

## Hands-On 5 vs Hands-On 6 Comparison

| Aspect       | Hands-On 5 (single header)            | Hands-On 6 (all headers) - this project |
|--------------|----------------------------------------|------------------------------------------|
| Method used  | `.header(String name)`                 | `.headers()`                             |
| Returns      | `String` (single value)                | `Headers` (iterable collection)          |
| Use when     | You know the specific header you want  | You want to print/inspect every header   |
| Typical code | `String ct = r.header("Content-Type")` | `for (Header h : r.headers()) { ... }`   |

## Typical Headers from POST /booking on Restful Booker

| Header           | Example value                              |
|------------------|--------------------------------------------|
| Server           | `Cowboy`                                   |
| Connection       | `keep-alive`                               |
| X-Powered-By     | `Express`                                  |
| Content-Type     | `application/json; charset=utf-8`          |
| Content-Length   | `<numeric byte count>`                     |
| Date             | `<RFC 7231 timestamp>`                     |
| Etag             | `W/"<hash>"`                               |
| Via              | `1.1 vegur`                                |

## Project Structure

```
RestfulBookerAllHeadersTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── GetAllHeadersTest.java
```

## What the Test Class Does

| # | Method                              | Purpose                                                                        |
|---|-------------------------------------|--------------------------------------------------------------------------------|
| 1 | `getAllHeadersUsingHeadersMethod`   | Main: extract response, call `.headers()`, for-each through every Header.      |
| 2 | `getAllHeadersAsList`               | Bonus - `.headers().asList()` gives a `List<Header>`; index iteration + stream.|
| 3 | `demonstrateHeadersHelperMethods`   | Bonus - `.size()`, `.hasHeaderWithName()`, `.getValue()`, `.getValues()`.       |
| 4 | `printHeadersUsingToString`         | Bonus - the simplest dump idioms: `Headers.toString()` and `.log().headers()`. |

## Key REST Assured Patterns

```java
// 1. Extract response so we can call .headers() on it
Response response = given().body(body)
        .when().post("/booking")
        .then().extract().response();

// 2. Get the entire Headers collection (the assignment's idiom)
Headers all = response.headers();

// 3. For-each iteration (most common print pattern)
for (Header h : all) {
    System.out.println(h.getName() + " : " + h.getValue());
}

// 4. Convert to List<Header> for streams / index ops
List<Header> list = response.headers().asList();
list.stream().map(Header::getName).forEach(System.out::println);

// 5. Helper methods on Headers
int    count        = all.size();
boolean has         = all.hasHeaderWithName("Content-Type");
String firstValue   = all.getValue("Content-Type");
List<String> all    = all.getValues("Set-Cookie");

// 6. One-shot dump
System.out.println(response.headers());        // toString()
.then().log().headers();                       // chain-style log
```

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request                           | New `@Test` method                                   |
| Set the method to POST                      | `given().when().post(ENDPOINT)`                      |
| Set the URL                                 | `RestAssured.baseURI` + endpoint                     |
| Set raw JSON body                           | `given().body(BOOKING_BODY)`                         |
| Click Send                                  | Execution of the `@Test` method                      |
| Open the "Headers" tab in Postman response  | `response.headers()` and iterate                     |
| See all 8 (or however many) headers listed  | The for-each prints every Header in the same way     |

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=GetAllHeadersTest#getAllHeadersUsingHeadersMethod
```

## Expected Output (abridged)

```
[TEST START] getAllHeadersUsingHeadersMethod
Request URL    : https://restful-booker.herokuapp.com/booking
Status code    : 200
Number of headers : 8

--- All response headers via .headers() (for-each iteration) ---
  Server : Cowboy
  Connection : keep-alive
  X-Powered-By : Express
  Content-Type : application/json; charset=utf-8
  Content-Length : 168
  Etag : W/"a8-Yr4LRAi+Wv6mO4FHKQiBaNoB+sk"
  Date : Sat, 03 May 2026 12:55:42 GMT
  Via : 1.1 vegur

[TEST PASSED] All headers retrieved and printed via .headers().

[TEST START] getAllHeadersAsList
List size : 8

--- Indexed header iteration (for(int i = 0; ...) ) ---
  [1] Server : Cowboy
  [2] Connection : keep-alive
  ...

--- Just the header NAMES via stream ---
  Server
  Connection
  X-Powered-By
  Content-Type
  ...

[TEST START] demonstrateHeadersHelperMethods
headers.size()                              = 8
headers.hasHeaderWithName("Content-Type")   = true
headers.hasHeaderWithName("X-Definitely-Not-Present") = false
headers.getValue("Content-Type")            = application/json; charset=utf-8
headers.getValues("Content-Type")           = [application/json; charset=utf-8]

===============================================
Total tests run: 4, Passes: 4, Failures: 0
===============================================
```

## Notes

- Header names are **case-insensitive** per HTTP RFC, and REST Assured
  follows that rule.
- The exact set of headers returned by Restful Booker can vary slightly
  (Heroku may inject/strip some). The test does not assume a particular
  count - it only requires `Content-Type` to be present and the count
  to be > 0.
- POST /booking on Restful Booker returns **200 OK**, not 201 Created.
- This pairs naturally with Hands-On 5 (`header(name)` for a single
  header). Together they cover both bulk and individual header access.
- If the network is unavailable, all tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
