package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.http.Header;
import io.restassured.http.Headers;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

/**
 * Hands-On 6: Handle the response - get ALL headers in REST Assured.
 *
 * Scenario:
 *   Method   : POST
 *   URL      : https://restful-booker.herokuapp.com/booking
 *   Auth     : none
 *   Body     : { firstname, lastname, totalprice, depositpaid,
 *                bookingdates: { checkin, checkout },
 *                additionalneeds }
 *   Goal     : Extract the response, retrieve ALL response headers via
 *              the headers() method, and print them to the console.
 *
 * Steps covered:
 *  1. POST /booking sent through REST Assured with the given body.
 *  2. Response extracted and ALL headers retrieved via .headers().
 *  3. Headers printed to the console (multiple formats demonstrated).
 *
 * About REST Assured's headers() method:
 *
 *   The Response interface exposes two equivalent methods that return
 *   the COMPLETE set of response headers:
 *
 *       Headers headers();         // canonical
 *       Headers getHeaders();      // alias - same thing
 *
 *   The returned 'Headers' object is iterable - it implements
 *   Iterable<Header>, so a simple for-each loop is the standard way to
 *   walk through every name/value pair:
 *
 *       Headers all = response.headers();
 *       for (Header h : all) {
 *           System.out.println(h.getName() + ": " + h.getValue());
 *       }
 *
 *   Headers also supports:
 *     - .size()           - number of headers
 *     - .asList()         - List<Header> for stream/collection ops
 *     - .hasHeaderWithName(name)
 *     - .getValue(name)   - single value (first occurrence)
 *     - .getValues(name)  - List<String> (all occurrences)
 *     - .toString()       - human-readable dump
 *
 * About the API:
 *   POST /booking on Restful Booker returns 200 OK and typical headers:
 *       Content-Type     : application/json; charset=utf-8
 *       Server           : Cowboy
 *       Connection       : keep-alive
 *       Date             : <timestamp>
 *       X-Powered-By     : Express
 *       Content-Length   : <number>
 */
public class GetAllHeadersTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    /** Step 1 - The exact request body specified in the assignment. */
    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Steps 2-3 - Extract the response and get ALL headers using .headers(),
     * then print them. This is the main task of the assignment.
     */
    @Test(priority = 1,
          description = "POST /booking - get all headers via .headers() and print")
    public void getAllHeadersUsingHeadersMethod() {

        System.out.println("\n[TEST START] getAllHeadersUsingHeadersMethod");

        // Step 1 - Send the POST and EXTRACT the response so we can call
        // .headers() on it
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract()
                    .response();

        // Sanity check
        Assert.assertEquals(response.getStatusCode(), 200,
                "FAILED: pre-condition status code");

        // Step 2 - Get ALL response headers in one call. The result is a
        // Headers object (iterable). This is the assignment's specific ask.
        Headers allHeaders = response.headers();

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Status code    : " + response.getStatusCode());
        System.out.println("Number of headers : " + allHeaders.size());

        // Step 3 - Print every header with a simple for-each loop. The
        // Headers object iterates over Header instances; each Header has
        // .getName() and .getValue().
        System.out.println("\n--- All response headers via .headers() (for-each iteration) ---");
        for (Header h : allHeaders) {
            System.out.println("  " + h.getName() + " : " + h.getValue());
        }

        // The Content-Type header should always be present - sanity assert
        Assert.assertTrue(allHeaders.hasHeaderWithName("Content-Type"),
                "FAILED: 'Content-Type' header was missing from response");
        Assert.assertTrue(allHeaders.size() > 0,
                "FAILED: response had zero headers");

        System.out.println("\n[TEST PASSED] All headers retrieved and printed via .headers().\n");
    }

    /**
     * Bonus - same retrieval, but converted to a List<Header> via .asList()
     * so collection operations (size, get(i), stream, etc.) become available.
     */
    @Test(priority = 2,
          description = "POST /booking - .headers().asList() gives a List<Header> for collection ops")
    public void getAllHeadersAsList() {

        System.out.println("\n[TEST START] getAllHeadersAsList");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract().response();

        // .asList() returns a standard java.util.List<Header>
        List<Header> headerList = response.headers().asList();

        System.out.println("List size : " + headerList.size());

        System.out.println("\n--- Indexed header iteration (for(int i = 0; ...) ) ---");
        for (int i = 0; i < headerList.size(); i++) {
            Header h = headerList.get(i);
            System.out.println("  [" + (i + 1) + "] " + h.getName() + " : " + h.getValue());
        }

        // Modern Java stream alternative
        System.out.println("\n--- Just the header NAMES via stream ---");
        headerList.stream()
                .map(Header::getName)
                .forEach(name -> System.out.println("  " + name));

        Assert.assertFalse(headerList.isEmpty(),
                "FAILED: header list was empty");

        System.out.println("[TEST PASSED] Headers as List demonstrated.\n");
    }

    /**
     * Bonus - additional Headers helper methods. Demonstrates the rest of
     * the Headers API beyond simple iteration.
     */
    @Test(priority = 3,
          description = "POST /booking - Headers helper methods (size, hasHeaderWithName, getValue)")
    public void demonstrateHeadersHelperMethods() {

        System.out.println("\n[TEST START] demonstrateHeadersHelperMethods");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract().response();

        Headers headers = response.headers();

        // .size() - count of headers
        System.out.println("headers.size()                              = " + headers.size());

        // .hasHeaderWithName(name) - existence check
        boolean hasContentType = headers.hasHeaderWithName("Content-Type");
        boolean hasMissing     = headers.hasHeaderWithName("X-Definitely-Not-Present");
        System.out.println("headers.hasHeaderWithName(\"Content-Type\") = " + hasContentType);
        System.out.println("headers.hasHeaderWithName(\"X-Definitely-Not-Present\") = " + hasMissing);

        // .getValue(name) - first value of named header
        String contentType = headers.getValue("Content-Type");
        System.out.println("headers.getValue(\"Content-Type\")           = " + contentType);

        // .getValues(name) - all values for a header (some headers can repeat)
        List<String> contentTypes = headers.getValues("Content-Type");
        System.out.println("headers.getValues(\"Content-Type\")          = " + contentTypes);

        Assert.assertTrue(hasContentType,
                "FAILED: Content-Type should be present");
        Assert.assertFalse(hasMissing,
                "FAILED: a non-existent header should not be reported as present");
        Assert.assertNotNull(contentType,
                "FAILED: Content-Type value was null");

        System.out.println("[TEST PASSED] Headers helper methods demonstrated.\n");
    }

    /**
     * Bonus - the simplest "print all headers" idiom: System.out.println on
     * the Headers object directly. The toString() override produces a
     * neatly formatted block, one header per line.
     */
    @Test(priority = 4,
          description = "POST /booking - print headers via Headers.toString()")
    public void printHeadersUsingToString() {

        System.out.println("\n[TEST START] printHeadersUsingToString");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract().response();

        // The simplest way to dump every header in one shot
        System.out.println("\n--- Headers via response.headers().toString() ---");
        System.out.println(response.headers());

        // Equivalent one-liner via the .then() chain log()
        System.out.println("\n--- Headers via .then().log().headers() ---");
        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .log().headers();          // prints request/response headers

        System.out.println("[TEST PASSED] Headers printed via two compact idioms.\n");
    }
}
