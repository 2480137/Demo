# Verify Status Code with assertThat() Method - REST Assured + TestNG

Maven-based Java project that automates the **"Verify the response status
code with assertThat() method in REST Assured"** scenario. It sends a POST
request to Restful Booker's `/booking` endpoint and verifies the response
status code using REST Assured's fluent **`.assertThat()`** method.

## Scenario

Send a **POST** request to:

```
https://restful-booker.herokuapp.com/booking
```

with the following body, then verify the response **status code** using
REST Assured's `.assertThat()` method:

```json
{
    "firstname": "Jim",
    "lastname": "Brown",
    "totalprice": 111,
    "depositpaid": true,
    "bookingdates": {
        "checkin":  "2018-01-01",
        "checkout": "2019-01-01"
    },
    "additionalneeds": "Breakfast"
}
```

## What is REST Assured's `.assertThat()` Method?

`.assertThat()` is REST Assured's **natural-language connector** for the
fluent `ValidatableResponse` chain. It is a **no-op functionally** - the
real assertion is done by the matcher that follows. Stylistically, it
makes the chain read like an English sentence:

```java
given()
    .body(body)
.when()
    .post("/booking")
.then()
    .assertThat()           // <-- "assert that..."
    .statusCode(200);       // <-- "...the status code is 200"
```

Reads as: *"given body, when POST /booking, then ASSERT THAT status code is 200."*

## When .assertThat() Really Shines - Multiple Chained Assertions

A single `.assertThat()` umbrella covers any number of expectations that
follow. The chain becomes a clear list:

```java
.then()
    .assertThat()
    .statusCode(200)
    .body("bookingid",         greaterThan(0))
    .body("booking.firstname", equalTo("Jim"))
    .body("booking.lastname",  equalTo("Brown"))
    .body("booking.totalprice", equalTo(111));
```

This is THE main reason to use `.assertThat()` - readability when you have
many things to assert. For a single status-code check it is interchangeable
with `.statusCode(200)` directly (see the bonus test
`demonstrateAssertThatIsOptional`).

## Hands-On 1 vs Hands-On 2 - The Difference

| Aspect             | Hands-On 1 (`statusCode()`)           | Hands-On 2 (`assertThat()`) — this project |
|--------------------|----------------------------------------|---------------------------------------------|
| Idiom              | `.then().statusCode(200)`              | `.then().assertThat().statusCode(200)`      |
| Functional result  | Identical                              | Identical                                   |
| Typical usage      | Quick status-only check                | Multiple assertions in one chain            |
| Reads like         | "then status code 200"                 | "then assert that status code is 200"       |

Both methods do exactly the same thing for a single status check; the
difference is purely stylistic.

## How POST /booking Responds

| Aspect       | Value                                                           |
|--------------|-----------------------------------------------------------------|
| Status code  | **200 OK** (note: NOT 201 Created - Restful Booker quirk)       |
| Auth         | Not required (POST is open; PUT/PATCH/DELETE require auth)      |
| Body shape   | `{ "bookingid": <int>, "booking": { ...echoed input... } }`     |

## Project Structure

```
RestfulBookerAssertThatTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── VerifyAssertThatTest.java
```

## What the Test Class Does

| # | Method                                  | Purpose                                                                           |
|---|-----------------------------------------|-----------------------------------------------------------------------------------|
| 1 | `verifyStatusCodeUsingAssertThat`       | Main: pure `.then().assertThat().statusCode(200)` - the assignment's specific ask. |
| 2 | `verifyStatusCodeAndBodyUsingAssertThat`| Bonus - `assertThat()` chained with **9 body matchers** (Hamcrest) on one chain.   |
| 3 | `demonstrateAssertThatIsOptional`       | Bonus - shows `.assertThat()` is purely cosmetic; both forms are equivalent.       |

## Key REST Assured Patterns

```java
// 1. The canonical assertThat() form (what the assignment asks for)
given().body(body)
   .when().post("/booking")
   .then().assertThat().statusCode(200);

// 2. assertThat() as an umbrella over many checks
given().body(body)
   .when().post("/booking")
   .then()
       .assertThat()
       .statusCode(200)
       .contentType(containsString("json"))
       .body("bookingid",         greaterThan(0))
       .body("booking.firstname", equalTo("Jim"))
       .body("booking.lastname",  equalTo("Brown"))
       .body("booking.totalprice", equalTo(111));

// 3. Hamcrest static imports keep the matcher syntax clean:
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.notNullValue;
```

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request                           | New `@Test` method                                   |
| Set the method to POST                      | `given().when().post(ENDPOINT)`                      |
| Set the URL                                 | `RestAssured.baseURI` + endpoint path                |
| Set raw JSON body                           | `given().body(BOOKING_BODY)`                         |
| Click Send                                  | Execution of the `@Test` method                      |
| Check status in Tests tab                   | `.then().assertThat().statusCode(200)`               |
| Multiple "pm.expect" statements             | Multiple chained `.body(...)` matchers               |

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=VerifyAssertThatTest#verifyStatusCodeUsingAssertThat
```

## Expected Output (abridged)

```
[TEST START] verifyStatusCodeUsingAssertThat
Verifying status code with REST Assured's .assertThat() method.
Request URL : https://restful-booker.herokuapp.com/booking
Method      : POST
Verified that the response status code is 200 via .assertThat().
[TEST PASSED] .assertThat().statusCode(200) succeeded.

[TEST START] verifyStatusCodeAndBodyUsingAssertThat
Chaining assertThat() with body matchers for a multi-aspect assertion.
[TEST PASSED] assertThat() + 9 chained matchers all succeeded.

[TEST START] demonstrateAssertThatIsOptional
Form 1: .then().assertThat().statusCode(200)
Form 2: .then().statusCode(200)
Both forms succeed identically. assertThat() is purely for readability.
[TEST PASSED] Functional equivalence demonstrated.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- POST /booking on Restful Booker returns **200**, not 201 Created.
- Each successful POST creates a real booking on the server. Restful
  Booker resets all data every 10 minutes anyway.
- This is a companion to Hands-On 1 (`.statusCode()` method). Together
  they cover both common idioms for status verification in REST Assured.
- If the network is unavailable, all tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
