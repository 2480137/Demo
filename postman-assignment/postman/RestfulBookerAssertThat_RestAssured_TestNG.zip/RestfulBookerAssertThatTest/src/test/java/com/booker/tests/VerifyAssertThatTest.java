package com.booker.tests;

import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Hands-On 2: Verify the response status code with the assertThat() method
 * in REST Assured - POST /booking on Restful Booker.
 *
 * Scenario:
 *   Method   : POST
 *   URL      : https://restful-booker.herokuapp.com/booking
 *   Auth     : none (POST /booking is open on Restful Booker)
 *   Body     : { firstname, lastname, totalprice, depositpaid,
 *                bookingdates: { checkin, checkout },
 *                additionalneeds }
 *   Verify   : Response status code (using REST Assured's assertThat() method).
 *
 * Steps covered:
 *  1. Java class created in the rest-assured framework (this file).
 *  2. POST /booking sent through REST Assured with the given body.
 *  3. Status code verified using REST Assured's assertThat() method.
 *
 * About the assertThat() method:
 *   .assertThat() is REST Assured's natural-language connector for the
 *   ValidatableResponse fluent chain. Functionally it is a no-op - the
 *   assertion is still done by the matcher that follows. Stylistically,
 *   it makes the chain read like an English sentence:
 *
 *      "given body, when post /booking, then ASSERT THAT status code is 200"
 *
 *   The signature is:
 *      .then().assertThat().statusCode(200);
 *
 *   It shines when CHAINED with multiple assertions, where it acts as
 *   one assertThat() umbrella over a list of expectations:
 *
 *      .then()
 *          .assertThat()
 *          .statusCode(200)
 *          .body("bookingid",         greaterThan(0))
 *          .body("booking.firstname", equalTo("Jim"))
 *          .body("booking.lastname",  equalTo("Brown"));
 *
 * About the API:
 *   POST /booking on Restful Booker returns 200 OK (NOT 201 Created).
 *   Response shape: { "bookingid": <int>, "booking": {...} }
 *   No authentication is required for POST.
 */
public class VerifyAssertThatTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    /** Step 2 - The exact request body specified in the assignment. */
    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 3 - Send POST and verify the status code using REST Assured's
     * assertThat() method.
     *
     * The chain reads as a sentence:
     *   "given body, when post /booking, then ASSERT THAT status code is 200"
     */
    @Test(priority = 1,
          description = "POST /booking - verify status code 200 using .assertThat().statusCode(200)")
    public void verifyStatusCodeUsingAssertThat() {

        System.out.println("\n[TEST START] verifyStatusCodeUsingAssertThat");
        System.out.println("Verifying status code with REST Assured's .assertThat() method.");

        // The assignment's specific ask - .assertThat() in the chain.
        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()                  // <-- the assertThat() method
                    .statusCode(200);

        System.out.println("Request URL : " + BASE_URI + ENDPOINT);
        System.out.println("Method      : POST");
        System.out.println("Verified that the response status code is 200 via .assertThat().");
        System.out.println("[TEST PASSED] .assertThat().statusCode(200) succeeded.\n");
    }

    /**
     * Bonus - .assertThat() shines when chained with multiple body
     * assertions. One assertThat() umbrella covers everything that follows;
     * the chain reads naturally as a series of expectations.
     */
    @Test(priority = 2,
          description = "POST /booking - assertThat chained with multiple body matchers")
    public void verifyStatusCodeAndBodyUsingAssertThat() {

        System.out.println("\n[TEST START] verifyStatusCodeAndBodyUsingAssertThat");
        System.out.println("Chaining assertThat() with body matchers for a multi-aspect assertion.");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()                              // umbrella
                    .statusCode(200)                           // status check
                    .body("bookingid",                  greaterThan(0))
                    .body("booking",                    notNullValue())
                    .body("booking.firstname",          equalTo("Jim"))
                    .body("booking.lastname",           equalTo("Brown"))
                    .body("booking.totalprice",         equalTo(111))
                    .body("booking.depositpaid",        equalTo(true))
                    .body("booking.bookingdates.checkin",   equalTo("2018-01-01"))
                    .body("booking.bookingdates.checkout",  equalTo("2019-01-01"))
                    .body("booking.additionalneeds",    equalTo("Breakfast"));

        System.out.println("[TEST PASSED] assertThat() + 9 chained matchers all succeeded.\n");
    }

    /**
     * Bonus - shows that assertThat() is functionally optional. These two
     * forms are equivalent; assertThat() exists purely for readability.
     */
    @Test(priority = 3,
          description = "POST /booking - .assertThat() is optional - functional equivalence demo")
    public void demonstrateAssertThatIsOptional() {

        System.out.println("\n[TEST START] demonstrateAssertThatIsOptional");

        // Form 1 - WITH assertThat()
        System.out.println("Form 1: .then().assertThat().statusCode(200)");
        RestAssured
                .given().header("Content-Type", "application/json").body(BOOKING_BODY)
                .when().post(ENDPOINT)
                .then().assertThat().statusCode(200);

        // Form 2 - WITHOUT assertThat() (functionally identical)
        System.out.println("Form 2: .then().statusCode(200)");
        RestAssured
                .given().header("Content-Type", "application/json").body(BOOKING_BODY)
                .when().post(ENDPOINT)
                .then().statusCode(200);

        System.out.println("Both forms succeed identically. assertThat() is purely for readability.");
        System.out.println("[TEST PASSED] Functional equivalence demonstrated.\n");
    }
}
