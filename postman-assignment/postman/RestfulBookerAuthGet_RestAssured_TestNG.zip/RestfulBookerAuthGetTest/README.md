# Restful Booker Auth GET - REST Assured + TestNG

Maven-based Java project that automates the **"Get the response of GET API
request"** scenario using **REST Assured** and **TestNG**. The test sends a
GET request to Restful Booker's `/auth` endpoint, prints the response, and
verifies the status code.

This is the **REST Assured automated equivalent** of the manual Postman
walkthrough (open Postman → workspace → collection → add request → set GET
method → set URL → click Send → verify response).

## Scenario

Send a **GET** request to:

```
https://restful-booker.herokuapp.com/auth
```

Inspect the response and verify the status code.

## IMPORTANT - The /auth endpoint is POST-only

Restful Booker's `/auth` route exists only to **issue authentication tokens**
via POST with credentials. A GET request to this route returns
**404 Not Found** because the route is not registered for the GET verb.

This is the documented behaviour of the API and is **not a defect**. The
assignment exercises *"send a request and inspect the response"* rather
than testing a happy path.

The main test method asserts on `404` (the actual API behaviour). A bonus
test method demonstrates the correct usage of `/auth` - a `POST` with admin
credentials that returns a JSON object containing an auth token.

## Postman → REST Assured Mapping

| Postman step                         | REST Assured equivalent                          |
|--------------------------------------|--------------------------------------------------|
| Open Postman                         | Maven project setup (`pom.xml`, this codebase)   |
| Go to the right workspace            | (workspace concept does not exist in code)       |
| Go to the right collection           | Test class / TestNG suite                        |
| Add a new request                    | New `@Test` method                               |
| Give the request a meaningful name   | Method name + `@Test(description=...)`           |
| Set the method to GET                | `given().when().get(ENDPOINT)`                   |
| Set the URL                          | `RestAssured.baseURI` + endpoint path            |
| Click Send                           | Execution of the `@Test` method                  |
| Verify the response                  | TestNG `Assert.assertEquals(...)`                |

## Project Structure

```
RestfulBookerAuthGetTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── RestfulBookerAuthGetTest.java
```

## What the Test Class Does

The `RestfulBookerAuthGetTest` class contains three test methods:

| # | Method                                | Purpose                                                                         |
|---|---------------------------------------|---------------------------------------------------------------------------------|
| 1 | `getAuthAndVerifyResponse`            | Main: GETs `/auth`, prints all response details, asserts the documented 404.    |
| 2 | `postAuthAndObtainToken`              | Bonus - shows the correct usage of /auth: POST with credentials → token.        |
| 3 | `documentMethodNotAllowedBehaviour`   | Bonus - documents that Restful Booker uses 404 instead of the stricter 405.     |

## Key REST Assured Pattern

```java
// Once at class level
RestAssured.baseURI = "https://restful-booker.herokuapp.com";

// Per-test (the GET path)
Response response = given()
        .header("Accept", "application/json")
    .when()
        .get("/auth")
    .then()
        .extract()
        .response();

// Inspect every aspect
int    status      = response.getStatusCode();
String contentType = response.getContentType();
long   timeMs      = response.getTime();
String body        = response.getBody().asString();
```

And the proper POST flow demonstrated in the bonus test:

```java
String credentials = "{ \"username\": \"admin\", \"password\": \"password123\" }";

Response response = given()
        .header("Content-Type", "application/json")
        .body(credentials)
    .when()
        .post("/auth")
    .then()
        .extract().response();

String token = response.jsonPath().getString("token");
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=RestfulBookerAuthGetTest#getAuthAndVerifyResponse
```

## Expected Output (abridged)

```
[TEST START] getAuthAndVerifyResponse
Request URL    : https://restful-booker.herokuapp.com/auth
Method         : GET
Status code    : 404
Content-Type   : text/html; charset=utf-8
Response time  : 234 ms

--- Response body ---
(empty body or HTML 404 page)
[TEST PASSED] GET /auth returned 404 as expected for a POST-only route.

[TEST START] postAuthAndObtainToken
POST URL       : https://restful-booker.herokuapp.com/auth
Status code    : 200
Response body  : { "token": "abc123def456..." }
Extracted token: abc123def456...
[TEST PASSED] POST /auth returned a non-empty token.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- Restful Booker is a public test API designed for QA practice. It contains
  a few intentional quirks (such as returning `201 Created` for DELETE,
  `404 Not Found` for wrong-method requests instead of `405 Method Not
  Allowed`). These quirks are part of the learning experience.
- The /auth credentials (`admin` / `password123`) are documented on the
  Restful Booker landing page and are shared by every user of the demo.
- If the network is unavailable, all tests will fail with connection errors
  - this is an infrastructure issue, not a code defect.
