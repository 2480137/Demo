package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hands-On 4: Get the response of GET API request - automated with REST Assured.
 *
 * Postman scenario (automated equivalent below):
 *   Method   : GET
 *   URL      : https://restful-booker.herokuapp.com/auth
 *   Action   : Click Send and verify the response
 *
 * IMPORTANT - the /auth endpoint is POST-only.
 *  Restful Booker's /auth route exists only to issue authentication tokens
 *  via POST with credentials. Sending a GET to it returns 404 Not Found.
 *  This is intentional behaviour - the assignment is exercising "send a
 *  request and inspect the response" rather than testing a happy path.
 *  The main test verifies the actual server behaviour (404), and a bonus
 *  test demonstrates the correct way to use this endpoint (POST with
 *  credentials to obtain a token).
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. baseURI configured to https://restful-booker.herokuapp.com
 *  4. GET request sent to /auth using RestAssured.
 *  5. Response inspected and printed to the console.
 *  6. Status code asserted (404 - expected behaviour for a POST-only route).
 */
public class RestfulBookerAuthGetTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/auth";

    @BeforeClass
    public void setUp() {
        // Step 3 - Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Steps 4-6 - Send GET to /auth, print the response, verify the status.
     *
     * Because /auth is POST-only, the server returns 404 Not Found. The test
     * still passes - we are asserting on the actual documented behaviour of
     * the endpoint, not assuming an arbitrary 200.
     */
    @Test(priority = 1,
          description = "GET /auth - inspect the response and verify the status code")
    public void getAuthAndVerifyResponse() {

        System.out.println("\n[TEST START] getAuthAndVerifyResponse");

        // Step 4 - Send the GET request through RestAssured
        Response response = RestAssured
                .given()
                    .header("Accept", "application/json")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int    statusCode  = response.getStatusCode();
        String contentType = response.getContentType();
        long   responseTime = response.getTime();
        String body        = response.getBody().asString();

        // Step 5 - Print every piece of information about the response
        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Method         : GET");
        System.out.println("Status code    : " + statusCode);
        System.out.println("Content-Type   : " + contentType);
        System.out.println("Response time  : " + responseTime + " ms");
        System.out.println("Response size  : " + body.length() + " chars");
        System.out.println("\n--- Response body ---");
        System.out.println(body.isEmpty() ? "(empty body)" : body);

        // Step 6 - Assert on the actual documented behaviour.
        // The endpoint is POST-only, so a GET legitimately returns 404.
        Assert.assertEquals(statusCode, 404,
                "FAILED: expected 404 (because /auth is POST-only) but got " + statusCode);

        System.out.println("[TEST PASSED] GET /auth returned 404 as expected for a POST-only route.\n");
    }

    /**
     * Bonus - the proper way to use /auth: a POST request with admin
     * credentials returns a JSON object containing an auth token.
     * This is the happy path the API was designed for.
     */
    @Test(priority = 2,
          description = "POST /auth with credentials - obtain an auth token")
    public void postAuthAndObtainToken() {

        System.out.println("\n[TEST START] postAuthAndObtainToken");

        String credentialsBody = "{\n"
                + "  \"username\": \"admin\",\n"
                + "  \"password\": \"password123\"\n"
                + "}";

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(credentialsBody)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();
        System.out.println("POST URL       : " + BASE_URI + ENDPOINT);
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response body  : " + response.getBody().asString());

        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK on POST /auth but got " + statusCode);

        // Pull the token out of the JSON response
        String token = response.jsonPath().getString("token");
        System.out.println("Extracted token: " + token);

        Assert.assertNotNull(token,
                "FAILED: 'token' field was null - check credentials in the request body");
        Assert.assertFalse(token.isEmpty(),
                "FAILED: 'token' field was empty");

        System.out.println("[TEST PASSED] POST /auth returned a non-empty token.\n");
    }

    /**
     * Bonus - a 405 Method Not Allowed is the strictest correct response for
     * a wrong method on an existing route. Restful Booker does not implement
     * 405; it returns 404 instead. This test documents that quirk so future
     * readers do not assume 405.
     */
    @Test(priority = 3,
          description = "Document Restful Booker's behaviour on wrong-method requests")
    public void documentMethodNotAllowedBehaviour() {

        System.out.println("\n[TEST START] documentMethodNotAllowedBehaviour");

        int statusCode = RestAssured
                .given()
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .statusCode();

        System.out.println("HTTP standard would suggest 405 Method Not Allowed for GET /auth.");
        System.out.println("Restful Booker actually returns: " + statusCode);
        System.out.println("(This is a known API quirk and is not a defect.)");

        Assert.assertTrue(statusCode == 404 || statusCode == 405,
                "FAILED: expected 404 or 405 from a wrong-method request, got " + statusCode);

        System.out.println("[TEST PASSED] Behaviour documented.\n");
    }
}
