# Restful Booker Create Booking - REST Assured + TestNG

Maven-based Java project that automates the **"Get the response of POST API
request"** scenario using **REST Assured** and **TestNG**. The test obtains
an auth token from `POST /auth` (chaining from the previous Hands-On 4
scenario), then sends `POST /booking` with that token as a Bearer header and
a JSON booking payload, and verifies the response.

This is the **REST Assured automated equivalent** of the manual Postman
walkthrough.

## Scenario

1. POST to `https://restful-booker.herokuapp.com/auth` with admin
   credentials → obtain an auth token.
2. POST to `https://restful-booker.herokuapp.com/booking` with:
   - `Authorization: Bearer <token>` header (from step 1)
   - JSON body containing booking details
3. Verify the response is `200 OK` and contains a `bookingid` plus the
   echoed booking object.

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                                |
|---------------------------------------------|--------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                             |
| Add a new request                           | New `@Test` method                                     |
| Set the method to POST                      | `given().when().post(ENDPOINT)`                        |
| Set the URL                                 | `RestAssured.baseURI` + endpoint                       |
| Get token from previous test, use as Bearer | `@BeforeClass` chains to /auth, stores `authToken`     |
| Set request body                            | `given().body(BOOKING_BODY)`                           |
| Click Send → verify response                | `Assert.assertEquals(...)` / fluent `then().body()`    |

## IMPORTANT - Notes on Auth and Restful Booker

Three subtleties to be aware of when reading the test code:

### 1. POST /booking does not actually require auth

Restful Booker only enforces auth on **PUT**, **PATCH**, and **DELETE**
operations against `/booking/{id}`. The `POST /booking` endpoint is open
and accepts requests without any auth header at all. The bonus test
`createBookingWithoutAuth` demonstrates this.

### 2. Restful Booker does not implement the Bearer scheme

When auth IS required (e.g. PUT /booking/123), Restful Booker accepts:

- A **Cookie** header: `Cookie: token=<token>`
- HTTP **Basic Auth**: `Authorization: Basic <base64(admin:password123)>`

It does **NOT** read `Authorization: Bearer ...`. So even if we attach the
token as a Bearer header, the server ignores it.

### 3. The assignment still wants Bearer, so we send Bearer

The assignment text says: *"Get the token from the above test case and
utilize as bearer token"*. The test follows that instruction literally and
asserts the happy path. The combination of (1) and (2) above means the
test passes either way.

## About the Response

`POST /booking` returns:

```json
{
    "bookingid": 4271,
    "booking": {
        "firstname": "Jim",
        "lastname": "Brown",
        "totalprice": 111,
        "depositpaid": true,
        "bookingdates": {
            "checkin":  "2024-01-01",
            "checkout": "2024-01-10"
        },
        "additionalneeds": "Breakfast"
    }
}
```

Note that the status code is **200 OK**, not 201 Created - another known
Restful Booker quirk.

## Project Structure

```
RestfulBookerCreateBookingTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── RestfulBookerCreateBookingTest.java
```

## What the Test Class Does

`@BeforeClass` chains from /auth: obtains a fresh token and stores it in the
`authToken` field. Every subsequent test reuses that token.

| # | Method                            | Purpose                                                                  |
|---|-----------------------------------|--------------------------------------------------------------------------|
| 1 | `createBookingWithBearerToken`    | Main: POST /booking with Bearer token + body, verifies 200 + bookingid.  |
| 2 | `createBookingWithFluentStyle`    | Bonus - same checks expressed in REST Assured's fluent matcher style.    |
| 3 | `createBookingWithoutAuth`        | Bonus - documents that POST /booking succeeds even without an auth header.|

## Sample Request Body (Input)

The assignment refers to a request body "from the input file column". One
was not provided, so the project ships with this representative payload:

```json
{
  "firstname":  "Jim",
  "lastname":   "Brown",
  "totalprice": 111,
  "depositpaid": true,
  "bookingdates": {
    "checkin":  "2024-01-01",
    "checkout": "2024-01-10"
  },
  "additionalneeds": "Breakfast"
}
```

## Key REST Assured Patterns

```java
// 1. Token chaining in @BeforeClass
String authBody = "{ \"username\": \"admin\", \"password\": \"password123\" }";
String token = given().header("Content-Type", "application/json")
                      .body(authBody)
                  .when().post("/auth")
                  .then().extract().jsonPath().getString("token");

// 2. POST with Bearer header + JSON body
Response response = given()
        .header("Content-Type", "application/json")
        .header("Authorization", "Bearer " + token)
        .body(BOOKING_BODY)
    .when().post("/booking")
    .then().extract().response();

// 3. Extract nested response fields
Integer bookingId = response.jsonPath().getInt("bookingid");
String firstname  = response.jsonPath().getString("booking.firstname");
String checkin    = response.jsonPath().getString("booking.bookingdates.checkin");
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=RestfulBookerCreateBookingTest#createBookingWithBearerToken
```

## Expected Output (abridged)

```
Token obtained from /auth: a1b2c3d4e5f6...

[TEST START] createBookingWithBearerToken
Request URL    : https://restful-booker.herokuapp.com/booking
Method         : POST
Auth header    : Bearer a1b2c3d4e5f6...
Status code    : 200

--- Pretty-printed response body ---
{
    "bookingid": 4271,
    "booking": {
        "firstname": "Jim",
        "lastname": "Brown",
        "totalprice": 111,
        "depositpaid": true,
        "bookingdates": {
            "checkin": "2024-01-01",
            "checkout": "2024-01-10"
        },
        "additionalneeds": "Breakfast"
    }
}

--- Echoed booking values ---
bookingid           : 4271
booking.firstname   : Jim
booking.lastname    : Brown
booking.totalprice  : 111
booking.checkin     : 2024-01-01
[TEST PASSED] Booking created successfully with bookingid=4271.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- Every successful POST creates a fresh booking on the server, but Restful
  Booker resets data every 10 minutes. The booking id will differ on every
  run; the test only asserts that it is a positive integer.
- If the network is unavailable, all tests will fail with connection errors
  - this is an infrastructure issue, not a code defect.
