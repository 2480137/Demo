package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hands-On 5: Get the response of POST API request - automated with REST Assured.
 *
 * Postman scenario (automated equivalent):
 *   Method   : POST
 *   URL      : https://restful-booker.herokuapp.com/booking
 *   Auth     : Bearer token obtained from POST /auth
 *   Body     : Booking details (firstname, lastname, dates, etc.)
 *   Action   : Click Send and verify the response
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. baseURI configured to https://restful-booker.herokuapp.com
 *  4. Token obtained from POST /auth (chaining from the previous test case).
 *  5. Token attached as Bearer to a POST /booking request.
 *  6. Request body supplied as raw JSON.
 *  7. Response asserted (200 OK + bookingid + booking object echoed back).
 *
 * Notes on auth (read this if you wonder why the test still passes):
 *  - Restful Booker only requires authentication for PUT, PATCH and DELETE
 *    on /booking/{id}. POST /booking is open and accepts requests without
 *    any auth header.
 *  - When auth IS required, Restful Booker accepts either a 'Cookie' header
 *    (token=...) or HTTP Basic Auth - it does NOT actually use the
 *    'Authorization: Bearer' scheme.
 *  - The assignment specifies to attach the token as a Bearer token on
 *    POST /booking. The server silently ignores it and the booking is
 *    created either way. We attach it as instructed and assert the happy
 *    path (200 OK + bookingid). A bonus test demonstrates that POST
 *    /booking works without any auth header at all.
 */
public class RestfulBookerCreateBookingTest {

    private static final String BASE_URI       = "https://restful-booker.herokuapp.com";
    private static final String AUTH_ENDPOINT  = "/auth";
    private static final String BOOKING_ENDPOINT = "/booking";
    private static final String USERNAME       = "admin";
    private static final String PASSWORD       = "password123";

    /** Token obtained from /auth and reused by every test in this class. */
    private String authToken;

    /** Sample booking payload supplied because the assignment's "input file" was not provided. */
    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2024-01-01\",\n"
            + "    \"checkout\": \"2024-01-10\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Step 3 - Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;

        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");

        // Step 4 - Chain from the previous test case: POST /auth to obtain a token
        // and store it for use by every booking test in this class.
        String authBody = "{ \"username\": \"" + USERNAME
                + "\", \"password\": \"" + PASSWORD + "\" }";

        Response authResp = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(authBody)
                .when()
                    .post(AUTH_ENDPOINT)
                .then()
                    .extract().response();

        Assert.assertEquals(authResp.getStatusCode(), 200,
                "FAILED: pre-condition - POST /auth returned "
                        + authResp.getStatusCode() + " (expected 200)");

        authToken = authResp.jsonPath().getString("token");
        Assert.assertNotNull(authToken,
                "FAILED: pre-condition - 'token' field missing from /auth response");
        Assert.assertFalse(authToken.isEmpty(),
                "FAILED: pre-condition - token from /auth was empty");

        System.out.println("Token obtained from /auth: " + authToken);
    }

    /**
     * Steps 5-7 - Send POST /booking with the bearer token + JSON body,
     * verify status code and inspect the response.
     */
    @Test(priority = 1,
          description = "POST /booking with Bearer token - create a booking and verify response")
    public void createBookingWithBearerToken() {

        System.out.println("\n[TEST START] createBookingWithBearerToken");

        // Step 5 + 6 - Send the POST with token + body
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .header("Authorization", "Bearer " + authToken)   // as the assignment specifies
                    .body(BOOKING_BODY)
                .when()
                    .post(BOOKING_ENDPOINT)
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + BOOKING_ENDPOINT);
        System.out.println("Method         : POST");
        System.out.println("Auth header    : Bearer " + authToken);
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        // Step 7 - Assertions
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK but got " + statusCode);

        // The response shape is { "bookingid": <int>, "booking": { ... } }
        Integer bookingId = response.jsonPath().getInt("bookingid");
        Assert.assertNotNull(bookingId,
                "FAILED: 'bookingid' field missing from response");
        Assert.assertTrue(bookingId > 0,
                "FAILED: bookingid should be a positive integer, got " + bookingId);

        // Verify the echoed booking matches what we sent
        String firstname  = response.jsonPath().getString("booking.firstname");
        String lastname   = response.jsonPath().getString("booking.lastname");
        Integer totalPrice = response.jsonPath().getInt("booking.totalprice");
        String checkin    = response.jsonPath().getString("booking.bookingdates.checkin");

        System.out.println("\n--- Echoed booking values ---");
        System.out.println("bookingid           : " + bookingId);
        System.out.println("booking.firstname   : " + firstname);
        System.out.println("booking.lastname    : " + lastname);
        System.out.println("booking.totalprice  : " + totalPrice);
        System.out.println("booking.checkin     : " + checkin);

        Assert.assertEquals(firstname, "Jim",
                "FAILED: firstname did not round-trip correctly");
        Assert.assertEquals(lastname, "Brown",
                "FAILED: lastname did not round-trip correctly");
        Assert.assertEquals(totalPrice, Integer.valueOf(111),
                "FAILED: totalprice did not round-trip correctly");
        Assert.assertEquals(checkin, "2024-01-01",
                "FAILED: checkin date did not round-trip correctly");

        System.out.println("[TEST PASSED] Booking created successfully with bookingid="
                + bookingId + ".\n");
    }

    /**
     * Bonus - same scenario expressed using REST Assured's fluent
     * then().body() Hamcrest assertions for a more compact idiom.
     */
    @Test(priority = 2,
          description = "POST /booking with Bearer token - fluent then().body() style")
    public void createBookingWithFluentStyle() {

        System.out.println("\n[TEST START] createBookingWithFluentStyle");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Authorization", "Bearer " + authToken)
                    .body(BOOKING_BODY)
                .when()
                    .post(BOOKING_ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(200)
                    .contentType(org.hamcrest.Matchers.containsString("json"))
                    .body("bookingid",          org.hamcrest.Matchers.greaterThan(0))
                    .body("booking.firstname",  org.hamcrest.Matchers.equalTo("Jim"))
                    .body("booking.lastname",   org.hamcrest.Matchers.equalTo("Brown"))
                    .body("booking.totalprice", org.hamcrest.Matchers.equalTo(111));

        System.out.println("[TEST PASSED] Fluent style assertions succeeded.\n");
    }

    /**
     * Bonus - documents that POST /booking does NOT actually require auth on
     * Restful Booker. The booking is created successfully whether the
     * Authorization header is present or absent. This explains why the
     * earlier tests still pass even though Restful Booker does not implement
     * the Bearer scheme.
     */
    @Test(priority = 3,
          description = "Document that POST /booking succeeds with no auth header at all")
    public void createBookingWithoutAuth() {

        System.out.println("\n[TEST START] createBookingWithoutAuth");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    // intentionally NO Authorization header
                    .body(BOOKING_BODY)
                .when()
                    .post(BOOKING_ENDPOINT)
                .then()
                    .extract().response();

        int statusCode = response.getStatusCode();
        Integer bookingId = response.jsonPath().getInt("bookingid");

        System.out.println("Status code (no auth) : " + statusCode);
        System.out.println("bookingid (no auth)   : " + bookingId);

        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK without auth (Restful Booker quirk: POST /booking is open)");
        Assert.assertNotNull(bookingId,
                "FAILED: bookingid was missing in the no-auth response");
        Assert.assertTrue(bookingId > 0,
                "FAILED: bookingid was not positive in the no-auth response");

        System.out.println("[TEST PASSED] Confirmed: POST /booking is open on Restful Booker.\n");
    }
}
