# Custom Parsers - REST Assured + TestNG

POST /booking on Restful Booker, validate the response using REST Assured custom parsers.

## Why custom parsers?

When the server returns a body in a non-standard `Content-Type`, REST Assured won't auto-parse it. Custom parser registration tells REST Assured to treat that Content-Type as JSON / XML / HTML.

## Three ways to register parsers

```java
// 1. Global - applies to every request
RestAssured.registerParser("application/vnd.booker.v1+json", Parser.JSON);

// 2. Per-request - inside .then()
.then().parser("application/vnd.booker.v1+json", Parser.JSON);

// 3. Default fallback - used when Content-Type is unknown
RestAssured.defaultParser = Parser.JSON;
```

## Test Methods

| # | Method                              | Purpose                                                  |
|---|-------------------------------------|----------------------------------------------------------|
| 1 | `validateWithGlobalCustomParser`    | Global `RestAssured.registerParser` + body validation + print. |
| 2 | `validateWithPerRequestParser`      | Per-request `.then().parser(...)` registration.          |
| 3 | `validateWithDefaultParserFallback` | `RestAssured.defaultParser = Parser.JSON` fallback.      |

## Run

```bash
mvn clean test
```
