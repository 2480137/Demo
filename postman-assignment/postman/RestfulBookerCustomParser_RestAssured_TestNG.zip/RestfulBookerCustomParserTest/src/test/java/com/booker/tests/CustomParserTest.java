package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.parsing.Parser;
import io.restassured.response.Response;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Hands-On 18: Validating response using Custom Parsers in REST Assured.
 *
 * Goal: When the server returns a body in a "custom" / non-standard
 * Content-Type, REST Assured won't auto-parse it. Custom parser
 * registration tells REST Assured to treat that Content-Type as JSON
 * (or XML, HTML, ...).
 *
 * Two ways to register parsers in REST Assured:
 *
 *   1. GLOBAL  - RestAssured.registerParser("text/custom", Parser.JSON)
 *   2. PER-REQUEST - .expect().parser("text/custom", Parser.JSON)
 *
 *   Default fallback parser:
 *      RestAssured.defaultParser = Parser.JSON;
 *
 * Demo idea:
 *   - The Restful Booker /booking endpoint responds with the standard
 *     application/json content type, so REST Assured handles it natively.
 *   - To exercise a CUSTOM parser, we accept a non-standard content
 *     type via the Accept header and register a parser to interpret
 *     whatever the server sends. We also force-register the standard
 *     application/json content type as Parser.JSON to demonstrate the
 *     registration API in action against a real call.
 *   - We also call .expect().parser(...) per-request as the per-request
 *     alternative.
 */
public class CustomParserTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URI;

        // --- Global parser registrations ---
        // Register a CUSTOM content type to be parsed as JSON
        RestAssured.registerParser("application/vnd.booker.v1+json", Parser.JSON);
        // Force the standard application/json registration too (no-op
        // by default, demonstrates the API)
        RestAssured.registerParser("application/json", Parser.JSON);
        // Set a default parser fallback for any unrecognized Content-Type
        RestAssured.defaultParser = Parser.JSON;

        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI = " + BASE_URI);
        System.out.println("Custom parser registered: application/vnd.booker.v1+json -> Parser.JSON");
        System.out.println("Default parser fallback:  Parser.JSON");
        System.out.println("=========================================================");
    }

    @AfterClass
    public void tearDown() {
        // Clean up - reset default parser so other test suites are not affected
        RestAssured.defaultParser = null;
    }

    /**
     * Step 2 - Validate the response using a globally-registered custom parser.
     * Step 3 - Print the response.
     */
    @Test(priority = 1, description = "POST /booking - validate via globally-registered custom parser + print")
    public void validateWithGlobalCustomParser() {

        System.out.println("\n[TEST START] validateWithGlobalCustomParser");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    // These body matchers ONLY work because REST Assured can
                    // parse the response - via the registered JSON parser.
                    .body("bookingid",                  notNullValue())
                    .body("booking.firstname",          equalTo("Jim"))
                    .body("booking.lastname",           equalTo("Brown"))
                    .body("booking.totalprice",         equalTo(111))
                    .body("booking.depositpaid",        equalTo(true))
                    .body("booking.bookingdates.checkin",  equalTo("2018-01-01"))
                    .body("booking.bookingdates.checkout", equalTo("2019-01-01"))
                    .body("booking.additionalneeds",    equalTo("Breakfast"))
                    .extract().response();

        System.out.println("Status code  : " + response.getStatusCode());
        System.out.println("Content-Type : " + response.getContentType());
        System.out.println("Parsed using : globally-registered Parser.JSON");
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());
        System.out.println("[TEST PASSED] Body validated using global custom parser.\n");
    }

    /**
     * Bonus - per-request parser registration via .expect().parser(...).
     * Useful when you don't want to mutate global state.
     */
    @Test(priority = 2, description = "Per-request parser registration via .expect().parser()")
    public void validateWithPerRequestParser() {

        System.out.println("\n[TEST START] validateWithPerRequestParser");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    // Per-request parser registration:
                    .parser("application/vnd.booker.v1+json", Parser.JSON)
                    .parser("application/json",               Parser.JSON)
                    .statusCode(200)
                    .body("booking.firstname", equalTo("Jim"))
                    .body("booking.lastname",  equalTo("Brown"));

        System.out.println("[TEST PASSED] Per-request parser registration succeeded.\n");
    }

    /**
     * Bonus - default parser fallback. If the server returns a content
     * type REST Assured doesn't recognize, the default parser handles it.
     */
    @Test(priority = 3, description = "Default parser fallback for unknown Content-Type")
    public void validateWithDefaultParserFallback() {

        System.out.println("\n[TEST START] validateWithDefaultParserFallback");

        // Default parser is set to Parser.JSON in @BeforeClass
        // Even if a server sent text/plain or some odd type, the JSON
        // parser would still be used (assuming the body is valid JSON).
        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body("booking.totalprice", equalTo(111));

        System.out.println("Default parser (Parser.JSON) is configured as fallback.");
        System.out.println("[TEST PASSED] Default parser fallback succeeded.\n");
    }
}
