# Restful Booker DELETE Booking - REST Assured + TestNG

Maven-based Java project that automates the **"Get the response of DELETE
API request"** scenario using **REST Assured** and **TestNG**. The test
creates a fresh booking via POST, then sends `DELETE /booking/{id}` with
**Basic Auth** (`admin` / `password123`), and verifies the response.

## Scenario

1. **Pre-condition** (in `@BeforeMethod`): POST to `/booking` to create a
   fresh booking and capture its id.
2. DELETE to `https://restful-booker.herokuapp.com/booking/{id}` with:
   - **Basic Auth** header (admin / password123)
   - No request body (DELETE doesn't need one)
3. Verify the response is `201 Created` (Restful Booker quirk - see below).

## IMPORTANT - The Restful Booker DELETE Quirk

The HTTP standard suggests `200 OK` or `204 No Content` for a successful
DELETE. **Restful Booker returns `201 Created` instead**:

```
DELETE /booking/4271
HTTP/1.1 201 Created
```

This is a known idiosyncrasy of the Restful Booker API and **not a
defect** in the test. The test asserts on `201` to match actual server
behaviour. If the test were written assuming the standard 200/204 it
would always fail with a misleading error.

## Why @BeforeMethod (not @BeforeClass)

For PUT and PATCH the booking can be reused across tests because update
operations leave it in place. For DELETE, the booking is **gone after the
operation** - there is nothing left to update or delete in subsequent
tests. The project therefore uses `@BeforeMethod`, which runs before
**every** `@Test` method, creating a brand-new booking and storing its id
in the `bookingId` field.

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                                |
|---------------------------------------------|--------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                             |
| Add a new request                           | New `@Test` method                                     |
| Set the method to DELETE                    | `given().when().delete(ENDPOINT)`                      |
| Set Basic Auth (admin / password123)        | `given().auth().preemptive().basic(USER, PASS)`        |
| Set URL with `:id`                          | `pathParam("id", bookingId).delete("/booking/{id}")`   |
| Click Send → verify response                | `Assert.assertEquals(...)` / fluent `then().body()`    |

## Note on the "Request Body from Input File" Step

The assignment text mentions *"Get the request body from the input file
column"*. DELETE on Restful Booker does **not** take a request body - the
booking to delete is identified solely by the `:id` path parameter. The
"input file column" reference appears to be a copy-paste artefact from
the PUT and PATCH variants of the assignment. This test sends DELETE with
no body, which is the correct usage.

## Why preemptive Basic Auth?

```java
.auth().preemptive().basic(USERNAME, PASSWORD)
```

REST Assured's plain `.basic(user, pass)` waits for the server to send a
`401 Unauthorized` challenge before resending with credentials. Restful
Booker does not issue this challenge - it returns `403 Forbidden`
immediately if the Authorization header is missing. `preemptive()`
attaches the `Authorization: Basic ...` header on the very first request.
Always use `preemptive()` with Restful Booker.

## Project Structure

```
RestfulBookerDeleteBookingTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── RestfulBookerDeleteBookingTest.java
```

## What the Test Class Does

`@BeforeMethod` creates a fresh booking and stores its id in `bookingId`
before every `@Test` method.

| # | Method                              | Purpose                                                                     |
|---|-------------------------------------|-----------------------------------------------------------------------------|
| 1 | `deleteBookingWithBasicAuth`        | Main: DELETE with Basic Auth, asserts `201 Created`.                        |
| 2 | `verifyBookingIsGoneAfterDelete`    | Bonus - DELETE then GET the same id, expect `404 Not Found`.                |
| 3 | `deleteWithoutAuthIsForbidden`      | Bonus - DELETE with no auth, expect `403 Forbidden`.                        |

## Key REST Assured Pattern

```java
// DELETE with preemptive Basic Auth and a path parameter
Response response = given()
        .auth().preemptive().basic("admin", "password123")
        .pathParam("id", bookingId)
    .when()
        .delete("/booking/{id}")
    .then()
        .extract().response();

assertEquals(response.getStatusCode(), 201);  // Restful Booker quirk
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=RestfulBookerDeleteBookingTest#deleteBookingWithBasicAuth
```

## Expected Output (abridged)

```
[BeforeMethod] Created fresh booking id = 4271

[TEST START] deleteBookingWithBasicAuth
Request URL    : https://restful-booker.herokuapp.com/booking/4271
Method         : DELETE
Auth           : Basic (admin / ********)
Status code    : 201
Response time  : 187 ms
Response body  : Created
[TEST PASSED] Booking 4271 deleted (status 201 as Restful Booker returns).

[BeforeMethod] Created fresh booking id = 4272

[TEST START] verifyBookingIsGoneAfterDelete
After delete, GET /booking/4272 returned status 404
[TEST PASSED] Booking is gone (GET returns 404).

[BeforeMethod] Created fresh booking id = 4273

[TEST START] deleteWithoutAuthIsForbidden
Status code (no auth) : 403
[TEST PASSED] DELETE correctly rejected without auth.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- Each test method creates and deletes its own booking, so the test
  suite leaves the server in a clean state.
- Restful Booker resets all booking data every 10 minutes anyway, so any
  bookings the test fails to clean up will be wiped automatically.
- Restful Booker also supports auth via `Cookie: token=<token>` (where the
  token is obtained from POST /auth). This project uses Basic Auth as the
  assignment specifies, but Cookie-based auth is interchangeable.
- If the network is unavailable, all tests will fail with connection errors
  - this is an infrastructure issue, not a code defect.
