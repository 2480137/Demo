package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

/**
 * Hands-On 9: Get the response of DELETE API request - automated with REST Assured.
 *
 * Postman scenario (automated equivalent below):
 *   Method   : DELETE
 *   URL      : https://restful-booker.herokuapp.com/booking/{id}
 *   Auth     : Basic Auth (admin / password123)
 *   Body     : (none - DELETE typically has no body)
 *   Action   : Click Send and verify the response
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. baseURI configured to https://restful-booker.herokuapp.com
 *  4. Booking id obtained from a freshly-created booking (each test creates
 *     its own via @BeforeMethod - DELETE consumes the booking, so reuse
 *     across tests is not possible).
 *  5. DELETE sent with Basic Auth (admin / password123).
 *  6. Status 201 verified (Restful Booker quirk - see note below).
 *
 * IMPORTANT - Restful Booker DELETE quirk:
 *   The HTTP standard suggests 200 OK or 204 No Content for a successful
 *   DELETE. Restful Booker returns 201 Created instead - this is a known
 *   idiosyncrasy of the API and not a defect. The test asserts on 201.
 *
 * Why @BeforeMethod (not @BeforeClass):
 *   DELETE actually removes the booking, so each test needs its own fresh
 *   booking id. @BeforeMethod runs before every @Test method, creating a
 *   new booking each time and storing the id in the bookingId field.
 *
 * Note on the assignment's "request body from input file":
 *   DELETE on Restful Booker does NOT take a request body - the booking
 *   to delete is identified by the URL path parameter alone. The
 *   assignment's mention of an input file column appears to be a copy-
 *   paste artefact from the PUT/PATCH variants. This test sends DELETE
 *   with no body, which is the correct usage.
 */
public class RestfulBookerDeleteBookingTest {

    private static final String BASE_URI         = "https://restful-booker.herokuapp.com";
    private static final String BOOKING_ENDPOINT = "/booking";
    private static final String USERNAME         = "admin";
    private static final String PASSWORD         = "password123";

    /** Booking id created fresh before every test method. */
    private int bookingId;

    /** Body used to create the booking we will then delete. */
    private static final String INITIAL_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2024-01-01\",\n"
            + "    \"checkout\": \"2024-01-10\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void configureBaseUri() {
        // Step 3 - Configure RestAssured base URI once for the class
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    @BeforeMethod
    public void createFreshBooking() {
        // Step 4 - Create a fresh booking for THIS test method.
        // Runs before every @Test, so each test gets its own bookingId.
        Response createResp = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(INITIAL_BODY)
                .when()
                    .post(BOOKING_ENDPOINT)
                .then()
                    .extract().response();

        Assert.assertEquals(createResp.getStatusCode(), 200,
                "FAILED: pre-condition - POST /booking returned "
                        + createResp.getStatusCode() + " (expected 200)");

        bookingId = createResp.jsonPath().getInt("bookingid");
        Assert.assertTrue(bookingId > 0,
                "FAILED: pre-condition - bookingid was not positive");

        System.out.println("\n[BeforeMethod] Created fresh booking id = " + bookingId);
    }

    /**
     * Steps 5-6 - Send DELETE /booking/{id} with Basic Auth and verify the
     * 201 response.
     */
    @Test(priority = 1,
          description = "DELETE /booking/{id} with Basic Auth - delete a booking and verify response")
    public void deleteBookingWithBasicAuth() {

        System.out.println("\n[TEST START] deleteBookingWithBasicAuth");

        // Step 5 - Send DELETE with preemptive Basic Auth
        Response response = RestAssured
                .given()
                    .auth().preemptive().basic(USERNAME, PASSWORD)
                    .pathParam("id", bookingId)
                .when()
                    .delete(BOOKING_ENDPOINT + "/{id}")
                .then()
                    .extract()
                    .response();

        int    statusCode = response.getStatusCode();
        long   timeMs     = response.getTime();
        String body       = response.getBody().asString();

        System.out.println("Request URL    : " + BASE_URI + BOOKING_ENDPOINT + "/" + bookingId);
        System.out.println("Method         : DELETE");
        System.out.println("Auth           : Basic (admin / ********)");
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + timeMs + " ms");
        System.out.println("Response body  : " + (body.isEmpty() ? "(empty)" : body));

        // Step 6 - Status assertion. Restful Booker returns 201 (quirky).
        Assert.assertEquals(statusCode, 201,
                "FAILED: expected 201 (Restful Booker DELETE quirk) but got "
                        + statusCode);

        System.out.println("[TEST PASSED] Booking " + bookingId
                + " deleted (status 201 as Restful Booker returns).\n");
    }

    /**
     * Bonus - confirm the booking is actually GONE after the DELETE by
     * issuing a GET on the same id and asserting it returns 404 Not Found.
     */
    @Test(priority = 2,
          description = "Verify booking is gone after DELETE (subsequent GET returns 404)")
    public void verifyBookingIsGoneAfterDelete() {

        System.out.println("\n[TEST START] verifyBookingIsGoneAfterDelete");

        // Delete it first
        int deleteStatus = RestAssured
                .given()
                    .auth().preemptive().basic(USERNAME, PASSWORD)
                    .pathParam("id", bookingId)
                .when()
                    .delete(BOOKING_ENDPOINT + "/{id}")
                .then()
                    .extract().statusCode();

        Assert.assertEquals(deleteStatus, 201,
                "FAILED: setup DELETE returned " + deleteStatus + " instead of 201");

        // Now GET the same booking - it should return 404
        int getStatus = RestAssured
                .given()
                    .header("Accept", "application/json")
                    .pathParam("id", bookingId)
                .when()
                    .get(BOOKING_ENDPOINT + "/{id}")
                .then()
                    .extract().statusCode();

        System.out.println("After delete, GET /booking/" + bookingId
                + " returned status " + getStatus);

        Assert.assertEquals(getStatus, 404,
                "FAILED: expected 404 Not Found after delete but got " + getStatus);

        System.out.println("[TEST PASSED] Booking is gone (GET returns 404).\n");
    }

    /**
     * Bonus - DELETE requires authentication. Calling DELETE without
     * credentials should return 403 Forbidden. Documents the contract and
     * proves the auth header is actually being checked.
     */
    @Test(priority = 3,
          description = "DELETE /booking/{id} without auth - expect 403 Forbidden")
    public void deleteWithoutAuthIsForbidden() {

        System.out.println("\n[TEST START] deleteWithoutAuthIsForbidden");

        int statusCode = RestAssured
                .given()
                    // intentionally NO auth
                    .pathParam("id", bookingId)
                .when()
                    .delete(BOOKING_ENDPOINT + "/{id}")
                .then()
                    .extract()
                    .statusCode();

        System.out.println("Status code (no auth) : " + statusCode);

        Assert.assertEquals(statusCode, 403,
                "FAILED: expected 403 Forbidden when no auth header is sent, got " + statusCode);

        System.out.println("[TEST PASSED] DELETE correctly rejected without auth.\n");
    }
}
