# Equality Check Validation - REST Assured + TestNG

Maven-based Java project that automates the **"Validating response using
Equality Check in REST Assured"** scenario. It sends a POST to Restful
Booker's `/booking` endpoint and verifies that response field values
**equal** the expected values using REST Assured + Hamcrest's
**`equalTo()`** matcher (and its alias `is()`).

## Scenario

1. Send a **POST** to `https://restful-booker.herokuapp.com/booking` with
   the given booking body.
2. Check that response field values equal specific expected values.
3. Print the response to the console.

```json
{
    "firstname": "Jim",
    "lastname": "Brown",
    "totalprice": 111,
    "depositpaid": true,
    "bookingdates": {
        "checkin":  "2018-01-01",
        "checkout": "2019-01-01"
    },
    "additionalneeds": "Breakfast"
}
```

## What is "Equality Check" in REST Assured?

The simplest and most common assertion - verify that a response field
equals a specific expected value. Two equivalent Hamcrest matchers:

```java
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;

.then()
    .body("booking.firstname", equalTo("Jim"))      // classic Hamcrest
    .body("booking.lastname",  is("Brown"));         // alias - reads more naturally
```

`equalTo()` is the classic JUnit/Hamcrest name. `is()` is its alias and
reads more like English: *"booking firstname **is** Jim"*.

Both compare using Java's `.equals()` method under the hood.

## Equality Checks Across Different Types

`equalTo()` works uniformly with any Java type. **Critical: the type must
match** - the API returns 111 as an integer, not a string, so:

```java
.body("booking.totalprice",  equalTo(111))       // CORRECT
.body("booking.totalprice",  equalTo("111"))     // FAILS - type mismatch
.body("booking.depositpaid", equalTo(true))      // CORRECT (boolean)
.body("booking.depositpaid", equalTo("true"))    // FAILS - type mismatch
.body("booking.firstname",   equalTo("Jim"))     // CORRECT (string)
```

## Three Ways to Express the Same Equality Check

```java
// Form 1 - Hamcrest equalTo() in the chain
.then().body("booking.firstname", equalTo("Jim"));

// Form 2 - Hamcrest is() in the chain (alias)
.then().body("booking.firstname", is("Jim"));

// Form 3 - Extract + TestNG Assert.assertEquals
String firstname = response.jsonPath().getString("booking.firstname");
Assert.assertEquals(firstname, "Jim");
```

All three are functionally equivalent. The chain forms are more compact
and integrate with the .then() flow; the extract+assert form is more
flexible when the comparison needs custom logic.

## Project Structure

```
RestfulBookerEqualityCheckTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── EqualityCheckTest.java
```

## What the Test Class Does

| # | Method                                   | Purpose                                                                            |
|---|------------------------------------------|------------------------------------------------------------------------------------|
| 1 | `verifyResponseValuesUsingEqualTo`       | Main: 7 chained `equalTo()` checks on every echoed field + print response.          |
| 2 | `verifyResponseValuesUsingIs`            | Bonus - same checks expressed with the `is()` alias.                                |
| 3 | `verifyExtractedValuesWithAssertEquals`  | Bonus - extract response, compare with TestNG `Assert.assertEquals`.                |
| 4 | `verifyEqualityAcrossTypes`              | Bonus - `equalTo()` with String, Integer, and Boolean types.                        |

## Key REST Assured Patterns

```java
// 1. The canonical idiom (this assignment's specific ask)
.then()
    .body("booking.firstname",                equalTo("Jim"))
    .body("booking.lastname",                 equalTo("Brown"))
    .body("booking.totalprice",               equalTo(111))
    .body("booking.depositpaid",              equalTo(true))
    .body("booking.bookingdates.checkin",     equalTo("2018-01-01"))
    .body("booking.bookingdates.checkout",    equalTo("2019-01-01"))
    .body("booking.additionalneeds",          equalTo("Breakfast"));

// 2. The is() alias (reads more naturally)
.then()
    .body("booking.firstname", is("Jim"))
    .body("booking.totalprice", is(111));

// 3. TestNG Assert.assertEquals on extracted values
String firstname = response.jsonPath().getString("booking.firstname");
Assert.assertEquals(firstname, "Jim", "firstname mismatch");
```

## Equality Check vs Other Validation Methods

This project covers ONLY the equalTo / is matchers. Where they fit in
the full REST Assured validation toolbox:

| Matcher type        | Example                          | Use for                        |
|---------------------|----------------------------------|--------------------------------|
| **Equality**        | `equalTo("Jim")`, `is("Jim")`    | Exact value match              |
| Negated equality    | `not(equalTo("X"))`              | Field does NOT equal X         |
| Substring           | `containsString("im")`           | Substring within a string      |
| Numeric range       | `greaterThan(0)`, `lessThan(N)`  | Number bounds                  |
| Existence           | `notNullValue()`                 | Field present, not null        |
| Collection size     | `hasSize(N)`                     | Array length                   |
| Multiple options    | `anyOf(is("X"), is("Y"))`        | Value is one of these          |

The assignment scope is the equality check (the first row).

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request, set POST + URL + body    | `given().body(...).when().post(...)`                 |
| `pm.expect(jsonData.firstname).to.eql("Jim")`| `.body("firstname", equalTo("Jim"))`                |
| `pm.expect(jsonData.firstname).to.equal("Jim")` | `.body("firstname", is("Jim"))`                  |

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=EqualityCheckTest#verifyResponseValuesUsingEqualTo
```

## Expected Output (abridged)

```
[TEST START] verifyResponseValuesUsingEqualTo
Verifying response values via Hamcrest equalTo().
Request URL    : https://restful-booker.herokuapp.com/booking
Status code    : 200

--- Equality checks that succeeded (expected ==  actual) ---
  booking.firstname              : Jim         == Jim
  booking.lastname               : Brown       == Brown
  booking.totalprice             : 111         == 111
  booking.depositpaid            : true        == true
  booking.bookingdates.checkin   : 2018-01-01  == 2018-01-01
  booking.bookingdates.checkout  : 2019-01-01  == 2019-01-01
  booking.additionalneeds        : Breakfast   == Breakfast

--- Pretty-printed response body ---
{
    "bookingid": 4271,
    "booking": {
        "firstname": "Jim",
        "lastname": "Brown",
        "totalprice": 111,
        "depositpaid": true,
        "bookingdates": { "checkin": "2018-01-01", "checkout": "2019-01-01" },
        "additionalneeds": "Breakfast"
    }
}
[TEST PASSED] All equalTo() equality checks succeeded.

===============================================
Total tests run: 4, Passes: 4, Failures: 0
===============================================
```

## Notes

- POST /booking on Restful Booker returns **200 OK**, not 201 Created.
- `equalTo()` compares with `.equals()` - case-sensitive for strings;
  type-sensitive across all Java types.
- For numeric fields, the API's actual type matters: integer fields
  must be matched with `equalTo(<int>)`, not `equalTo("<int as string>")`.
- This is a focused subset of Hands-On 10 (full field-by-field validation).
  Equality is one specific matcher type; Hands-On 10 covered the broader
  family.
- If the network is unavailable, all tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
