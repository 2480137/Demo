package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;

/**
 * Hands-On 13: Validating response using Equality Check in REST Assured.
 *
 * Scenario:
 *   Method   : POST
 *   URL      : https://restful-booker.herokuapp.com/booking
 *   Auth     : none
 *   Body     : { firstname, lastname, totalprice, depositpaid,
 *                bookingdates: { checkin, checkout },
 *                additionalneeds }
 *   Goal     : Check that response values EQUAL specific expected values
 *              using REST Assured + Hamcrest equality matchers.
 *
 * Steps covered:
 *  1. POST /booking sent through REST Assured.
 *  2. Each field of the response checked for EQUALITY against an expected
 *     value using equalTo() (or its alias is()).
 *  3. Response printed to the console.
 *
 * About equality checks in REST Assured:
 *
 *   The simplest and most common assertion is to verify that a response
 *   field exactly equals a specific value. Two equivalent Hamcrest
 *   matchers are used for this:
 *
 *      org.hamcrest.Matchers.equalTo(expected)
 *      org.hamcrest.Matchers.is(expected)            // alias - same thing
 *
 *   Both are passed to .body(path, matcher) in the .then() chain:
 *
 *      .then()
 *          .body("booking.firstname", equalTo("Jim"))
 *          .body("booking.lastname",  is("Brown"))
 *          .body("booking.totalprice", equalTo(111));
 *
 *   equalTo() is the classic JUnit/Hamcrest name; is() reads more
 *   naturally inside the chain ("body firstname is Jim"). Both compare
 *   using Java's .equals() under the hood.
 */
public class EqualityCheckTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    /** Step 1 - The exact request body specified in the assignment. */
    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Steps 2-3 - Send POST and verify each response value EQUALS the
     * expected value using equalTo(), then print the response.
     */
    @Test(priority = 1,
          description = "POST /booking - equality checks with equalTo() + print response")
    public void verifyResponseValuesUsingEqualTo() {

        System.out.println("\n[TEST START] verifyResponseValuesUsingEqualTo");
        System.out.println("Verifying response values via Hamcrest equalTo().");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    // Step 2 - equality check on every echoed field
                    .body("booking.firstname",                equalTo("Jim"))
                    .body("booking.lastname",                 equalTo("Brown"))
                    .body("booking.totalprice",               equalTo(111))
                    .body("booking.depositpaid",              equalTo(true))
                    .body("booking.bookingdates.checkin",     equalTo("2018-01-01"))
                    .body("booking.bookingdates.checkout",    equalTo("2019-01-01"))
                    .body("booking.additionalneeds",          equalTo("Breakfast"))
                    .extract()
                    .response();

        // Step 3 - Print the response for console visibility
        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Status code    : " + response.getStatusCode());

        System.out.println("\n--- Equality checks that succeeded (expected ==  actual) ---");
        System.out.println("  booking.firstname              : Jim         == "
                + response.jsonPath().getString("booking.firstname"));
        System.out.println("  booking.lastname               : Brown       == "
                + response.jsonPath().getString("booking.lastname"));
        System.out.println("  booking.totalprice             : 111         == "
                + response.jsonPath().getInt("booking.totalprice"));
        System.out.println("  booking.depositpaid            : true        == "
                + response.jsonPath().getBoolean("booking.depositpaid"));
        System.out.println("  booking.bookingdates.checkin   : 2018-01-01  == "
                + response.jsonPath().getString("booking.bookingdates.checkin"));
        System.out.println("  booking.bookingdates.checkout  : 2019-01-01  == "
                + response.jsonPath().getString("booking.bookingdates.checkout"));
        System.out.println("  booking.additionalneeds        : Breakfast   == "
                + response.jsonPath().getString("booking.additionalneeds"));

        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        System.out.println("[TEST PASSED] All equalTo() equality checks succeeded.\n");
    }

    /**
     * Bonus - is() is the alias of equalTo(). Reads more naturally:
     *   "body booking.firstname IS Jim"
     */
    @Test(priority = 2,
          description = "POST /booking - equality checks using the is() alias")
    public void verifyResponseValuesUsingIs() {

        System.out.println("\n[TEST START] verifyResponseValuesUsingIs");
        System.out.println("Same equality checks expressed with the is() alias for natural reading.");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body("booking.firstname",                is("Jim"))
                    .body("booking.lastname",                 is("Brown"))
                    .body("booking.totalprice",               is(111))
                    .body("booking.depositpaid",              is(true))
                    .body("booking.bookingdates.checkin",     is("2018-01-01"))
                    .body("booking.bookingdates.checkout",    is("2019-01-01"))
                    .body("booking.additionalneeds",          is("Breakfast"));

        System.out.println("[TEST PASSED] All is() equality checks succeeded.\n");
    }

    /**
     * Bonus - alternative pattern: extract response and compare values
     * using TestNG's Assert.assertEquals. Useful when the comparison
     * needs custom logic (e.g. comparing trimmed strings, computed
     * expected values, etc.).
     */
    @Test(priority = 3,
          description = "POST /booking - extract response, then equality via TestNG Assert.assertEquals")
    public void verifyExtractedValuesWithAssertEquals() {

        System.out.println("\n[TEST START] verifyExtractedValuesWithAssertEquals");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract()
                    .response();

        Assert.assertEquals(response.getStatusCode(), 200,
                "FAILED: pre-condition status code");

        // Extract each field and compare with TestNG Assert.assertEquals
        String  firstname  = response.jsonPath().getString("booking.firstname");
        String  lastname   = response.jsonPath().getString("booking.lastname");
        Integer totalprice = response.jsonPath().getInt("booking.totalprice");
        Boolean depositpaid= response.jsonPath().getBoolean("booking.depositpaid");
        String  checkin    = response.jsonPath().getString("booking.bookingdates.checkin");
        String  checkout   = response.jsonPath().getString("booking.bookingdates.checkout");
        String  needs      = response.jsonPath().getString("booking.additionalneeds");

        Assert.assertEquals(firstname,   "Jim",        "FAILED: firstname mismatch");
        Assert.assertEquals(lastname,    "Brown",      "FAILED: lastname mismatch");
        Assert.assertEquals(totalprice,  Integer.valueOf(111), "FAILED: totalprice mismatch");
        Assert.assertEquals(depositpaid, Boolean.TRUE, "FAILED: depositpaid mismatch");
        Assert.assertEquals(checkin,  "2018-01-01",    "FAILED: checkin mismatch");
        Assert.assertEquals(checkout, "2019-01-01",    "FAILED: checkout mismatch");
        Assert.assertEquals(needs,    "Breakfast",     "FAILED: additionalneeds mismatch");

        System.out.println("All 7 fields matched expected values.");
        System.out.println("[TEST PASSED] TestNG Assert.assertEquals form succeeded.\n");
    }

    /**
     * Bonus - equality checks across different value types. Demonstrates
     * that equalTo() works uniformly with String, Integer, and Boolean
     * (and any other Comparable / Object type).
     */
    @Test(priority = 4,
          description = "POST /booking - equalTo() with String, Integer, and Boolean types")
    public void verifyEqualityAcrossTypes() {

        System.out.println("\n[TEST START] verifyEqualityAcrossTypes");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(200)
                    // String equality
                    .body("booking.firstname",   equalTo("Jim"))
                    // Integer equality - note: NOT equalTo("111")
                    .body("booking.totalprice",  equalTo(111))
                    // Boolean equality - note: NOT equalTo("true")
                    .body("booking.depositpaid", equalTo(true));

        System.out.println("Equality checks succeeded across String / Integer / Boolean types.");
        System.out.println("Note: types must MATCH - equalTo(111) is NOT the same as equalTo(\"111\")");
        System.out.println("[TEST PASSED] Cross-type equality checks succeeded.\n");
    }
}
