# Existence Check - REST Assured + TestNG

POST /booking on Restful Booker, check if keys exist in the response.

## Existence Matchers

| Matcher                          | Use for                          |
|----------------------------------|----------------------------------|
| `notNullValue()`                 | Field exists and is not null     |
| `hasKey("name")`                 | Map contains the named key       |
| `not(hasKey("name"))` / `nullValue()` | Field does NOT exist        |
| `hasEntry("k", value)`           | Key exists AND has expected value|

## Test Methods

| # | Method                              | Purpose                                                  |
|---|-------------------------------------|----------------------------------------------------------|
| 1 | `verifyKeysExistInResponse`         | 10 `notNullValue()` + 10 `hasKey()` + print response.    |
| 2 | `verifyNonExistentKey`              | `not(hasKey)` + `nullValue` for absent fields.           |
| 3 | `verifyKeysExistViaExtractAndAssert`| Extract Map, check `containsKey()` with TestNG Assert.   |
| 4 | `verifyKeyAndValueWithHasEntry`     | `hasEntry(key, value)` - existence + value in one matcher.|

## Run

```bash
mvn clean test
```
