package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.Map;

import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.hasEntry;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.nullValue;

/**
 * Hands-On 15: Validating response using Existence Check in REST Assured.
 *
 * Goal: Check if a key exists in the response.
 *
 * Two equivalent ways:
 *   1. .body(path, notNullValue())             - field exists and is not null
 *   2. .body(parentPath, hasKey("childKey"))   - parent map contains the key
 *
 * Plus negative checks:
 *   3. .body(path, nullValue()) or .body(parent, not(hasKey("X")))
 */
public class ExistenceCheckTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 2 - Check if keys exist in the response (notNullValue + hasKey).
     * Step 3 - Print the response in the console.
     */
    @Test(priority = 1, description = "POST /booking - existence checks via notNullValue + hasKey + print")
    public void verifyKeysExistInResponse() {

        System.out.println("\n[TEST START] verifyKeysExistInResponse");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    // ---- Existence checks via notNullValue() ----
                    .body("bookingid",                          notNullValue())
                    .body("booking",                            notNullValue())
                    .body("booking.firstname",                  notNullValue())
                    .body("booking.lastname",                   notNullValue())
                    .body("booking.totalprice",                 notNullValue())
                    .body("booking.depositpaid",                notNullValue())
                    .body("booking.bookingdates",               notNullValue())
                    .body("booking.bookingdates.checkin",       notNullValue())
                    .body("booking.bookingdates.checkout",      notNullValue())
                    .body("booking.additionalneeds",            notNullValue())
                    // ---- Existence checks via hasKey() (Map matcher) ----
                    .body("$",                                  hasKey("bookingid"))
                    .body("$",                                  hasKey("booking"))
                    .body("booking",                            hasKey("firstname"))
                    .body("booking",                            hasKey("lastname"))
                    .body("booking",                            hasKey("totalprice"))
                    .body("booking",                            hasKey("depositpaid"))
                    .body("booking",                            hasKey("bookingdates"))
                    .body("booking",                            hasKey("additionalneeds"))
                    .body("booking.bookingdates",               hasKey("checkin"))
                    .body("booking.bookingdates",               hasKey("checkout"))
                    .extract().response();

        System.out.println("Request URL : " + BASE_URI + ENDPOINT);
        System.out.println("Status code : " + response.getStatusCode());

        System.out.println("\n--- Keys verified to exist ---");
        System.out.println("  bookingid, booking");
        System.out.println("  booking.firstname, booking.lastname, booking.totalprice");
        System.out.println("  booking.depositpaid, booking.bookingdates, booking.additionalneeds");
        System.out.println("  booking.bookingdates.checkin, booking.bookingdates.checkout");

        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        System.out.println("[TEST PASSED] All existence checks succeeded.\n");
    }

    /**
     * Bonus - negative existence: a key that should NOT be in the response.
     */
    @Test(priority = 2, description = "POST /booking - non-existent key check via not(hasKey) + nullValue")
    public void verifyNonExistentKey() {

        System.out.println("\n[TEST START] verifyNonExistentKey");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    // booking has NO 'roomNumber' field
                    .body("booking",                  not(hasKey("roomNumber")))
                    .body("booking.roomNumber",       nullValue())
                    // top-level has NO 'errors' field
                    .body("$",                        not(hasKey("errors")))
                    .body("errors",                   nullValue());

        System.out.println("Verified that 'roomNumber' (under booking) and 'errors' (top-level) do NOT exist.");
        System.out.println("[TEST PASSED] Non-existent keys correctly absent.\n");
    }

    /**
     * Bonus - extract response, then check existence with TestNG.
     */
    @Test(priority = 3, description = "POST /booking - extract + existence check via TestNG Assert")
    public void verifyKeysExistViaExtractAndAssert() {

        System.out.println("\n[TEST START] verifyKeysExistViaExtractAndAssert");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract().response();

        Map<String, Object> top     = response.jsonPath().getMap("$");
        Map<String, Object> booking = response.jsonPath().getMap("booking");
        Map<String, Object> dates   = response.jsonPath().getMap("booking.bookingdates");

        Assert.assertTrue(top.containsKey("bookingid"),   "FAILED: 'bookingid' missing");
        Assert.assertTrue(top.containsKey("booking"),     "FAILED: 'booking' missing");
        Assert.assertTrue(booking.containsKey("firstname"),       "FAILED: 'firstname' missing");
        Assert.assertTrue(booking.containsKey("lastname"),        "FAILED: 'lastname' missing");
        Assert.assertTrue(booking.containsKey("totalprice"),      "FAILED: 'totalprice' missing");
        Assert.assertTrue(booking.containsKey("depositpaid"),     "FAILED: 'depositpaid' missing");
        Assert.assertTrue(booking.containsKey("bookingdates"),    "FAILED: 'bookingdates' missing");
        Assert.assertTrue(booking.containsKey("additionalneeds"), "FAILED: 'additionalneeds' missing");
        Assert.assertTrue(dates.containsKey("checkin"),   "FAILED: 'checkin' missing");
        Assert.assertTrue(dates.containsKey("checkout"),  "FAILED: 'checkout' missing");

        System.out.println("All 10 keys verified via TestNG Assert + Map.containsKey.");
        System.out.println("[TEST PASSED] Extract+Assert existence checks succeeded.\n");
    }

    /**
     * Bonus - hasEntry: existence + value in one matcher.
     */
    @Test(priority = 4, description = "POST /booking - hasEntry checks key+value together")
    public void verifyKeyAndValueWithHasEntry() {

        System.out.println("\n[TEST START] verifyKeyAndValueWithHasEntry");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body("booking", hasEntry("firstname",  "Jim"))
                    .body("booking", hasEntry("lastname",   "Brown"))
                    .body("booking", hasEntry("totalprice", 111))
                    .body("booking", hasEntry("depositpaid", true))
                    .body("booking", hasEntry("additionalneeds", "Breakfast"));

        System.out.println("[TEST PASSED] hasEntry (key+value) checks succeeded.\n");
    }
}
