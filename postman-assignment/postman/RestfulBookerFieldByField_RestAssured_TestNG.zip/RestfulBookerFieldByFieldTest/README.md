# Field-by-Field Validation - REST Assured + TestNG

Maven-based Java project that automates the **"Field-by-Field Validation
in REST Assured"** scenario. It sends a POST to Restful Booker's
`/booking` endpoint and validates **every individual field** of the JSON
response using REST Assured's **`body(String path, Matcher matcher)`**
method - the most fundamental REST Assured assertion idiom.

## Scenario

1. Send a **POST** to `https://restful-booker.herokuapp.com/booking` with
   the given booking body.
2. Validate each individual field of the JSON response using
   `.body(path, matcher)`.
3. Print the response to the console.

```json
{
    "firstname": "Jim",
    "lastname": "Brown",
    "totalprice": 111,
    "depositpaid": true,
    "bookingdates": {
        "checkin":  "2018-01-01",
        "checkout": "2019-01-01"
    },
    "additionalneeds": "Breakfast"
}
```

## What is REST Assured's `.body(String path, Matcher matcher)`?

The `ValidatableResponse` interface (returned by `.then()`) exposes:

```java
ValidatableResponse body(String path, Matcher<?> matcher);
```

It validates a **single JSON field**, identified by its dotted path, against
a Hamcrest matcher:

```java
.then()
    .body("booking.firstname", equalTo("Jim"))
    .body("booking.totalprice", equalTo(111));
```

## Path Syntax (GPath / JsonPath dot notation)

| JSON shape                                  | Path expression                       |
|---------------------------------------------|---------------------------------------|
| `{ "x": 1 }`                                | `"x"`                                 |
| `{ "a": { "b": 1 } }`                       | `"a.b"`                               |
| `{ "a": { "b": { "c": 1 } } }`              | `"a.b.c"`                             |
| `{ "items": [{"name":"x"}, ...] }`          | `"items[0].name"`                     |
| `{ "items": [...] }` (last element)         | `"items[-1]"`                         |
| `{ "items": [...] }` (size)                 | `"items.size()"`                      |
| `{ "data": { "CPU model": "i9" } }`         | `"data.\"CPU model\""` (escape spaces)|

## Response Shape & Path Examples

The Restful Booker POST /booking response:

```json
{
    "bookingid": 4271,
    "booking": {
        "firstname": "Jim",
        "lastname": "Brown",
        "totalprice": 111,
        "depositpaid": true,
        "bookingdates": { "checkin": "2018-01-01", "checkout": "2019-01-01" },
        "additionalneeds": "Breakfast"
    }
}
```

Fields validated by this project:

| Path                                  | Matcher                  | Field value         |
|---------------------------------------|--------------------------|---------------------|
| `bookingid`                           | `greaterThan(0)`         | server-assigned int |
| `booking`                             | `notNullValue()`         | nested object       |
| `booking.firstname`                   | `equalTo("Jim")`         | "Jim"               |
| `booking.lastname`                    | `equalTo("Brown")`       | "Brown"             |
| `booking.totalprice`                  | `equalTo(111)`           | 111                 |
| `booking.depositpaid`                 | `equalTo(true)`          | true                |
| `booking.bookingdates.checkin`        | `equalTo("2018-01-01")`  | "2018-01-01"        |
| `booking.bookingdates.checkout`       | `equalTo("2019-01-01")`  | "2019-01-01"        |
| `booking.additionalneeds`             | `equalTo("Breakfast")`   | "Breakfast"         |

## Project Structure

```
RestfulBookerFieldByFieldTest/
├── pom.xml                                       # Maven dependencies
├── testng.xml                                    # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── FieldByFieldValidationTest.java
```

## What the Test Class Does

| # | Method                                  | Purpose                                                                            |
|---|-----------------------------------------|------------------------------------------------------------------------------------|
| 1 | `validateEveryFieldUsingBodyMatcher`    | Main: 9 chained `.body(path, matcher)` calls + extract + print response.            |
| 2 | `validateFieldsViaExtractAndAssert`     | Bonus - extract first, then validate each field with TestNG `Assert`.               |
| 3 | `validateFieldsWithVariousMatchers`     | Bonus - 11 different Hamcrest matcher flavours across the response fields.          |
| 4 | `validateFieldsWithVariadicBodyOverload`| Bonus - variadic `.body(p1, m1, p2, m2, ...)` form for compact multi-field check.   |

## Key REST Assured Patterns

```java
// 1. The canonical idiom (this assignment's specific ask)
.then()
    .body("bookingid",                  greaterThan(0))
    .body("booking.firstname",          equalTo("Jim"))
    .body("booking.lastname",           equalTo("Brown"))
    .body("booking.totalprice",         equalTo(111))
    .body("booking.depositpaid",        equalTo(true))
    .body("booking.bookingdates.checkin",  equalTo("2018-01-01"))
    .body("booking.bookingdates.checkout", equalTo("2019-01-01"))
    .body("booking.additionalneeds",    equalTo("Breakfast"));

// 2. Variadic .body(...) for many fields in one call
.then().body(
    "booking.firstname",          equalTo("Jim"),
    "booking.lastname",           equalTo("Brown"),
    "booking.totalprice",         equalTo(111));

// 3. Extract + JsonPath + TestNG Assert (alternative pattern)
Response r = ...post().then().extract().response();
String firstname = r.jsonPath().getString("booking.firstname");
Assert.assertEquals(firstname, "Jim");
```

## Common Hamcrest Matchers for Field Validation

| Matcher                                   | Use for                              |
|-------------------------------------------|--------------------------------------|
| `equalTo(value)` / `is(value)`            | Exact match                          |
| `notNullValue()`                          | Field exists / is not null           |
| `containsString(substr)`                  | Substring check on string fields     |
| `startsWith(...)` / `endsWith(...)`       | Prefix / suffix on strings           |
| `greaterThan(N)` / `lessThan(N)`          | Numeric ranges                       |
| `hasSize(N)`                              | Array length                         |
| `everyItem(matcher)`                      | Apply a matcher to every array item  |
| `hasItem(matcher)`                        | At least one item matches            |
| `not(otherMatcher)`                       | Negation                             |
| `anyOf(m1, m2)` / `allOf(m1, m2)`         | Boolean combinations                 |

## Postman → REST Assured Mapping

| Postman step                                   | REST Assured equivalent                              |
|------------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection          | Maven project + test class                           |
| Add a new request, set POST + URL + body       | `given().body(...).when().post(...)`                 |
| Tests tab: `pm.expect(jsonData.firstname).to.eql("Jim")` | `.body("firstname", equalTo("Jim"))`               |
| Multiple `pm.expect` calls                     | Multiple chained `.body(...)` calls                  |

## Field-by-Field vs Schema vs Header Validation

This is part of the validation family covered in Hands-On 7-10:

| Hands-On | Method                              | Validates                          |
|----------|-------------------------------------|------------------------------------|
| 7        | `.header(name, matcher)`            | One header                         |
| 8        | `.headers(name1, m1, name2, m2, ...)` | Multiple headers in one call       |
| 9        | `.body(matchesJsonSchemaInClasspath)` | Whole-body shape (JSON Schema)     |
| 10       | `.body(path, matcher)`              | **Individual fields** (this one)   |

Schema (Hands-On 9) proves the **shape** of the response.
Field-by-field validation (this Hands-On 10) proves the **data**.
They are complementary - real test suites usually use both.

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=FieldByFieldValidationTest#validateEveryFieldUsingBodyMatcher
```

## Expected Output (abridged)

```
[TEST START] validateEveryFieldUsingBodyMatcher
Request URL    : https://restful-booker.herokuapp.com/booking
Status code    : 200
Status line    : HTTP/1.1 200 OK

--- Validated fields ---
  bookingid                     : 4271
  booking.firstname             : Jim
  booking.lastname              : Brown
  booking.totalprice            : 111
  booking.depositpaid           : true
  booking.bookingdates.checkin  : 2018-01-01
  booking.bookingdates.checkout : 2019-01-01
  booking.additionalneeds       : Breakfast

--- Pretty-printed response body ---
{
    "bookingid": 4271,
    "booking": { ... }
}
[TEST PASSED] All 9 fields validated via .body(path, matcher).

===============================================
Total tests run: 4, Passes: 4, Failures: 0
===============================================
```

## Notes

- POST /booking on Restful Booker returns **200 OK**, not 201 Created.
- The path syntax is REST Assured's GPath (similar to JsonPath but slightly
  different in places - see the path syntax table above).
- For deeply nested or array-heavy responses, prefer this field-by-field
  approach over JSON Schema when assertions need to be value-specific
  (not just shape-specific).
- If the network is unavailable, all tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
