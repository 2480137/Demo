package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Hands-On 10: Field-by-Field Validation in REST Assured.
 *
 * Scenario:
 *   Method   : POST
 *   URL      : https://restful-booker.herokuapp.com/booking
 *   Auth     : none
 *   Body     : { firstname, lastname, totalprice, depositpaid,
 *                bookingdates: { checkin, checkout },
 *                additionalneeds }
 *   Goal     : Validate INDIVIDUAL fields of the JSON response using
 *              REST Assured's body(String path, Matcher<?> matcher) method.
 *
 * Steps covered:
 *  1. POST /booking sent through REST Assured.
 *  2. Each field of the response validated using .body(path, matcher).
 *  3. Response printed to the console.
 *
 * About REST Assured's body(String path, Matcher matcher) method:
 *
 *   The ValidatableResponse interface (returned by .then()) exposes:
 *
 *      ValidatableResponse body(String path, Matcher<?> matcher);
 *
 *   This validates a single JSON field, identified by its dotted GPath /
 *   JsonPath expression, against a Hamcrest matcher:
 *
 *      .then().body("booking.firstname", equalTo("Jim"));
 *
 *   The path syntax:
 *      - Top-level field      -> "bookingid"
 *      - Nested field         -> "booking.firstname"
 *      - Deeper nested field  -> "booking.bookingdates.checkin"
 *      - Array element        -> "items[0].name"
 *      - Field with special chars -> "data.\"CPU model\""
 *
 *   Multiple .body(path, matcher) calls can be chained for full
 *   field-by-field validation:
 *
 *      .then()
 *          .body("bookingid",                  greaterThan(0))
 *          .body("booking.firstname",          equalTo("Jim"))
 *          .body("booking.lastname",           equalTo("Brown"))
 *          .body("booking.totalprice",         equalTo(111))
 *          .body("booking.depositpaid",        equalTo(true));
 *
 *   This is the most fundamental REST Assured assertion idiom for
 *   validating response data field by field.
 *
 * Response shape:
 *   {
 *     "bookingid": <int>,
 *     "booking": {
 *       "firstname": "Jim",
 *       "lastname":  "Brown",
 *       "totalprice": 111,
 *       "depositpaid": true,
 *       "bookingdates": { "checkin": "2018-01-01", "checkout": "2019-01-01" },
 *       "additionalneeds": "Breakfast"
 *     }
 *   }
 */
public class FieldByFieldValidationTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    /** Step 1 - The exact request body specified in the assignment. */
    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Steps 2-3 - Validate every field of the response using
     * .body(path, matcher), then print the response.
     *
     * This is the canonical "field-by-field validation" pattern - one
     * .body() call per field, chained inside .then().
     */
    @Test(priority = 1,
          description = "POST /booking - validate every field with .body(path, matcher) + print response")
    public void validateEveryFieldUsingBodyMatcher() {

        System.out.println("\n[TEST START] validateEveryFieldUsingBodyMatcher");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    // Step 2 - Field-by-field validation. One .body() per field.
                    .body("bookingid",                       greaterThan(0))            // top-level
                    .body("booking",                         notNullValue())            // nested object
                    .body("booking.firstname",               equalTo("Jim"))            // nested string
                    .body("booking.lastname",                equalTo("Brown"))          // nested string
                    .body("booking.totalprice",              equalTo(111))              // nested number
                    .body("booking.depositpaid",             equalTo(true))             // nested boolean
                    .body("booking.bookingdates.checkin",    equalTo("2018-01-01"))     // doubly-nested
                    .body("booking.bookingdates.checkout",   equalTo("2019-01-01"))     // doubly-nested
                    .body("booking.additionalneeds",         equalTo("Breakfast"))      // optional string
                    .extract()
                    .response();

        // Step 3 - Print the response for console visibility
        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Status code    : " + response.getStatusCode());
        System.out.println("Status line    : " + response.getStatusLine());

        System.out.println("\n--- Validated fields ---");
        System.out.println("  bookingid                     : " + response.jsonPath().getInt("bookingid"));
        System.out.println("  booking.firstname             : " + response.jsonPath().getString("booking.firstname"));
        System.out.println("  booking.lastname              : " + response.jsonPath().getString("booking.lastname"));
        System.out.println("  booking.totalprice            : " + response.jsonPath().getInt("booking.totalprice"));
        System.out.println("  booking.depositpaid           : " + response.jsonPath().getBoolean("booking.depositpaid"));
        System.out.println("  booking.bookingdates.checkin  : " + response.jsonPath().getString("booking.bookingdates.checkin"));
        System.out.println("  booking.bookingdates.checkout : " + response.jsonPath().getString("booking.bookingdates.checkout"));
        System.out.println("  booking.additionalneeds       : " + response.jsonPath().getString("booking.additionalneeds"));

        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        System.out.println("[TEST PASSED] All 9 fields validated via .body(path, matcher).\n");
    }

    /**
     * Bonus - the same validation expressed by extracting the response
     * first and using JsonPath + TestNG Assert. Some teams prefer this
     * style when the validations get complex (e.g. each field needs
     * multiple checks or conditional logic).
     */
    @Test(priority = 2,
          description = "POST /booking - extract response, then validate each field with TestNG Assert")
    public void validateFieldsViaExtractAndAssert() {

        System.out.println("\n[TEST START] validateFieldsViaExtractAndAssert");

        // Extract the response first
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract()
                    .response();

        Assert.assertEquals(response.getStatusCode(), 200,
                "FAILED: pre-condition status code");

        // Now extract and assert each field individually
        Integer bookingId   = response.jsonPath().getInt("bookingid");
        String  firstname   = response.jsonPath().getString("booking.firstname");
        String  lastname    = response.jsonPath().getString("booking.lastname");
        Integer totalprice  = response.jsonPath().getInt("booking.totalprice");
        Boolean depositpaid = response.jsonPath().getBoolean("booking.depositpaid");
        String  checkin     = response.jsonPath().getString("booking.bookingdates.checkin");
        String  checkout    = response.jsonPath().getString("booking.bookingdates.checkout");
        String  needs       = response.jsonPath().getString("booking.additionalneeds");

        System.out.println("\n--- Field-by-field validation via TestNG Assert ---");

        Assert.assertNotNull(bookingId,        "FAILED: bookingid was null");
        Assert.assertTrue(bookingId > 0,       "FAILED: bookingid should be > 0, got " + bookingId);
        System.out.println("  bookingid OK: " + bookingId);

        Assert.assertEquals(firstname,  "Jim",   "FAILED: firstname did not round-trip");
        System.out.println("  firstname OK: " + firstname);

        Assert.assertEquals(lastname,   "Brown", "FAILED: lastname did not round-trip");
        System.out.println("  lastname  OK: " + lastname);

        Assert.assertEquals(totalprice, Integer.valueOf(111), "FAILED: totalprice did not round-trip");
        System.out.println("  totalprice OK: " + totalprice);

        Assert.assertEquals(depositpaid, Boolean.TRUE, "FAILED: depositpaid did not round-trip");
        System.out.println("  depositpaid OK: " + depositpaid);

        Assert.assertEquals(checkin,  "2018-01-01", "FAILED: checkin did not round-trip");
        System.out.println("  checkin  OK: " + checkin);

        Assert.assertEquals(checkout, "2019-01-01", "FAILED: checkout did not round-trip");
        System.out.println("  checkout OK: " + checkout);

        Assert.assertEquals(needs, "Breakfast", "FAILED: additionalneeds did not round-trip");
        System.out.println("  additionalneeds OK: " + needs);

        System.out.println("[TEST PASSED] All 8 fields validated via extract + TestNG Assert.\n");
    }

    /**
     * Bonus - the same fields validated with a richer mix of Hamcrest
     * matchers, showing that .body(path, matcher) accepts any matcher
     * appropriate for the field type.
     */
    @Test(priority = 3,
          description = "POST /booking - validate fields with various Hamcrest matchers")
    public void validateFieldsWithVariousMatchers() {

        System.out.println("\n[TEST START] validateFieldsWithVariousMatchers");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(200)
                    // Different matcher types for different fields:
                    .body("bookingid",                  is(notNullValue()))             // existence
                    .body("bookingid",                  greaterThan(0))                 // numeric
                    .body("booking",                    notNullValue())                 // sub-object exists
                    .body("booking.firstname",          equalTo("Jim"))                 // exact match
                    .body("booking.firstname",          containsString("im"))           // substring
                    .body("booking.lastname",           is("Brown"))                    // is(equal)
                    .body("booking.totalprice",         greaterThan(100))               // numeric range
                    .body("booking.totalprice",         is(equalTo(111)))               // wrapped
                    .body("booking.depositpaid",        is(true))                       // boolean
                    .body("booking.bookingdates.checkin",
                          containsString("2018"))                                       // partial date
                    .body("booking.additionalneeds",
                          containsString("Break"));                                     // partial string

        System.out.println("Validated 11 field-level matchers across the booking response.");
        System.out.println("[TEST PASSED] Various matcher styles applied per field.\n");
    }

    /**
     * Bonus - a single .body(...) call CAN take multiple
     * (additionalKeyMatcherPairs...) overload variant and validate many
     * fields in one invocation. This keeps the chain compact.
     */
    @Test(priority = 4,
          description = "POST /booking - .body(path, matcher, additional...) variadic overload")
    public void validateFieldsWithVariadicBodyOverload() {

        System.out.println("\n[TEST START] validateFieldsWithVariadicBodyOverload");

        // The overload signature is:
        //   .body(String path, Matcher matcher, Object... additionalKeyMatcherPairs)
        // Pairs are interleaved (path, matcher, path, matcher, ...).
        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body(
                        "booking.firstname",                   equalTo("Jim"),
                        "booking.lastname",                    equalTo("Brown"),
                        "booking.totalprice",                  equalTo(111),
                        "booking.depositpaid",                 equalTo(true),
                        "booking.bookingdates.checkin",        equalTo("2018-01-01"),
                        "booking.bookingdates.checkout",       equalTo("2019-01-01"),
                        "booking.additionalneeds",             equalTo("Breakfast")
                    );

        System.out.println("Validated 7 fields in a single .body(...) call (variadic form).");
        System.out.println("[TEST PASSED] Variadic body() overload succeeded.\n");
    }
}
