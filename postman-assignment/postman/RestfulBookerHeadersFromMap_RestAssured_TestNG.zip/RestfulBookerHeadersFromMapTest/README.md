# Headers from Map - REST Assured + TestNG

POST https://restful-booker.herokuapp.com/auth, headers built from a Map.

## Idiom

```java
Map<String, String> headers = new HashMap<>();
headers.put("Content-Type", "application/json");
headers.put("Accept",       "application/json");

.given()
    .headers(headers)        // headers from Map
    .body(authBody)
.when()
    .post("/auth")
.then()
    .statusCode(200)
    .body("token", notNullValue());
```

## Test Methods

| # | Method                              | Map Type                     |
|---|-------------------------------------|------------------------------|
| 1 | `authWithHeadersFromMap`            | `HashMap<String, String>`    |
| 2 | `authWithHeadersFromLinkedHashMap`  | `LinkedHashMap` (ordered)    |
| 3 | `authWithHeadersFromObjectMap`      | `HashMap<String, Object>`    |

## Run

```bash
mvn clean test
```
