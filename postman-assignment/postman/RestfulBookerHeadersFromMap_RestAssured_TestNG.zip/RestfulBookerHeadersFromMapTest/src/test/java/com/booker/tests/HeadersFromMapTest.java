package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.hamcrest.Matchers.notNullValue;

/**
 * Hands-On 23: Set headers from a Map in REST Assured.
 *
 * URL    : POST https://restful-booker.herokuapp.com/auth
 * Body   : { "username": "admin", "password": "password123" }
 * Headers (built from a Map):
 *          Content-Type = application/json
 *          Accept       = application/json
 *
 * Validate the response, print it.
 */
public class HeadersFromMapTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/auth";

    private static final String AUTH_BODY = "{\n"
            + "  \"username\" : \"admin\",\n"
            + "  \"password\" : \"password123\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI = " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Build a Map<String, String> of headers and pass it to .headers(Map).
     */
    @Test(priority = 1, description = "POST /auth - headers from Map - validate + print")
    public void authWithHeadersFromMap() {

        System.out.println("\n[TEST START] authWithHeadersFromMap");

        // Build headers in a Map
        Map<String, String> headersMap = new HashMap<>();
        headersMap.put("Content-Type", "application/json");
        headersMap.put("Accept",       "application/json");

        System.out.println("Headers map being sent:");
        headersMap.forEach((k, v) -> System.out.println("  " + k + " : " + v));

        Response response = RestAssured
                .given()
                    .headers(headersMap)                  // headers from Map
                    .body(AUTH_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body("token", notNullValue())
                    .extract().response();

        String token = response.jsonPath().getString("token");

        System.out.println("\nRequest URL  : " + BASE_URI + ENDPOINT);
        System.out.println("Status code  : " + response.getStatusCode());
        System.out.println("Token        : " + token);
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        Assert.assertNotNull(token, "FAILED: token was null");
        Assert.assertFalse(token.isEmpty(), "FAILED: token was empty");

        System.out.println("[TEST PASSED] /auth response validated using header Map.\n");
    }

    /**
     * Bonus - use LinkedHashMap to preserve insertion order (handy for
     * deterministic logs).
     */
    @Test(priority = 2, description = "POST /auth - headers from LinkedHashMap (ordered)")
    public void authWithHeadersFromLinkedHashMap() {

        System.out.println("\n[TEST START] authWithHeadersFromLinkedHashMap");

        Map<String, String> headers = new LinkedHashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("Accept",       "application/json");

        Response response = RestAssured
                .given()
                    .headers(headers)
                    .body(AUTH_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body("token", notNullValue())
                    .extract().response();

        System.out.println("Token : " + response.jsonPath().getString("token"));
        System.out.println("[TEST PASSED]\n");
    }

    /**
     * Bonus - Map<String, Object> is also accepted (values can be Strings
     * or any toString()-able object).
     */
    @Test(priority = 3, description = "POST /auth - headers from Map<String, Object>")
    public void authWithHeadersFromObjectMap() {

        System.out.println("\n[TEST START] authWithHeadersFromObjectMap");

        Map<String, Object> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("Accept",       "application/json");

        Response response = RestAssured
                .given()
                    .headers(headers)
                    .body(AUTH_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body("token", notNullValue())
                    .extract().response();

        System.out.println("Token : " + response.jsonPath().getString("token"));
        System.out.println("[TEST PASSED]\n");
    }
}
