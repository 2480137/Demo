# Validate XML Response Against Inline XSD - REST Assured + TestNG

Maven-based Java project that automates the **"Validate the inline XSD
schema in REST Assured"** scenario. It sends a GET request to Restful
Booker's `/booking/{id}` endpoint asking for **XML** (`Accept:
application/xml`), then validates the response against an **XSD schema
defined inline** as a Java string using REST Assured's
**`matchesXsd(String xsdString)`** matcher.

## Scenario

1. Send a **GET** to `https://restful-booker.herokuapp.com/booking/{id}`.
2. Set `Content-Type: application/xml` and `Accept: application/xml` so
   the API returns XML.
3. Define an XSD schema **inline** as a Java string and pass it to
   `body(matchesXsd(xsdString))` to validate the XML response shape.
4. Print the response to the console.

## What is REST Assured's `matchesXsd(String)` Matcher?

REST Assured's `RestAssuredMatchers` class exposes a family of XSD
matchers:

```java
import static io.restassured.matcher.RestAssuredMatchers.matchesXsd;

// Inline string (this assignment's specific ask)
.then().body(matchesXsd(xsdString));

// File / URL / InputStream / classpath
.then().body(matchesXsd(file));
.then().body(matchesXsd(url));
.then().body(matchesXsd(inputStream));
.then().body(matchesXsdInClasspath("schema.xsd"));
```

Each returns a Hamcrest `Matcher<String>` that validates the entire
response body conforms to the supplied XML Schema definition. The inline
form is the most convenient for small schemas and self-contained tests.

## The Inline XSD Used in This Project

Embedded directly in the test class as a Java string:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<xs:schema xmlns:xs="http://www.w3.org/2001/XMLSchema"
           elementFormDefault="qualified">
  <xs:element name="booking">
    <xs:complexType>
      <xs:sequence>
        <xs:element name="firstname"  type="xs:string"/>
        <xs:element name="lastname"   type="xs:string"/>
        <xs:element name="totalprice" type="xs:decimal"/>
        <xs:element name="depositpaid" type="xs:boolean"/>
        <xs:element name="bookingdates">
          <xs:complexType>
            <xs:sequence>
              <xs:element name="checkin"  type="xs:date"/>
              <xs:element name="checkout" type="xs:date"/>
            </xs:sequence>
          </xs:complexType>
        </xs:element>
        <xs:element name="additionalneeds" type="xs:string" minOccurs="0"/>
      </xs:sequence>
    </xs:complexType>
  </xs:element>
</xs:schema>
```

Notes on the schema:
- Root element is `<booking>`.
- All children are required EXCEPT `additionalneeds` (`minOccurs="0"`).
- Numeric, boolean, and date types use the typed XSD primitives for
  stricter validation.
- `totalprice` is `xs:decimal` to allow non-integer prices.

## IMPORTANT - The Stale ID Problem

The assignment specifies id **119**. Restful Booker resets all data
**every 10 minutes**, so id 119 is unlikely to exist when this test runs.
A naive GET against /booking/119 would 404.

To make the test self-contained and reliable:
1. `@BeforeClass` POSTs a fresh booking (Jim Brown / 2018-2019 / Breakfast)
   and captures the server-assigned `bookingid`.
2. The main test GETs **that** id with `Accept: application/xml`.
3. A bonus test additionally tries the literal id 119 and tolerates
   either 200 (lucky) or 404 (typical case).

## The XML Response Shape

When `Accept: application/xml`, Restful Booker returns:

```xml
<booking>
    <firstname>Jim</firstname>
    <lastname>Brown</lastname>
    <totalprice>111</totalprice>
    <depositpaid>true</depositpaid>
    <bookingdates>
        <checkin>2018-01-01</checkin>
        <checkout>2019-01-01</checkout>
    </bookingdates>
    <additionalneeds>Breakfast</additionalneeds>
</booking>
```

The XSD above describes exactly this shape.

## Project Structure

```
RestfulBookerInlineXsdTest/
├── pom.xml                              # Maven dependencies (incl. xml-path)
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── ValidateInlineXsdTest.java
```

## What the Test Class Does

`@BeforeClass` POSTs a fresh booking and captures its id.

| # | Method                                  | Purpose                                                                            |
|---|-----------------------------------------|------------------------------------------------------------------------------------|
| 1 | `validateXmlResponseAgainstInlineXsd`   | Main: GET as XML, validate via `matchesXsd(BOOKING_XSD)`, print response.            |
| 2 | `validateInlineXsdWithAssertThat`       | Bonus - same validation in `.assertThat()` fluent style.                            |
| 3 | `validateXsdAndXmlFields`               | Bonus - XSD (shape) + XPath body field assertions (data) - production combo.        |
| 4 | `verifyXsdRejectsMismatchingResponse`   | Bonus - feeds a wrong XSD; proves matchesXsd actually rejects bad shapes.            |
| 5 | `tryAssignmentLiteralId119`             | Bonus - hits the literal id 119; tolerates either 200 (lucky) or 404 (typical).      |

## Key REST Assured Patterns

```java
// 1. Required static import
import static io.restassured.matcher.RestAssuredMatchers.matchesXsd;

// 2. Declare the XSD as a Java string (this assignment's specific approach)
private static final String BOOKING_XSD =
        "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
      + "<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\">"
      + "  <xs:element name=\"booking\">..."
      + "</xs:schema>";

// 3. The canonical idiom
given()
    .header("Accept", "application/xml")
    .pathParam("id", bookingId)
.when()
    .get("/booking/{id}")
.then()
    .statusCode(200)
    .body(matchesXsd(BOOKING_XSD));

// 4. Combined with field-level assertions
.then()
    .body(matchesXsd(BOOKING_XSD))                      // shape
    .body("booking.firstname",  equalTo("Jim"))         // data
    .body("booking.totalprice", equalTo("111"));        // data
```

## Why Validate XML with an XSD?

| What it proves            | Catches problems like                                  |
|---------------------------|--------------------------------------------------------|
| Right element names       | `<lastname>` typo'd as `<lastnme>`                     |
| Right hierarchy           | `<checkin>` floated to root instead of nested          |
| Right cardinality         | `<firstname>` missing or duplicated                    |
| Right primitive types     | `<totalprice>` returned as `"abc"` instead of a number |
| Right date format         | `<checkin>` as `"01-01-2018"` instead of `"2018-01-01"`|

A single `matchesXsd(...)` call covers all of these in one shot.

## Required Dependencies

The `xml-path` module is needed for XML support and XSD validation.
Without it, `matchesXsd(...)` will not be available:

```xml
<dependency>
    <groupId>io.rest-assured</groupId>
    <artifactId>xml-path</artifactId>
    <version>5.3.2</version>
    <scope>test</scope>
</dependency>
```

Both `rest-assured` and `xml-path` should be on the same version.

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request, set GET + URL            | `given().when().get(ENDPOINT)`                       |
| Add `Accept: application/xml` header        | `given().header("Accept", "application/xml")`       |
| Tests tab: validate against XSD             | `.body(matchesXsd(XSD_STRING))`                      |

Postman has no built-in XSD validator - this is a REST Assured exclusive
strength.

## Hands-On 9 vs Hands-On 12 - The Two Schema Validators

| Aspect           | Hands-On 9 (JSON Schema)              | Hands-On 12 (XSD) - this project    |
|------------------|----------------------------------------|--------------------------------------|
| Format           | JSON                                   | XML                                  |
| Schema language  | JSON Schema (Draft 4)                  | XSD (XML Schema Definition)          |
| Matcher          | `matchesJsonSchemaInClasspath(file)`   | `matchesXsd(string)` (inline)        |
| Where defined    | Separate `.json` file in test/resources| Java string inside the test class    |

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- **XML Path `5.3.2`** - required for XSD validation
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=ValidateInlineXsdTest#validateXmlResponseAgainstInlineXsd
```

## Expected Output (abridged)

```
Created fresh booking with id: 4271
(The assignment's literal id 119 is usually wiped by the 10-minute reset.)

[TEST START] validateXmlResponseAgainstInlineXsd
Request URL    : https://restful-booker.herokuapp.com/booking/4271
Method         : GET
Accept         : application/xml
Status code    : 200
Content-Type   : application/xml; charset=utf-8

--- XML response body ---
<booking>
    <firstname>Jim</firstname>
    <lastname>Brown</lastname>
    <totalprice>111</totalprice>
    <depositpaid>true</depositpaid>
    <bookingdates>
        <checkin>2018-01-01</checkin>
        <checkout>2019-01-01</checkout>
    </bookingdates>
    <additionalneeds>Breakfast</additionalneeds>
</booking>

--- XSD used (inline) ---
<?xml version="1.0" encoding="UTF-8"?>
<xs:schema ...>
   ...
</xs:schema>

[TEST PASSED] XML response validated against inline XSD.

[TEST START] verifyXsdRejectsMismatchingResponse
(expected) Validation failed for the wrong XSD - schema does its job.
[TEST PASSED] matchesXsd correctly rejects responses that do not match the XSD.

[TEST START] tryAssignmentLiteralId119
Trying assignment's literal id: 119
Status code  : 404
(Expected - id 119 does not currently exist, status was 404.)
[TEST PASSED] Literal id 119 GET exercised; status was 404.

===============================================
Total tests run: 5, Passes: 5, Failures: 0
===============================================
```

## Notes

- Inline XSD strings can become unwieldy for large schemas. For schemas
  longer than ~40 lines, prefer `matchesXsdInClasspath("schema.xsd")`
  with the file under `src/test/resources`.
- The XSD in this project uses `xs:decimal` for `totalprice` so both
  integer and decimal prices are accepted.
- POST /booking on Restful Booker returns **200**, not 201 Created.
- If the network is unavailable, all tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
