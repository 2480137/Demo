package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.matcher.RestAssuredMatchers.matchesXsd;

/**
 * Hands-On 12: Validate the inline XSD schema in REST Assured.
 *
 * Scenario:
 *   Method   : GET
 *   URL      : https://restful-booker.herokuapp.com/booking/{id}
 *   Auth     : none
 *   Headers  : Content-Type: application/xml, Accept: application/xml
 *   Goal     : Validate the XML response against an inline XSD using
 *              REST Assured's matchesXsd(String) matcher.
 *
 * Steps covered:
 *  1. GET /booking/{id} with Accept: application/xml so the API returns XML.
 *  2. Inline XSD defined as a Java String in the test class.
 *  3. Response body validated via .body(matchesXsd(XSD_STRING)).
 *  4. Response printed to the console.
 *
 * About REST Assured's matchesXsd matcher:
 *
 *   The class io.restassured.matcher.RestAssuredMatchers exposes:
 *
 *      matchesXsd(String xsdString)         // <-- the inline form (this assignment)
 *      matchesXsd(File xsd)
 *      matchesXsd(URL xsd)
 *      matchesXsd(InputStream xsd)
 *      matchesXsdInClasspath(String path)
 *
 *   Each returns a Hamcrest Matcher<String> that can be passed to
 *   .body(...) to validate that the entire response body conforms to
 *   the supplied XML Schema.
 *
 *      .then().body(matchesXsd(xsdString));
 *
 *   The "inline" form is convenient for small schemas and self-contained
 *   tests (no extra file to maintain). For larger schemas, prefer
 *   matchesXsdInClasspath("schema.xsd") with the file under
 *   src/test/resources.
 *
 * About the API:
 *   GET /booking/{id} on Restful Booker returns:
 *      - JSON by default
 *      - XML when Accept: application/xml is sent
 *
 *   The XML shape (when found):
 *      <booking>
 *          <firstname>Jim</firstname>
 *          <lastname>Brown</lastname>
 *          <totalprice>111</totalprice>
 *          <depositpaid>true</depositpaid>
 *          <bookingdates>
 *              <checkin>2018-01-01</checkin>
 *              <checkout>2019-01-01</checkout>
 *          </bookingdates>
 *          <additionalneeds>Breakfast</additionalneeds>
 *      </booking>
 *
 *   IMPORTANT: Restful Booker resets all data every 10 minutes, so the
 *   assignment's specific id (119) usually doesn't exist when the test
 *   runs. To make the test self-contained, @BeforeClass POSTs a fresh
 *   booking and captures its id; the main test uses THAT id. A bonus
 *   test additionally tries the literal id 119 and tolerates a 404.
 */
public class ValidateInlineXsdTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";

    /** id from the assignment text - kept for documentation; usually 404 */
    private static final int ASSIGNMENT_LITERAL_ID = 119;

    /** id of a freshly-created booking, captured in @BeforeClass. */
    private static int freshBookingId;

    /** Body used to create the fresh booking in @BeforeClass. */
    private static final String CREATE_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    /**
     * Step 2 - Inline XSD describing the GET /booking/{id} XML response shape.
     *
     * Notes on the schema:
     *  - The root element is <booking>.
     *  - All child elements are required EXCEPT additionalneeds, which
     *    is optional (minOccurs=0).
     *  - Numeric/boolean/date types are typed for stricter validation;
     *    totalprice is xs:decimal so non-integer prices are accepted too.
     */
    private static final String BOOKING_XSD =
            "<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n"
          + "<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\"\n"
          + "           elementFormDefault=\"qualified\">\n"
          + "  <xs:element name=\"booking\">\n"
          + "    <xs:complexType>\n"
          + "      <xs:sequence>\n"
          + "        <xs:element name=\"firstname\"  type=\"xs:string\"/>\n"
          + "        <xs:element name=\"lastname\"   type=\"xs:string\"/>\n"
          + "        <xs:element name=\"totalprice\" type=\"xs:decimal\"/>\n"
          + "        <xs:element name=\"depositpaid\" type=\"xs:boolean\"/>\n"
          + "        <xs:element name=\"bookingdates\">\n"
          + "          <xs:complexType>\n"
          + "            <xs:sequence>\n"
          + "              <xs:element name=\"checkin\"  type=\"xs:date\"/>\n"
          + "              <xs:element name=\"checkout\" type=\"xs:date\"/>\n"
          + "            </xs:sequence>\n"
          + "          </xs:complexType>\n"
          + "        </xs:element>\n"
          + "        <xs:element name=\"additionalneeds\" type=\"xs:string\" minOccurs=\"0\"/>\n"
          + "      </xs:sequence>\n"
          + "    </xs:complexType>\n"
          + "  </xs:element>\n"
          + "</xs:schema>";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");

        // Pre-condition - POST a fresh booking so we have a guaranteed-
        // valid id to GET. This protects against Restful Booker's data
        // reset (every 10 minutes) which removes the literal id 119.
        Response createResp = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(CREATE_BODY)
                .when()
                    .post("/booking")
                .then()
                    .extract().response();

        Assert.assertEquals(createResp.getStatusCode(), 200,
                "FAILED: pre-condition - POST /booking returned "
                        + createResp.getStatusCode() + " (expected 200). "
                        + "Body: " + createResp.getBody().asString());

        freshBookingId = createResp.jsonPath().getInt("bookingid");
        Assert.assertTrue(freshBookingId > 0,
                "FAILED: pre-condition - bookingid should be positive");

        System.out.println("Created fresh booking with id: " + freshBookingId);
        System.out.println("(The assignment's literal id " + ASSIGNMENT_LITERAL_ID
                + " is usually wiped by the 10-minute reset.)");
    }

    /**
     * Steps 1-4 - GET the booking as XML, validate the XML body against
     * the inline XSD via matchesXsd, then print the response.
     */
    @Test(priority = 1,
          description = "GET /booking/{id} as XML - validate body against inline XSD + print")
    public void validateXmlResponseAgainstInlineXsd() {

        System.out.println("\n[TEST START] validateXmlResponseAgainstInlineXsd");

        // Step 1 + 3 - GET as XML and validate against inline XSD
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/xml")        // Step 2
                    .header("Accept",       "application/xml")        // Step 2 - request XML
                    .pathParam("id", freshBookingId)
                .when()
                    .get("/booking/{id}")
                .then()
                    .statusCode(200)
                    .body(matchesXsd(BOOKING_XSD))                    // Step 3 - inline XSD
                    .extract()
                    .response();

        // Step 4 - Print the response for console visibility
        System.out.println("Request URL    : " + BASE_URI + "/booking/" + freshBookingId);
        System.out.println("Method         : GET");
        System.out.println("Accept         : application/xml");
        System.out.println("Status code    : " + response.getStatusCode());
        System.out.println("Content-Type   : " + response.getContentType());

        System.out.println("\n--- XML response body ---");
        System.out.println(response.getBody().asPrettyString());

        System.out.println("--- XSD used (inline) ---");
        System.out.println(BOOKING_XSD);

        System.out.println("\n[TEST PASSED] XML response validated against inline XSD.\n");
    }

    /**
     * Bonus - inline XSD with .assertThat() form for fluent reading.
     */
    @Test(priority = 2,
          description = "GET /booking/{id} as XML - matchesXsd inside .assertThat() form")
    public void validateInlineXsdWithAssertThat() {

        System.out.println("\n[TEST START] validateInlineXsdWithAssertThat");

        RestAssured
                .given()
                    .header("Content-Type", "application/xml")
                    .header("Accept",       "application/xml")
                    .pathParam("id", freshBookingId)
                .when()
                    .get("/booking/{id}")
                .then()
                    .assertThat()
                    .statusCode(200)
                    .body(matchesXsd(BOOKING_XSD));

        System.out.println("[TEST PASSED] XSD validation succeeded with .assertThat() form.\n");
    }

    /**
     * Bonus - schema validation combined with XPath body assertions.
     * matchesXsd proves SHAPE; .body("//path", matcher) proves DATA.
     * These are complementary and usually used together in real tests.
     */
    @Test(priority = 3,
          description = "GET /booking/{id} as XML - matchesXsd PLUS XPath body assertions")
    public void validateXsdAndXmlFields() {

        System.out.println("\n[TEST START] validateXsdAndXmlFields");

        RestAssured
                .given()
                    .header("Content-Type", "application/xml")
                    .header("Accept",       "application/xml")
                    .pathParam("id", freshBookingId)
                .when()
                    .get("/booking/{id}")
                .then()
                    .assertThat()
                    .statusCode(200)
                    // Schema (shape)
                    .body(matchesXsd(BOOKING_XSD))
                    // Data via XPath - REST Assured uses GPath-style for XML
                    .body("booking.firstname",                org.hamcrest.Matchers.equalTo("Jim"))
                    .body("booking.lastname",                 org.hamcrest.Matchers.equalTo("Brown"))
                    .body("booking.totalprice",               org.hamcrest.Matchers.equalTo("111"))
                    .body("booking.depositpaid",              org.hamcrest.Matchers.equalTo("true"))
                    .body("booking.bookingdates.checkin",     org.hamcrest.Matchers.equalTo("2018-01-01"))
                    .body("booking.bookingdates.checkout",    org.hamcrest.Matchers.equalTo("2019-01-01"));

        System.out.println("[TEST PASSED] XSD (shape) + XPath (data) both validated.\n");
    }

    /**
     * Bonus - prove the XSD actually catches mismatches by feeding it a
     * deliberately wrong schema (root element renamed). The XSD validation
     * SHOULD fail; we catch the AssertionError to confirm.
     */
    @Test(priority = 4,
          description = "BONUS - bad XSD (wrong root) should make matchesXsd FAIL")
    public void verifyXsdRejectsMismatchingResponse() {

        System.out.println("\n[TEST START] verifyXsdRejectsMismatchingResponse");

        // Deliberately wrong - schema expects <reservation> not <booking>
        final String WRONG_XSD =
                "<?xml version=\"1.0\" encoding=\"UTF-8\"?>"
              + "<xs:schema xmlns:xs=\"http://www.w3.org/2001/XMLSchema\">"
              + "  <xs:element name=\"reservation\" type=\"xs:string\"/>"
              + "</xs:schema>";

        boolean rejectedAsExpected = false;
        try {
            RestAssured
                    .given()
                        .header("Accept", "application/xml")
                        .pathParam("id", freshBookingId)
                    .when()
                        .get("/booking/{id}")
                    .then()
                        .body(matchesXsd(WRONG_XSD));
        } catch (AssertionError | Exception e) {
            rejectedAsExpected = true;
            System.out.println("(expected) Validation failed for the wrong XSD - schema does its job.");
        }

        Assert.assertTrue(rejectedAsExpected,
                "FAILED: matchesXsd should have rejected the response for a non-matching XSD");

        System.out.println("[TEST PASSED] matchesXsd correctly rejects responses that do not match the XSD.\n");
    }

    /**
     * Bonus - try the assignment's literal id 119. May or may not exist.
     * If it 404s we tolerate it; if it returns 200, validate against
     * the inline XSD just like the main test.
     */
    @Test(priority = 5,
          description = "BONUS - GET /booking/119 (the assignment's literal id) - 200 or 404 OK")
    public void tryAssignmentLiteralId119() {

        System.out.println("\n[TEST START] tryAssignmentLiteralId119");
        System.out.println("Trying assignment's literal id: " + ASSIGNMENT_LITERAL_ID);

        Response response = RestAssured
                .given()
                    .header("Accept", "application/xml")
                    .pathParam("id", ASSIGNMENT_LITERAL_ID)
                .when()
                    .get("/booking/{id}")
                .then()
                    .extract().response();

        int sc = response.getStatusCode();
        System.out.println("Status code  : " + sc);

        if (sc == 200) {
            System.out.println("(Lucky - id 119 exists right now.)");
            // Run the XSD validation
            RestAssured
                    .given()
                        .header("Accept", "application/xml")
                        .pathParam("id", ASSIGNMENT_LITERAL_ID)
                    .when()
                        .get("/booking/{id}")
                    .then()
                        .body(matchesXsd(BOOKING_XSD));
            System.out.println("XSD validation passed for id " + ASSIGNMENT_LITERAL_ID);
        } else {
            System.out.println("(Expected - id " + ASSIGNMENT_LITERAL_ID
                    + " does not currently exist, status was " + sc + ".)");
        }

        Assert.assertTrue(sc == 200 || sc == 404,
                "FAILED: expected 200 or 404 for literal id, got " + sc);

        System.out.println("[TEST PASSED] Literal id 119 GET exercised; status was " + sc + ".\n");
    }
}
