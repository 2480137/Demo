# Restful Booker JSON Parse - REST Assured + TestNG

Maven-based Java project that uses **REST Assured** and **TestNG** to call the
`GET /booking` endpoint of the public Restful Booker API, parse the response
into JSON, and print the values.

## Scenario

Send a **GET** request to:

```
https://restful-booker.herokuapp.com/booking
```

Retrieve the response body, parse it as JSON, and print the booking ids
(plus, as a bonus, the full details of one booking).

## About the Response

`GET /booking` returns a JSON **array** of single-key objects. Each object
contains one integer field, `bookingid`:

```json
[
  { "bookingid": 1 },
  { "bookingid": 2 },
  { "bookingid": 3 },
  ...
]
```

To get the full booking record (firstname, lastname, dates, etc.), follow up
with `GET /booking/<bookingid>` - the bonus test method demonstrates this.

## Project Structure

```
RestfulBookerJsonParseTest/
├── pom.xml                          # Maven dependencies
├── testng.xml                       # TestNG suite file
├── README.md
└── src/
    └── test/
        └── java/
            └── com/
                └── booker/
                    └── tests/
                        └── RestfulBookerJsonParseTest.java
```

## What the Test Class Does

The `RestfulBookerJsonParseTest` class contains three test methods:

| # | Method                              | Purpose                                                                                  |
|---|-------------------------------------|------------------------------------------------------------------------------------------|
| 1 | `getBookingsAndPrintJson`           | Sends GET, retrieves the body, parses to JSON via `JsonPath`, prints all booking ids.    |
| 2 | `getBookingDetailsAndPrintFields`   | Bonus - GETs `/booking/{id}` and prints every field of the nested booking object.        |
| 3 | `iterateBookingsAsMaps`             | Bonus - parses the response as `List<Map<String,Object>>` and iterates dynamically.      |

## Key REST Assured Patterns Used

```java
// 1. Get the response
Response response = RestAssured
        .given().header("Accept", "application/json")
        .when().get("/booking")
        .then().extract().response();

// 2. Parse to JSON
JsonPath jsonPath = response.jsonPath();

// 3. Extract values (top-level array)
List<Integer> ids = jsonPath.getList("bookingid");

// 4. Extract values (nested object)
String firstname = jsonPath.getString("firstname");
String checkin   = jsonPath.getString("bookingdates.checkin");
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open the project as a Maven project (select `pom.xml`), wait for dependencies
to download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=RestfulBookerJsonParseTest#getBookingsAndPrintJson
```

## Expected Output (abridged)

```
[TEST START] getBookingsAndPrintJson
Status code    : 200
Total bookings returned : 10
  Booking #1 -> id = 1
  Booking #2 -> id = 2
  ...
First booking id : 1
Last booking id  : 10
[TEST PASSED] JSON response parsed and printed successfully.

[TEST START] getBookingDetailsAndPrintFields
firstname        : Jim
lastname         : Brown
totalprice       : 111
depositpaid      : true
checkin          : 2018-01-01
checkout         : 2019-01-01
additionalneeds  : Breakfast
[TEST PASSED] Nested JSON parsed and printed successfully.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- Restful Booker resets its data **every 10 minutes** back to a default set
  of 10 bookings, so the booking ids in the response will change between
  runs but there will always be at least a few entries available.
- No authentication is required for the GET endpoints used here.
- If the public API is unreachable, the tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
