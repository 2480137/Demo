package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

/**
 * Hands-On: Get the API response in JSON in REST Assured.
 *
 * Scenario:
 *  Send a GET request to https://restful-booker.herokuapp.com/booking,
 *  retrieve the response body, parse it into JSON, and print the values.
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. GET request sent through RestAssured to
 *     https://restful-booker.herokuapp.com/booking
 *  4. Response body is retrieved and parsed into JSON via JsonPath.
 *  5. JSON values are printed to the console.
 *
 * About the response:
 *  GET /booking returns a JSON array of booking-id objects, e.g.
 *      [
 *          { "bookingid": 1 },
 *          { "bookingid": 2 },
 *          ...
 *      ]
 *  Each item is a single-key Map with the integer booking id.
 */
public class RestfulBookerJsonParseTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI once for the whole class
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 4 + 5 - Retrieve the response body, parse to JSON, print the values.
     */
    @Test(priority = 1,
          description = "GET /booking - parse JSON array and print booking ids")
    public void getBookingsAndPrintJson() {

        System.out.println("\n[TEST START] getBookingsAndPrintJson");

        // Step 3 - Send GET through RestAssured
        Response response = RestAssured
                .given()
                    .header("Accept", "application/json")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        // Sanity-check the request actually succeeded
        int statusCode = response.getStatusCode();
        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Status code    : " + statusCode);
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK from GET /booking but got " + statusCode);

        // Step 4 - Retrieve the raw body and parse it into JSON
        String rawBody = response.getBody().asString();
        System.out.println("Raw body length: " + rawBody.length() + " chars");
        System.out.println("Raw body (first 200 chars): "
                + rawBody.substring(0, Math.min(200, rawBody.length())) + " ...");

        // Two equivalent ways to obtain a JsonPath instance:
        //   1) From the Response directly:    response.jsonPath()
        //   2) Construct from the raw string: new JsonPath(rawBody)
        JsonPath jsonPath = response.jsonPath();

        // Pretty-print the parsed JSON for visibility
        System.out.println("\n--- Pretty-printed JSON response ---");
        System.out.println(response.getBody().asPrettyString());

        // Step 5 - Print the JSON values

        // The response is a list of booking-id objects.  Pull all the ids:
        List<Integer> bookingIds = jsonPath.getList("bookingid");
        Assert.assertNotNull(bookingIds, "FAILED: bookingid list is null");
        Assert.assertFalse(bookingIds.isEmpty(),
                "FAILED: bookingid list is empty");

        System.out.println("\n--- Booking ids extracted from JSON ---");
        System.out.println("Total bookings returned : " + bookingIds.size());
        for (int i = 0; i < bookingIds.size(); i++) {
            System.out.println("  Booking #" + (i + 1) + " -> id = " + bookingIds.get(i));
        }

        // Show a couple of useful single-value extractions too
        Integer firstId = jsonPath.getInt("[0].bookingid");
        Integer lastId  = jsonPath.getInt("[" + (bookingIds.size() - 1) + "].bookingid");
        System.out.println("\nFirst booking id : " + firstId);
        System.out.println("Last booking id  : " + lastId);

        System.out.println("[TEST PASSED] JSON response parsed and printed successfully.\n");
    }

    /**
     * Bonus - fetch the details of one booking and print every field of the
     * nested JSON object.  This demonstrates parsing of richer JSON than the
     * top-level booking list.
     */
    @Test(priority = 2,
          description = "GET /booking/:id - parse nested JSON and print each field")
    public void getBookingDetailsAndPrintFields() {

        System.out.println("\n[TEST START] getBookingDetailsAndPrintFields");

        // First, list bookings to find a valid id
        List<Integer> bookingIds = RestAssured
                .given()
                    .header("Accept", "application/json")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .jsonPath()
                    .getList("bookingid");

        Assert.assertFalse(bookingIds.isEmpty(),
                "Pre-condition failed: no bookings available to inspect");
        int bookingId = bookingIds.get(0);
        System.out.println("Picking the first booking: id = " + bookingId);

        // Fetch that booking's details
        Response response = RestAssured
                .given()
                    .header("Accept", "application/json")
                .when()
                    .get(ENDPOINT + "/" + bookingId)
                .then()
                    .extract()
                    .response();

        Assert.assertEquals(response.getStatusCode(), 200,
                "FAILED: GET /booking/" + bookingId + " did not return 200");

        // Parse and pretty-print
        JsonPath jsonPath = response.jsonPath();
        System.out.println("\n--- Booking #" + bookingId + " details ---");
        System.out.println(response.getBody().asPrettyString());

        // Pull individual fields (Restful Booker booking schema)
        String  firstname       = jsonPath.getString("firstname");
        String  lastname        = jsonPath.getString("lastname");
        Integer totalprice      = jsonPath.getInt("totalprice");
        Boolean depositpaid     = jsonPath.getBoolean("depositpaid");
        String  checkin         = jsonPath.getString("bookingdates.checkin");
        String  checkout        = jsonPath.getString("bookingdates.checkout");
        String  additionalneeds = jsonPath.getString("additionalneeds");

        System.out.println("\n--- Field-by-field values ---");
        System.out.println("firstname        : " + firstname);
        System.out.println("lastname         : " + lastname);
        System.out.println("totalprice       : " + totalprice);
        System.out.println("depositpaid      : " + depositpaid);
        System.out.println("checkin          : " + checkin);
        System.out.println("checkout         : " + checkout);
        System.out.println("additionalneeds  : " + additionalneeds);

        // Most basic sanity assertions on the parsed values
        Assert.assertNotNull(firstname, "firstname should not be null");
        Assert.assertNotNull(lastname,  "lastname should not be null");
        Assert.assertTrue(totalprice >= 0,
                "totalprice should be non-negative, got " + totalprice);

        System.out.println("[TEST PASSED] Nested JSON parsed and printed successfully.\n");
    }

    /**
     * Bonus alternative - same parsing flow but uses Map iteration instead of
     * extracting one field at a time.  Useful when the JSON shape is dynamic
     * or unknown ahead of time.
     */
    @Test(priority = 3,
          description = "GET /booking - iterate the JSON list as Map<String, Object>")
    public void iterateBookingsAsMaps() {

        System.out.println("\n[TEST START] iterateBookingsAsMaps");

        Response response = RestAssured
                .given()
                    .header("Accept", "application/json")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        // Treat the entire body as a list of maps
        List<Map<String, Object>> bookings = response.jsonPath().getList("$");

        System.out.println("Total entries: " + bookings.size());
        // Print the first up-to-5 entries so the output stays readable
        int max = Math.min(5, bookings.size());
        for (int i = 0; i < max; i++) {
            System.out.println("  Entry " + (i + 1) + " keys = " + bookings.get(i).keySet()
                    + ", values = " + bookings.get(i).values());
        }
        if (bookings.size() > max) {
            System.out.println("  ... (" + (bookings.size() - max) + " more entries)");
        }

        Assert.assertFalse(bookings.isEmpty(), "FAILED: bookings list was empty");

        System.out.println("[TEST PASSED] JSON parsed as List<Map> and iterated.\n");
    }
}
