# Validate JSON Schema with matchesJsonSchemaInClasspath - REST Assured + TestNG

Maven-based Java project that automates the **"Validating JSON Schema using
matchesJsonSchemaInClasspath in REST Assured"** scenario. It sends a POST
request to Restful Booker's `/booking` endpoint, validates the entire
response body against a **JSON Schema** file located on the test classpath,
and prints the response.

## Scenario

1. Send a **POST** to `https://restful-booker.herokuapp.com/booking` with
   the given booking body.
2. Validate the response body against `booking-schema.json` using
   `matchesJsonSchemaInClasspath(...)`.
3. Print the response to the console.

```json
{
    "firstname": "Jim",
    "lastname": "Brown",
    "totalprice": 111,
    "depositpaid": true,
    "bookingdates": {
        "checkin":  "2018-01-01",
        "checkout": "2019-01-01"
    },
    "additionalneeds": "Breakfast"
}
```

## What is `matchesJsonSchemaInClasspath`?

REST Assured's `json-schema-validator` module provides a static factory:

```java
io.restassured.module.jsv.JsonSchemaValidator
    .matchesJsonSchemaInClasspath(String schemaPath)
```

It returns a Hamcrest `Matcher<String>` that you pass to `.body(...)` to
validate the **entire** response body against a JSON Schema file located
on the test classpath:

```java
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

.then()
    .statusCode(200)
    .body(matchesJsonSchemaInClasspath("booking-schema.json"));
```

The schema file is just a JSON file describing required fields, types,
formats, etc. Place it under `src/test/resources` so it ends up on the
classpath at test time.

## What's in This Project's Schema File?

`src/test/resources/booking-schema.json` describes the POST /booking
response shape:

```
BookingCreatedResponse
├── bookingid    : integer (required, >= 1)
└── booking      : object (required)
    ├── firstname       : string (required, non-empty)
    ├── lastname        : string (required, non-empty)
    ├── totalprice      : number (required, >= 0)
    ├── depositpaid     : boolean (required)
    ├── bookingdates    : object (required)
    │   ├── checkin     : string (required, "YYYY-MM-DD" pattern)
    │   └── checkout    : string (required, "YYYY-MM-DD" pattern)
    └── additionalneeds : string (optional)
```

The schema uses **JSON Schema Draft 4** (the default for the
json-schema-validator module).

## Why Use JSON Schema Validation?

| What it proves | Catches problems like                                              |
|----------------|--------------------------------------------------------------------|
| Field exists   | `bookingid` missing entirely                                       |
| Right type     | `bookingid` returned as a string instead of an integer             |
| Right shape    | `booking.bookingdates` returned as a flat string instead of object |
| Format/pattern | `checkin` returned as `"01-01-2018"` instead of `"2018-01-01"`     |
| No extras      | A new unexpected field added by a backend change                   |

A single `matchesJsonSchemaInClasspath()` call covers all of these in one
shot - much more compact than writing dozens of `.body(path, matcher)`
checks for every field.

## Family of Schema Matchers

```java
import static io.restassured.module.jsv.JsonSchemaValidator.*;

.then().body(matchesJsonSchemaInClasspath("schema.json"));     // <-- this assignment
.then().body(matchesJsonSchema(schemaText));                   // schema as a String
.then().body(matchesJsonSchema(new File("schema.json")));       // schema from a File
.then().body(matchesJsonSchema(inputStream));                   // schema from a Stream
.then().body(matchesJsonSchema(new URL("https://...")));        // schema from a URL
```

Use whichever fits the test's needs. `matchesJsonSchemaInClasspath` is by
far the most common in real projects because schemas live in the repo.

## Project Structure

```
RestfulBookerJsonSchemaTest/
├── pom.xml                                              # Maven dependencies
├── testng.xml                                           # TestNG suite file
├── README.md
└── src/test/
    ├── java/com/booker/tests/
    │   └── JsonSchemaValidationTest.java
    └── resources/
        └── booking-schema.json                          # JSON Schema file
```

The `src/test/resources/` folder is on the classpath at test time, so
`matchesJsonSchemaInClasspath("booking-schema.json")` finds the file with
just its relative name.

## What the Test Class Does

| # | Method                                  | Purpose                                                                            |
|---|-----------------------------------------|------------------------------------------------------------------------------------|
| 1 | `validateResponseAgainstJsonSchema`     | Main: POST + `.body(matchesJsonSchemaInClasspath(...))` + print response.           |
| 2 | `validateJsonSchemaWithAssertThat`      | Bonus - same validation in `.assertThat()` fluent style.                            |
| 3 | `validateSchemaAndFields`               | Bonus - schema (shape) PLUS body field matchers (data) - typical production combo.  |
| 4 | `verifySchemaFailsOnNonMatchingResponse`| Bonus - GET /ping returns plain text; proves schema validation rejects bad shapes.  |

## Key REST Assured Patterns

```java
// 1. Required static import
import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

// 2. The canonical idiom (this assignment's specific ask)
.then().body(matchesJsonSchemaInClasspath("booking-schema.json"));

// 3. Combined with status check
.then()
    .statusCode(200)
    .body(matchesJsonSchemaInClasspath("booking-schema.json"));

// 4. Schema (shape) + field-level matchers (data) - the production combo
.then()
    .statusCode(200)
    .body(matchesJsonSchemaInClasspath("booking-schema.json"))   // shape
    .body("booking.firstname", equalTo("Jim"))                    // data
    .body("booking.totalprice", equalTo(111));                    // data
```

## Required Dependency

The `json-schema-validator` module is NOT included with the base REST Assured
artifact - it must be added separately:

```xml
<dependency>
    <groupId>io.rest-assured</groupId>
    <artifactId>json-schema-validator</artifactId>
    <version>5.3.2</version>
    <scope>test</scope>
</dependency>
```

This module pulls in the underlying `com.github.java-json-tools:json-schema-validator`
which does the actual schema processing.

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request, set POST + URL + body    | `given().body(...).when().post(...)`                 |
| Tests tab: validate response shape          | `.body(matchesJsonSchemaInClasspath("schema.json"))` |
| Tests tab: validate individual fields       | `.body("path", matcher)` calls (Hamcrest)            |

Postman has `pm.response.to.have.jsonSchema(schema)` - REST Assured's
matcher is the equivalent.

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- **JSON Schema Validator `5.3.2`** - the focus of this assignment
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=JsonSchemaValidationTest#validateResponseAgainstJsonSchema
```

## Expected Output (abridged)

```
[TEST START] validateResponseAgainstJsonSchema
Request URL    : https://restful-booker.herokuapp.com/booking
Status code    : 200
Status line    : HTTP/1.1 200 OK
Schema used    : booking-schema.json
Schema validation : PASSED

--- Pretty-printed response body ---
{
    "bookingid": 4271,
    "booking": {
        "firstname": "Jim",
        "lastname": "Brown",
        "totalprice": 111,
        "depositpaid": true,
        "bookingdates": {
            "checkin":  "2018-01-01",
            "checkout": "2019-01-01"
        },
        "additionalneeds": "Breakfast"
    }
}
[TEST PASSED] Response validated against booking-schema.json.

===============================================
Total tests run: 4, Passes: 4, Failures: 0
===============================================
```

## Notes

- The schema in this project uses `additionalProperties: false` to be
  strict - if Restful Booker adds a new top-level field in the future,
  this schema will reject it. Set `additionalProperties: true` (or remove
  the line) for a more lenient schema.
- POST /booking on Restful Booker returns **200 OK**, not 201 Created.
- `matchesJsonSchemaInClasspath` looks for the file relative to the test
  classpath root, so `src/test/resources/sub/booking-schema.json` would
  be referenced as `"sub/booking-schema.json"`.
- If the schema file is missing or malformed, REST Assured throws a
  descriptive error at test time.
- If the network is unavailable, all tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
