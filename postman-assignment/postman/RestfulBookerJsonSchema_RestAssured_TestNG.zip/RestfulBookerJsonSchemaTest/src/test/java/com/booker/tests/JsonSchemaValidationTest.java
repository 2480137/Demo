package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static io.restassured.module.jsv.JsonSchemaValidator.matchesJsonSchemaInClasspath;

/**
 * Hands-On 9: Validating JSON Schema using matchesJsonSchemaInClasspath
 * in REST Assured.
 *
 * Scenario:
 *   Method   : POST
 *   URL      : https://restful-booker.herokuapp.com/booking
 *   Auth     : none
 *   Body     : { firstname, lastname, totalprice, depositpaid,
 *                bookingdates: { checkin, checkout },
 *                additionalneeds }
 *   Goal     : Validate the entire response BODY against a JSON Schema
 *              file using matchesJsonSchemaInClasspath().
 *
 * Steps covered:
 *  1. POST /booking sent through REST Assured.
 *  2. Response validated against booking-schema.json (in src/test/resources)
 *     using the matchesJsonSchemaInClasspath() Hamcrest matcher.
 *  3. Response printed to the console.
 *
 * About JSON Schema validation in REST Assured:
 *
 *   The 'json-schema-validator' module adds a static factory method:
 *
 *     io.restassured.module.jsv.JsonSchemaValidator
 *         .matchesJsonSchemaInClasspath(String schemaPath)
 *
 *   This returns a Hamcrest Matcher<String> that can be used inside
 *   .then().body(...) to validate the entire response body against
 *   the schema located at schemaPath on the test classpath:
 *
 *     .then().body(matchesJsonSchemaInClasspath("booking-schema.json"));
 *
 *   The schema file is just a JSON file describing required fields,
 *   types, formats, etc. Place it under src/test/resources so it ends
 *   up on the classpath at test time.
 *
 *   Related matchers in the same JsonSchemaValidator class:
 *     - matchesJsonSchema(String schemaText)    - schema as a string
 *     - matchesJsonSchema(File f)               - schema from a File
 *     - matchesJsonSchema(InputStream is)       - schema from a stream
 *     - matchesJsonSchema(URL url)              - schema from a URL
 *
 * About the schema in this project (src/test/resources/booking-schema.json):
 *   Describes the POST /booking response shape:
 *      {
 *        "bookingid": <int>,
 *        "booking": {
 *          "firstname": <string>,
 *          "lastname":  <string>,
 *          "totalprice": <number>,
 *          "depositpaid": <bool>,
 *          "bookingdates": { "checkin": <date-string>, "checkout": <date-string> },
 *          "additionalneeds": <string>
 *        }
 *      }
 */
public class JsonSchemaValidationTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    private static final String SCHEMA_FILE = "booking-schema.json";

    /** Step 1 - The exact request body specified in the assignment. */
    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("Schema file (classpath) : " + SCHEMA_FILE);
        System.out.println("=========================================================");
    }

    /**
     * Steps 2-3 - Validate the response against the JSON Schema file using
     * matchesJsonSchemaInClasspath, then print the response.
     */
    @Test(priority = 1,
          description = "POST /booking - validate response with matchesJsonSchemaInClasspath() and print")
    public void validateResponseAgainstJsonSchema() {

        System.out.println("\n[TEST START] validateResponseAgainstJsonSchema");

        // Step 1 - Send the POST and run JSON Schema validation in-chain.
        // .extract().response() gives us the response so we can print it.
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    // Step 2 - validate response body against schema on classpath
                    .body(matchesJsonSchemaInClasspath(SCHEMA_FILE))
                    .extract()
                    .response();

        // Step 3 - Print the response for console visibility
        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Status code    : " + response.getStatusCode());
        System.out.println("Status line    : " + response.getStatusLine());
        System.out.println("Schema used    : " + SCHEMA_FILE);
        System.out.println("Schema validation : PASSED");

        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        System.out.println("[TEST PASSED] Response validated against " + SCHEMA_FILE + ".\n");
    }

    /**
     * Bonus - the same validation expressed with .assertThat() for a more
     * fluent reading style.
     */
    @Test(priority = 2,
          description = "POST /booking - JSON schema validation in fluent .assertThat() form")
    public void validateJsonSchemaWithAssertThat() {

        System.out.println("\n[TEST START] validateJsonSchemaWithAssertThat");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(200)
                    .body(matchesJsonSchemaInClasspath(SCHEMA_FILE));

        System.out.println("[TEST PASSED] Schema validation succeeded with assertThat() form.\n");
    }

    /**
     * Bonus - schema validation combined with normal body field assertions.
     * Schema validation proves the SHAPE; the field matchers prove the
     * DATA. They are usually used together in production tests.
     */
    @Test(priority = 3,
          description = "POST /booking - schema validation PLUS field-level body assertions")
    public void validateSchemaAndFields() {

        System.out.println("\n[TEST START] validateSchemaAndFields");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(200)
                    // Shape validation
                    .body(matchesJsonSchemaInClasspath(SCHEMA_FILE))
                    // Data validation
                    .body("booking.firstname",          org.hamcrest.Matchers.equalTo("Jim"))
                    .body("booking.lastname",           org.hamcrest.Matchers.equalTo("Brown"))
                    .body("booking.totalprice",         org.hamcrest.Matchers.equalTo(111))
                    .body("booking.depositpaid",        org.hamcrest.Matchers.equalTo(true))
                    .body("booking.bookingdates.checkin",  org.hamcrest.Matchers.equalTo("2018-01-01"))
                    .body("booking.bookingdates.checkout", org.hamcrest.Matchers.equalTo("2019-01-01"))
                    .body("booking.additionalneeds",    org.hamcrest.Matchers.equalTo("Breakfast"));

        System.out.println("Schema (shape) and fields (data) both validated.");
        System.out.println("[TEST PASSED] Combined schema + field validation succeeded.\n");
    }

    /**
     * Bonus - prove the schema actually catches mismatches. We hit a
     * different endpoint (GET /ping returns plain text, not JSON) and
     * check that schema validation FAILS as expected.
     */
    @Test(priority = 4,
          description = "BONUS - GET /ping (text/plain) does NOT match the booking schema")
    public void verifySchemaFailsOnNonMatchingResponse() {

        System.out.println("\n[TEST START] verifySchemaFailsOnNonMatchingResponse");
        System.out.println("Calling GET /ping which returns plain text - schema validation should fail.");

        boolean failedAsExpected = false;
        try {
            RestAssured
                    .given()
                    .when()
                        .get("/ping")
                    .then()
                        .body(matchesJsonSchemaInClasspath(SCHEMA_FILE));
        } catch (AssertionError e) {
            failedAsExpected = true;
            System.out.println("(expected) AssertionError raised - schema validation correctly failed.");
        } catch (Exception e) {
            // Some non-JSON responses produce a different exception class
            failedAsExpected = true;
            System.out.println("(expected) Exception raised - schema validation could not run on non-JSON.");
        }

        Assert.assertTrue(failedAsExpected,
                "FAILED: schema validation should have failed for GET /ping but did not");

        System.out.println("[TEST PASSED] Schema validation correctly rejects non-matching response.\n");
    }
}
