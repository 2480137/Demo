# List of Values Validation - REST Assured + TestNG

POST /booking on Restful Booker, then validate a LIST response by converting to a JSON document.

## Approach

POST /booking returns a single booking object. GET /booking returns an ARRAY (list of values) - that's what we validate.

Pattern:
```java
Response r = given().when().get("/booking")
    .then().extract().response();

JsonPath doc = r.jsonPath();              // convert response -> JSON document
List<Integer> ids = doc.getList("bookingid", Integer.class);
List<Map<String, Object>> rows = doc.getList("$");
```

## List Matchers Used

| Matcher                          | Use for                             |
|----------------------------------|-------------------------------------|
| `hasItem(value)`                 | List contains a specific value      |
| `hasItem(matcher)`               | At least one item matches matcher   |
| `everyItem(matcher)`             | Every item matches matcher          |
| `hasSize(n)` / `hasSize(matcher)`| Exact / matched size                |
| `contains(...)` / `containsInAnyOrder(...)` | Ordered / unordered exact match |

## Test Methods

| # | Method                                   | Purpose                                                       |
|---|------------------------------------------|---------------------------------------------------------------|
| 1 | `createBookingAndPrintResponse`          | POST + print response.                                         |
| 2 | `validateListOfValuesFromResponse`       | GET list, convert to JSON doc, validate via list matchers + map iteration. |
| 3 | `validateFilteredListOfValues`           | GET filtered list (firstname=Jim) - validate filtered subset.  |
| 4 | `convertRawStringToJsonPathDocument`     | `new JsonPath(rawString)` to convert raw text -> JSON document.|

## Run

```bash
mvn clean test
```
