package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;
import java.util.Map;

import static org.hamcrest.Matchers.everyItem;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.hasItem;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Hands-On 19: Validating response for a List of Values in REST Assured.
 *
 * Goal: Validate a response that contains a LIST of values. Convert the
 * response to a JSON document (JsonPath) and validate.
 *
 * Approach:
 *  1. POST /booking to create a booking (assignment input body), print response.
 *  2. GET /booking - returns a JSON ARRAY: [ {bookingid: 1}, {bookingid: 2}, ... ]
 *  3. Convert the response to a JSON document via response.jsonPath() / new JsonPath(...)
 *  4. Validate the LIST contents using:
 *       - hasItem(value)
 *       - everyItem(matcher)
 *       - hasSize(...)
 *       - List<Integer> bookingIds = jsonPath.getList("bookingid", Integer.class)
 */
public class ListOfValuesTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";

    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    private static int createdBookingId;

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 1 - POST /booking and print response.
     */
    @Test(priority = 1, description = "POST /booking and print response")
    public void createBookingAndPrintResponse() {

        System.out.println("\n[TEST START] createBookingAndPrintResponse");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post("/booking")
                .then()
                    .statusCode(200)
                    .extract().response();

        createdBookingId = response.jsonPath().getInt("bookingid");
        System.out.println("Created bookingid : " + createdBookingId);
        System.out.println("\n--- POST response ---");
        System.out.println(response.getBody().asPrettyString());
        System.out.println("[TEST PASSED] Booking created.\n");
    }

    /**
     * Steps 2-3 - Validate the LIST response (GET /booking) by converting
     * to a JSON document and using list matchers + JsonPath extraction.
     */
    @Test(priority = 2, description = "GET /booking - validate list of values + print",
          dependsOnMethods = "createBookingAndPrintResponse")
    public void validateListOfValuesFromResponse() {

        System.out.println("\n[TEST START] validateListOfValuesFromResponse");

        // 1) GET /booking - returns a JSON ARRAY
        Response response = RestAssured
                .given()
                .when()
                    .get("/booking")
                .then()
                    .statusCode(200)
                    // Validate using inline list matchers in the chain
                    .body("$",         hasSize(greaterThanOrEqualTo(1)))
                    .body("size()",    greaterThan(0))
                    .body("bookingid", everyItem(notNullValue()))
                    // Our just-created booking id should be in the list
                    .body("bookingid", hasItem(createdBookingId))
                    .extract().response();

        // 2) Convert response to a JSON document for further validation
        JsonPath jsonDoc = response.jsonPath();

        // Extract the list of bookingid values as List<Integer>
        List<Integer> bookingIds = jsonDoc.getList("bookingid", Integer.class);

        // Extract the entire array as List<Map> so each element can be inspected
        List<Map<String, Object>> bookings = jsonDoc.getList("$");

        System.out.println("Total bookings in list : " + bookings.size());
        System.out.println("First 5 booking ids   : "
                + bookingIds.subList(0, Math.min(5, bookingIds.size())));
        System.out.println("Created bookingid is in list : "
                + bookingIds.contains(createdBookingId));

        // Programmatic assertions on the list contents
        Assert.assertNotNull(bookings,    "FAILED: list was null");
        Assert.assertFalse(bookings.isEmpty(), "FAILED: list was empty");
        Assert.assertTrue(bookingIds.contains(createdBookingId),
                "FAILED: just-created bookingid " + createdBookingId + " was not in the list");

        // Every entry must have a 'bookingid' key
        for (Map<String, Object> b : bookings) {
            Assert.assertTrue(b.containsKey("bookingid"),
                    "FAILED: an entry was missing 'bookingid': " + b);
        }

        // Step 3 - Print
        System.out.println("\n--- Sample of GET /booking list (first 3 entries) ---");
        bookings.subList(0, Math.min(3, bookings.size()))
                .forEach(b -> System.out.println("  " + b));

        System.out.println("[TEST PASSED] List of values validated via JSON document.\n");
    }

    /**
     * Bonus - filtered list (server-side filtering with query params).
     */
    @Test(priority = 3, description = "GET /booking?firstname=Jim - validate filtered list")
    public void validateFilteredListOfValues() {

        System.out.println("\n[TEST START] validateFilteredListOfValues");

        Response response = RestAssured
                .given()
                    .queryParam("firstname", "Jim")
                .when()
                    .get("/booking")
                .then()
                    .statusCode(200)
                    .body("$",         hasSize(greaterThanOrEqualTo(1)))
                    .body("bookingid", everyItem(notNullValue()))
                    .extract().response();

        List<Integer> filteredIds = response.jsonPath().getList("bookingid", Integer.class);
        System.out.println("Bookings with firstname=Jim : " + filteredIds.size());
        System.out.println("[TEST PASSED] Filtered list validated.\n");
    }

    /**
     * Bonus - new JsonPath() from raw response string. Same outcome as
     * response.jsonPath() but explicitly converts the string into a
     * "JSON document" object.
     */
    @Test(priority = 4, description = "Convert raw response string to JsonPath document and validate")
    public void convertRawStringToJsonPathDocument() {

        System.out.println("\n[TEST START] convertRawStringToJsonPathDocument");

        String rawJson = RestAssured
                .given()
                .when()
                    .get("/booking")
                .then()
                    .statusCode(200)
                    .extract().asString();

        // Convert raw response string to a JSON document
        JsonPath doc = new JsonPath(rawJson);

        int size = doc.getList("$").size();
        List<Integer> bookingIds = doc.getList("bookingid", Integer.class);

        System.out.println("Parsed JSON document - " + size + " entries");
        System.out.println("First 3 ids: "
                + bookingIds.subList(0, Math.min(3, bookingIds.size())));

        Assert.assertTrue(size > 0, "FAILED: expected non-empty list");
        Assert.assertEquals(bookingIds.size(), size, "FAILED: id count != entry count");

        System.out.println("[TEST PASSED] Raw string converted to JsonPath document.\n");
    }
}
