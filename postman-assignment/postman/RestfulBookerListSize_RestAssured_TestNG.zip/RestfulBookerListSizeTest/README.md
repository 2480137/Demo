# List Size Check - REST Assured + TestNG

POST /booking on Restful Booker, then verify the size of a list in the
response using REST Assured's list-size matchers.

## Note on the Response

POST /booking returns `{ "bookingid": <int>, "booking": {...} }` - no list
inside it. GET /booking returns a JSON ARRAY of booking ids - that's the
list this test exercises. The POST is still done first (and printed to
console as required by step 3 of the assignment); the size assertions
target the GET /booking list.

## List-Size Matchers Demonstrated

```java
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.equalTo;

.body("$",       hasSize(N))            // exact size
.body("$",       hasSize(greaterThan(0))) // size with another matcher
.body("size()",  equalTo(N))             // GPath size() function
.body("size()",  greaterThan(0))         // size > N
```

## Test Methods

| # | Method                              | Purpose                                                     |
|---|-------------------------------------|-------------------------------------------------------------|
| 1 | `verifyListSizeInResponse`          | POST + print + GET list + size matchers (`hasSize`, `size()`).|
| 2 | `verifyFilteredListSize`            | GET /booking?firstname=Jim - filtered list size check.       |
| 3 | `verifyListSizeWithTestNGAssert`    | Extract list, verify size with TestNG `Assert`.              |

## Run

```bash
mvn clean test
```

## Notes

- POST /booking returns 200, not 201.
- Restful Booker resets data every 10 minutes - list size varies between
  runs. The tests use `>= 1` and `greaterThan(0)` so they remain stable.
