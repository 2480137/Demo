package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.greaterThanOrEqualTo;
import static org.hamcrest.Matchers.hasSize;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Hands-On 14: Validating response using List Size Check in REST Assured.
 *
 * Scenario:
 *  1. POST /booking with the assignment body (creates a booking).
 *  2. Verify size of a list in the response.
 *  3. Print the response.
 *
 * The POST /booking response itself does NOT contain a list, but the
 * surrounding API does:
 *   - GET /booking          -> returns a JSON ARRAY of booking ids
 *     [ { "bookingid": 1 }, { "bookingid": 2 }, ... ]
 *
 * This test creates a booking via POST (printed to console as required by
 * step 3), then exercises list-size matchers against the GET /booking
 * list. That demonstrates the assignment's specific ask without needing
 * a list inside the POST response itself.
 *
 * List-size matchers shown:
 *   .body(path, hasSize(N))                  - exact size
 *   .body(path + ".size()", equalTo(N))      - GPath size() function
 *   .body(path + ".size()", greaterThan(N))  - size lower bound
 */
public class ListSizeCheckTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";

    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 1 - POST /booking and print the response (assignment step 3).
     * Step 2 - Verify list size: GET /booking returns a LIST of booking
     *          ids - check its size is > 0 (and prove the exact size).
     */
    @Test(priority = 1, description = "POST /booking + verify size of GET /booking list + print")
    public void verifyListSizeInResponse() {

        System.out.println("\n[TEST START] verifyListSizeInResponse");

        // 1. POST - create a booking, print the response (step 3 of assignment)
        Response postResp = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post("/booking")
                .then()
                    .statusCode(200)
                    .extract().response();

        System.out.println("\n--- POST /booking response (pretty) ---");
        System.out.println(postResp.getBody().asPrettyString());

        // 2. GET /booking - returns a LIST of bookings
        Response listResp = RestAssured
                .given()
                .when()
                    .get("/booking")
                .then()
                    .statusCode(200)
                    .body("$", notNullValue())
                    // List size assertions:
                    .body("$",        hasSize(greaterThanOrEqualTo(1))) // at least our new one
                    .body("size()",   greaterThan(0))                    // GPath size()
                    .extract().response();

        // Read the actual size for printing/log
        List<?> bookings = listResp.jsonPath().getList("$");
        int actualSize = bookings.size();

        System.out.println("\n--- GET /booking response - list size ---");
        System.out.println("Number of bookings in list : " + actualSize);
        System.out.println("First 3 entries           : " + bookings.subList(0, Math.min(3, actualSize)));

        // Tighter assertion using the exact size we just observed
        RestAssured
                .given()
                .when()
                    .get("/booking")
                .then()
                    .body("$",            hasSize(actualSize))
                    .body("size()",       equalTo(actualSize))
                    .body("bookingid",    hasSize(actualSize));

        Assert.assertTrue(actualSize > 0, "FAILED: expected at least one booking, got " + actualSize);

        System.out.println("[TEST PASSED] List size " + actualSize + " verified via hasSize() and size().\n");
    }

    /**
     * Bonus - GET /booking?firstname=Jim filters by firstname. The result
     * is still a list, so size matchers still apply but typically with
     * tighter bounds.
     */
    @Test(priority = 2, description = "GET /booking?firstname=Jim - filtered list size check")
    public void verifyFilteredListSize() {

        System.out.println("\n[TEST START] verifyFilteredListSize");

        Response resp = RestAssured
                .given()
                    .queryParam("firstname", "Jim")
                .when()
                    .get("/booking")
                .then()
                    .statusCode(200)
                    .body("$",      hasSize(greaterThanOrEqualTo(1)))
                    .body("size()", greaterThan(0))
                    .extract().response();

        int size = resp.jsonPath().getList("$").size();
        System.out.println("Filtered list size (firstname=Jim) : " + size);
        System.out.println("[TEST PASSED] Filtered list size " + size + " verified.\n");
    }

    /**
     * Bonus - extract the list and check size with TestNG Assert.
     */
    @Test(priority = 3, description = "GET /booking - extract list and assert size with TestNG")
    public void verifyListSizeWithTestNGAssert() {

        System.out.println("\n[TEST START] verifyListSizeWithTestNGAssert");

        List<Object> bookings = RestAssured
                .given()
                .when()
                    .get("/booking")
                .then()
                    .statusCode(200)
                    .extract().jsonPath().getList("$");

        int size = bookings.size();
        System.out.println("Extracted list size : " + size);

        Assert.assertNotNull(bookings, "FAILED: list was null");
        Assert.assertTrue(size > 0, "FAILED: list was empty");

        System.out.println("[TEST PASSED] List size " + size + " verified via TestNG.\n");
    }
}
