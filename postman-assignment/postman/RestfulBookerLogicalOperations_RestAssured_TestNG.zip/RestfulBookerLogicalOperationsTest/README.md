# Logical Operations - REST Assured + TestNG

POST /booking on Restful Booker, perform AND/OR/NOT logic on response assertions.

## Hamcrest Logical Matchers

| Matcher                        | Logic   | Behaviour                                  |
|--------------------------------|---------|--------------------------------------------|
| `allOf(m1, m2, ...)`           | **AND** | Every nested matcher must pass             |
| `anyOf(m1, m2, ...)`           | **OR**  | At least one nested matcher must pass      |
| `not(matcher)`                 | **NOT** | The nested matcher must FAIL               |

## Examples

```java
.body("booking.totalprice", allOf(greaterThan(100), lessThan(200), equalTo(111)));
.body("booking.firstname",  anyOf(equalTo("Jim"), equalTo("Sally")));
.body("booking.firstname",  not(equalTo("Bob")));

// Nested
.body("booking.firstname",
    allOf(
        notNullValue(),
        anyOf(equalTo("Jim"), equalTo("John")),
        not(equalTo("Bob"))
    ));
```

## Test Methods

| # | Method                              | Purpose                                                  |
|---|-------------------------------------|----------------------------------------------------------|
| 1 | `verifyResponseWithLogicalOperators`| AND/OR/NOT on body and status code + print response.     |
| 2 | `nestedLogicalCompositions`         | More complex nested compositions of AND/OR/NOT.          |

## Run

```bash
mvn clean test
```
