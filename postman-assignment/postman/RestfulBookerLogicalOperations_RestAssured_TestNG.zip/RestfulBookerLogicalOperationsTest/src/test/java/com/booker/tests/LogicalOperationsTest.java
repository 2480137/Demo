package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anyOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.lessThan;
import static org.hamcrest.Matchers.not;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.startsWith;

/**
 * Hands-On 17: Validating response using Logical Operations in REST Assured.
 *
 * Goal: Use AND / OR / NOT logic in response assertions via Hamcrest:
 *   allOf(...)  -> AND  - every nested matcher must pass
 *   anyOf(...)  -> OR   - at least one nested matcher must pass
 *   not(...)    -> NOT  - the nested matcher must FAIL
 */
public class LogicalOperationsTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 2 - AND / OR / NOT logical operations on the response.
     * Step 3 - Print response.
     */
    @Test(priority = 1, description = "POST /booking - allOf, anyOf, not + print response")
    public void verifyResponseWithLogicalOperators() {

        System.out.println("\n[TEST START] verifyResponseWithLogicalOperators");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(200)
                    // ---- AND ----
                    // firstname is "Jim" AND not null AND contains "i"
                    .body("booking.firstname",
                          allOf(notNullValue(), equalTo("Jim"), containsString("i")))
                    // totalprice > 100 AND < 200 AND equals 111
                    .body("booking.totalprice",
                          allOf(greaterThan(100), lessThan(200), equalTo(111)))
                    // bookingid not null AND > 0
                    .body("bookingid",
                          allOf(notNullValue(), greaterThan(0)))
                    // ---- OR ----
                    // firstname is "Jim" OR "Sally"
                    .body("booking.firstname",
                          anyOf(equalTo("Jim"), equalTo("Sally")))
                    // additionalneeds matches Breakfast OR Lunch OR Dinner
                    .body("booking.additionalneeds",
                          anyOf(equalTo("Breakfast"), equalTo("Lunch"), equalTo("Dinner")))
                    // depositpaid is true OR false (always true for booleans)
                    .body("booking.depositpaid",
                          anyOf(is(true), is(false)))
                    // ---- NOT ----
                    // firstname is NOT "Bob"
                    .body("booking.firstname",       not(equalTo("Bob")))
                    // totalprice is NOT 0
                    .body("booking.totalprice",      not(equalTo(0)))
                    // lastname does NOT contain "x"
                    .body("booking.lastname",        not(containsString("x")))
                    // ---- Combined: AND of (existence, OR(...), NOT(...)) ----
                    .body("booking.firstname",
                          allOf(
                              notNullValue(),
                              anyOf(equalTo("Jim"), equalTo("John")),
                              not(equalTo("Bob"))
                          ))
                    // ---- Logic at status code level too ----
                    .statusCode(allOf(greaterThan(199), lessThan(300)))
                    .statusCode(anyOf(is(200), is(204)))
                    .extract().response();

        // Step 3 - print
        System.out.println("Request URL : " + BASE_URI + ENDPOINT);
        System.out.println("Status code : " + response.getStatusCode());
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());
        System.out.println("[TEST PASSED] AND / OR / NOT logical operations verified.\n");
    }

    /**
     * Bonus - more complex compound logic.
     */
    @Test(priority = 2, description = "Nested logical compositions")
    public void nestedLogicalCompositions() {

        System.out.println("\n[TEST START] nestedLogicalCompositions");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    // ((startsWith "2018" OR "2019") AND (NOT containsString "31"))
                    .body("booking.bookingdates.checkin",
                          allOf(
                              anyOf(startsWith("2018"), startsWith("2019")),
                              not(containsString("31"))
                          ))
                    // (totalprice >= 1 AND totalprice <= 10000) AND (NOT 0 AND NOT 99999)
                    .body("booking.totalprice",
                          allOf(
                              greaterThan(0),
                              lessThan(10000),
                              not(equalTo(0)),
                              not(equalTo(99999))
                          ))
                    // (firstname is in {Jim, John, Jane}) AND (NOT empty-ish names)
                    .body("booking.firstname",
                          allOf(
                              anyOf(equalTo("Jim"), equalTo("John"), equalTo("Jane")),
                              not(equalTo("")),
                              not(equalTo("Anonymous"))
                          ));

        System.out.println("[TEST PASSED] Nested AND/OR/NOT compositions succeeded.\n");
    }
}
