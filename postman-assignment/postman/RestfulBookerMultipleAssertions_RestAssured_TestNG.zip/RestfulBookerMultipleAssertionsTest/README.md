# Multiple Assertions - REST Assured + TestNG

POST /booking on Restful Booker, perform many assertions on the response in a single chain.

## Categories of Assertions Combined

- **Status**: `statusCode`, `statusLine`
- **Headers**: `header(name, matcher)`
- **Existence**: `hasKey`, `notNullValue`
- **Equality**: `equalTo`, `is`
- **Numeric**: `greaterThan`
- **String**: `containsString`, `startsWith`
- **Compound**: `allOf`

## Test Methods

| # | Method                              | Purpose                                                 |
|---|-------------------------------------|---------------------------------------------------------|
| 1 | `multipleAssertionsInOneChain`      | 25+ chained assertions covering every category + print. |
| 2 | `multipleAssertionsChainAndTestNG`  | Chain + extract + TestNG Assert combo.                  |
| 3 | `multipleAssertionsWithRootPath`    | Same scenario compacted with `rootPath()`.              |

## Run

```bash
mvn clean test
```
