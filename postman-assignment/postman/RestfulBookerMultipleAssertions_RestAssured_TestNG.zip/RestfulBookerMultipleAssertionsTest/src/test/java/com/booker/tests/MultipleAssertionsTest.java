package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.hasKey;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.startsWith;

/**
 * Hands-On 16: Validating response using Multiple Assertions in REST Assured.
 *
 * Goal: Perform multiple assertions on the same response in one chain.
 *
 * Multiple assertions chained together cover:
 *   - Status code
 *   - Headers
 *   - Body field equality
 *   - Body field existence (notNullValue)
 *   - Body numeric checks (greaterThan)
 *   - Body string substring checks (containsString, startsWith)
 *   - Map key existence (hasKey)
 *   - Compound matchers (allOf)
 */
public class MultipleAssertionsTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 2 - Perform MULTIPLE assertions in a single chain.
     * Step 3 - Print the response.
     */
    @Test(priority = 1, description = "POST /booking - many chained assertions + print response")
    public void multipleAssertionsInOneChain() {

        System.out.println("\n[TEST START] multipleAssertionsInOneChain");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    // ---- Status & status line ----
                    .statusCode(200)
                    .statusLine(containsString("200"))
                    .statusLine(startsWith("HTTP/"))
                    // ---- Headers ----
                    .header("Content-Type", containsString("json"))
                    .header("Server",       notNullValue())
                    .header("Content-Length", notNullValue())
                    // ---- Body - existence ----
                    .body("$",                                  hasKey("bookingid"))
                    .body("$",                                  hasKey("booking"))
                    .body("booking",                            hasKey("firstname"))
                    .body("booking",                            hasKey("bookingdates"))
                    .body("booking.bookingdates",               hasKey("checkin"))
                    .body("booking.bookingdates",               hasKey("checkout"))
                    // ---- Body - not null ----
                    .body("bookingid",                          notNullValue())
                    .body("booking",                            notNullValue())
                    // ---- Body - equality ----
                    .body("booking.firstname",                  equalTo("Jim"))
                    .body("booking.lastname",                   equalTo("Brown"))
                    .body("booking.totalprice",                 equalTo(111))
                    .body("booking.depositpaid",                equalTo(true))
                    .body("booking.bookingdates.checkin",       equalTo("2018-01-01"))
                    .body("booking.bookingdates.checkout",      equalTo("2019-01-01"))
                    .body("booking.additionalneeds",            equalTo("Breakfast"))
                    // ---- Body - numeric / range ----
                    .body("bookingid",                          greaterThan(0))
                    .body("booking.totalprice",                 greaterThan(0))
                    // ---- Body - substring / prefix ----
                    .body("booking.firstname",                  containsString("im"))
                    .body("booking.bookingdates.checkin",       startsWith("2018"))
                    // ---- Body - compound (allOf) ----
                    .body("booking.firstname",                  allOf(notNullValue(), is("Jim")))
                    .body("booking.totalprice",                 allOf(greaterThan(0), is(111)))
                    .extract().response();

        // Step 3 - Print response
        System.out.println("Request URL  : " + BASE_URI + ENDPOINT);
        System.out.println("Status code  : " + response.getStatusCode());
        System.out.println("Status line  : " + response.getStatusLine());
        System.out.println("Content-Type : " + response.getContentType());
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());
        System.out.println("[TEST PASSED] 25+ chained assertions all succeeded.\n");
    }

    /**
     * Bonus - mix REST Assured chain assertions WITH TestNG Assert calls
     * after extraction. Common production pattern.
     */
    @Test(priority = 2, description = "Multiple assertions: chain + TestNG combo")
    public void multipleAssertionsChainAndTestNG() {

        System.out.println("\n[TEST START] multipleAssertionsChainAndTestNG");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    // chain assertions
                    .statusCode(200)
                    .header("Content-Type", containsString("json"))
                    .body("booking.firstname", equalTo("Jim"))
                    .body("booking.lastname",  equalTo("Brown"))
                    .extract().response();

        // TestNG assertions on extracted values
        int    bookingId  = response.jsonPath().getInt("bookingid");
        String firstname  = response.jsonPath().getString("booking.firstname");
        Integer total     = response.jsonPath().getInt("booking.totalprice");
        Boolean deposit   = response.jsonPath().getBoolean("booking.depositpaid");

        Assert.assertTrue(bookingId > 0,  "FAILED: bookingid should be > 0");
        Assert.assertEquals(firstname, "Jim",   "FAILED: firstname mismatch");
        Assert.assertEquals(total, Integer.valueOf(111), "FAILED: totalprice mismatch");
        Assert.assertTrue(deposit,        "FAILED: depositpaid should be true");
        Assert.assertNotNull(response.header("Date"), "FAILED: Date header missing");

        System.out.println("Chain assertions + 5 TestNG assertions all succeeded.");
        System.out.println("[TEST PASSED]\n");
    }

    /**
     * Bonus - same multi-assertion run, expressed using rootPath() for
     * compactness (relative paths under "booking").
     */
    @Test(priority = 3, description = "Multiple assertions with rootPath() for compactness")
    public void multipleAssertionsWithRootPath() {

        System.out.println("\n[TEST START] multipleAssertionsWithRootPath");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body("bookingid", greaterThan(0))
                    .rootPath("booking")
                    .body("firstname",         equalTo("Jim"))
                    .body("lastname",          equalTo("Brown"))
                    .body("totalprice",        equalTo(111))
                    .body("depositpaid",       equalTo(true))
                    .body("additionalneeds",   equalTo("Breakfast"))
                    .appendRootPath("bookingdates")
                    .body("checkin",           equalTo("2018-01-01"))
                    .body("checkout",          equalTo("2019-01-01"));

        System.out.println("[TEST PASSED] rootPath-style multi-assertion succeeded.\n");
    }
}
