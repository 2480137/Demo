# Multiple Headers Auth - REST Assured + TestNG

POST https://restful-booker.herokuapp.com/auth with multiple headers (Content-Type + Accept).

## Three Ways to Send Multiple Headers

```java
// 1. Chained .header() calls
.given()
    .header("Content-Type", "application/json")
    .header("Accept",       "application/json")

// 2. .headers(Map<String, String>)
Map<String, String> h = new HashMap<>();
h.put("Content-Type", "application/json");
h.put("Accept",       "application/json");
.given().headers(h)

// 3. Headers / Header[] objects
Headers headers = new Headers(
    new Header("Content-Type", "application/json"),
    new Header("Accept",       "application/json"));
.given().headers(headers)
```

## Run

```bash
mvn clean test
```
