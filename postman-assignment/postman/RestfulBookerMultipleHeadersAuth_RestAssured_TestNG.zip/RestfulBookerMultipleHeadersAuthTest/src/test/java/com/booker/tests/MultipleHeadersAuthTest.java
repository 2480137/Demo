package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.http.Headers;
import io.restassured.http.Header;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.Map;

import static org.hamcrest.Matchers.notNullValue;

/**
 * Hands-On 22: Get the response of an API using multiple headers.
 *
 * URL     : POST https://restful-booker.herokuapp.com/auth
 * Body    : { "username": "admin", "password": "password123" }
 * Headers : Content-Type = application/json
 *           Accept       = application/json
 *
 * Validate response, print it.
 */
public class MultipleHeadersAuthTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/auth";

    private static final String AUTH_BODY = "{\n"
            + "  \"username\" : \"admin\",\n"
            + "  \"password\" : \"password123\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI = " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * POST /auth with TWO chained .header() calls.
     */
    @Test(priority = 1, description = "POST /auth with multiple chained headers - validate + print")
    public void authWithMultipleChainedHeaders() {

        System.out.println("\n[TEST START] authWithMultipleChainedHeaders");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(AUTH_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body("token", notNullValue())
                    .extract().response();

        String token = response.jsonPath().getString("token");

        System.out.println("Request URL  : " + BASE_URI + ENDPOINT);
        System.out.println("Headers sent : Content-Type=application/json, Accept=application/json");
        System.out.println("Status code  : " + response.getStatusCode());
        System.out.println("Token        : " + token);
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        Assert.assertNotNull(token);
        Assert.assertFalse(token.isEmpty());
        System.out.println("[TEST PASSED] Multi-header request returned a valid token.\n");
    }

    /**
     * Bonus - same scenario using .headers(Map) to send multiple headers
     * at once.
     */
    @Test(priority = 2, description = "POST /auth using .headers(Map) variadic form")
    public void authWithHeadersMap() {

        System.out.println("\n[TEST START] authWithHeadersMap");

        Map<String, String> headers = new HashMap<>();
        headers.put("Content-Type", "application/json");
        headers.put("Accept",       "application/json");

        Response response = RestAssured
                .given()
                    .headers(headers)
                    .body(AUTH_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body("token", notNullValue())
                    .extract().response();

        System.out.println("Token via .headers(Map) : " + response.jsonPath().getString("token"));
        System.out.println("[TEST PASSED]\n");
    }

    /**
     * Bonus - using a Headers object with Header[] for type-safe construction.
     */
    @Test(priority = 3, description = "POST /auth using Headers / Header[] objects")
    public void authWithHeadersObject() {

        System.out.println("\n[TEST START] authWithHeadersObject");

        Headers headers = new Headers(
                new Header("Content-Type", "application/json"),
                new Header("Accept",       "application/json"));

        Response response = RestAssured
                .given()
                    .headers(headers)
                    .body(AUTH_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body("token", notNullValue())
                    .extract().response();

        System.out.println("Token via Headers object : " + response.jsonPath().getString("token"));
        System.out.println("[TEST PASSED]\n");
    }
}
