# Restful Booker PATCH Booking - REST Assured + TestNG

Maven-based Java project that automates the **"Get the response of PATCH API
request"** scenario using **REST Assured** and **TestNG**. The test creates
a fresh booking via POST, then sends `PATCH /booking/{id}` with **Basic Auth**
(`admin` / `password123`) and a **partial** booking body, and verifies that
only the fields in the body were changed - everything else stayed the same.

## Scenario

1. **Pre-condition** (in `@BeforeClass`): POST to `/booking` to create a
   fresh booking and capture its id.
2. PATCH to `https://restful-booker.herokuapp.com/booking/{id}` with:
   - **Basic Auth** header (admin / password123)
   - JSON body containing **only the fields to update** (firstname + totalprice)
3. Verify the response is `200 OK` and:
   - The PATCHed fields contain the new values.
   - The un-PATCHed fields retain their original values.

## PUT vs PATCH - The Key Distinction

| Aspect             | PUT                                          | PATCH                                          |
|--------------------|----------------------------------------------|------------------------------------------------|
| Semantics          | Replace entire resource                      | Partial update                                 |
| Body must contain  | Every field of the resource                  | Only the fields to change                      |
| Untouched fields   | Get reset (or rejected, depending on API)    | Keep their previous values                     |
| Typical body size  | Full record                                  | Just the diff                                  |
| Idempotent         | Yes                                          | Often yes, depends on the operation            |

This test **proves** the partial-update semantics of PATCH by asserting on
both the changed fields AND the unchanged fields.

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request                           | New `@Test` method                                   |
| Set the method to PATCH                     | `given().when().patch(ENDPOINT)`                     |
| Set Basic Auth (admin / password123)        | `given().auth().preemptive().basic(USER, PASS)`      |
| Set URL with `:id`                          | `pathParam("id", bookingId).patch("/booking/{id}")`  |
| Set partial request body                    | `given().body(PATCH_BODY)`                           |
| Click Send → verify response                | `Assert.assertEquals(...)` / fluent `then().body()`  |

## IMPORTANT - Why preemptive Basic Auth?

```java
.auth().preemptive().basic(USERNAME, PASSWORD)
```

REST Assured's plain `.basic(user, pass)` waits for the server to send a
**401 Unauthorized** challenge before resending the request with credentials.
Restful Booker does not issue this challenge - it returns `403 Forbidden`
immediately if the Authorization header is missing.

`.preemptive().basic(user, pass)` sends the `Authorization: Basic <base64>`
header on the **very first** request without waiting for a challenge. Always
use `preemptive()` with Restful Booker.

## Sample Request Body (Input)

The original booking (created in `@BeforeClass`):

```json
{
  "firstname":  "Jim",
  "lastname":   "Brown",
  "totalprice": 111,
  "depositpaid": true,
  "bookingdates": {
    "checkin":  "2024-01-01",
    "checkout": "2024-01-10"
  },
  "additionalneeds": "Breakfast"
}
```

The PATCH body - only the fields to change:

```json
{
  "firstname":  "James",
  "totalprice": 250
}
```

After the PATCH, the booking should contain:

| Field                       | Before        | After         | Changed?    |
|-----------------------------|---------------|---------------|-------------|
| firstname                   | Jim           | **James**     | YES (PATCHed) |
| totalprice                  | 111           | **250**       | YES (PATCHed) |
| lastname                    | Brown         | Brown         | no          |
| depositpaid                 | true          | true          | no          |
| bookingdates.checkin        | 2024-01-01    | 2024-01-01    | no          |
| bookingdates.checkout       | 2024-01-10    | 2024-01-10    | no          |
| additionalneeds             | Breakfast     | Breakfast     | no          |

The test asserts on every row of this table.

## About the Response

`PATCH /booking/{id}` returns the **full booking object** (no envelope
wrapper, same as PUT):

```json
{
    "firstname":  "James",
    "lastname":   "Brown",
    "totalprice": 250,
    "depositpaid": true,
    "bookingdates": {
        "checkin":  "2024-01-01",
        "checkout": "2024-01-10"
    },
    "additionalneeds": "Breakfast"
}
```

## Project Structure

```
RestfulBookerPatchBookingTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── RestfulBookerPatchBookingTest.java
```

## What the Test Class Does

`@BeforeClass` creates a fresh booking and captures its id in the
`bookingId` field. Every subsequent test uses that id.

| # | Method                              | Purpose                                                                                |
|---|-------------------------------------|----------------------------------------------------------------------------------------|
| 1 | `partialUpdateBookingWithPatch`     | Main: PATCH with Basic Auth + partial body, asserts changed fields AND untouched ones. |
| 2 | `patchBookingWithFluentStyle`       | Bonus - same checks expressed in REST Assured's fluent matcher style.                  |
| 3 | `patchWithoutAuthIsForbidden`       | Bonus - documents that PATCH without auth returns 403 Forbidden.                       |

## Key REST Assured Patterns

```java
// 1. PATCH with preemptive Basic Auth + partial body
.given()
    .auth().preemptive().basic("admin", "password123")
    .header("Content-Type", "application/json")
    .pathParam("id", bookingId)
    .body(PATCH_BODY)            // only the fields to change
.when()
    .patch("/booking/{id}")
.then()
    .statusCode(200);

// 2. Verify both changed AND unchanged fields after PATCH
String firstname = response.jsonPath().getString("firstname");  // "James" - changed
String lastname  = response.jsonPath().getString("lastname");   // "Brown" - unchanged
Integer price    = response.jsonPath().getInt("totalprice");    // 250    - changed
Boolean deposit  = response.jsonPath().getBoolean("depositpaid"); // true - unchanged
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=RestfulBookerPatchBookingTest#partialUpdateBookingWithPatch
```

## Expected Output (abridged)

```
Created fresh booking with id: 4271
Initial firstname  = Jim
Initial totalprice = 111
Initial lastname   = Brown      (will be left untouched by PATCH)
Initial dates      = 2024-01-01 / 2024-01-10  (untouched by PATCH)

[TEST START] partialUpdateBookingWithPatch
Request URL    : https://restful-booker.herokuapp.com/booking/4271
Method         : PATCH
Auth           : Basic (admin / ********)
Status code    : 200

--- Booking state after PATCH ---
firstname        : James    (PATCHed)
totalprice       : 250      (PATCHed)
lastname         : Brown    (untouched)
depositpaid      : true     (untouched)
bookingdates.checkin  : 2024-01-01  (untouched)
bookingdates.checkout : 2024-01-10  (untouched)
additionalneeds  : Breakfast    (untouched)
[TEST PASSED] PATCH updated 2 fields and preserved 5 others.

[TEST START] patchWithoutAuthIsForbidden
Status code (no auth) : 403
[TEST PASSED] PATCH correctly rejected without auth.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- Each test run creates a brand-new booking, so the id will differ on
  every execution; the test does not assume a specific id.
- Restful Booker also supports auth via `Cookie: token=<token>` (where the
  token is obtained from POST /auth). This project uses Basic Auth as the
  assignment specifies, but Cookie-based auth is interchangeable.
- If the network is unavailable, all tests will fail with connection errors
  - this is an infrastructure issue, not a code defect.
