package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hands-On 8: Get the response of PATCH API request - automated with REST Assured.
 *
 * Postman scenario (automated equivalent below):
 *   Method   : PATCH
 *   URL      : https://restful-booker.herokuapp.com/booking/{id}
 *   Auth     : Basic Auth (admin / password123)
 *   Body     : Partial booking JSON (only the fields to update)
 *   Action   : Click Send and verify the response
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. baseURI configured to https://restful-booker.herokuapp.com
 *  4. Booking id obtained from a freshly-created booking (chained in @BeforeClass).
 *  5. PATCH sent with Basic Auth (admin / password123) and a PARTIAL body.
 *  6. Status 200 verified, plus:
 *      - the patched fields contain the new values.
 *      - the un-patched fields retain their original values.
 *
 * PUT vs PATCH:
 *  PUT  - Replaces the entire resource. Body must contain every field.
 *  PATCH - Partial update. Only fields present in the body are changed;
 *         all other fields keep their pre-PATCH values.
 *  This test proves the partial-update semantics by asserting on BOTH the
 *  updated fields AND the untouched fields.
 *
 * Why we create a fresh booking in @BeforeClass:
 *  Restful Booker resets its data every 10 minutes, so any hard-coded id
 *  may have been wiped between runs. POSTing a fresh booking guarantees
 *  the test always has a valid id to update.
 */
public class RestfulBookerPatchBookingTest {

    private static final String BASE_URI         = "https://restful-booker.herokuapp.com";
    private static final String BOOKING_ENDPOINT = "/booking";
    private static final String USERNAME         = "admin";
    private static final String PASSWORD         = "password123";

    /** Booking id created in @BeforeClass and reused by every PATCH test. */
    private int bookingId;

    /** The original payload used to create the booking in @BeforeClass. */
    private static final String INITIAL_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2024-01-01\",\n"
            + "    \"checkout\": \"2024-01-10\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    /**
     * Partial body for PATCH - only firstname and totalprice are updated.
     * After PATCH:
     *   firstname        -> changes from "Jim"  to "James"     (PATCHed)
     *   totalprice       -> changes from 111    to 250          (PATCHed)
     *   lastname         -> stays  "Brown"                       (unchanged)
     *   depositpaid      -> stays  true                          (unchanged)
     *   bookingdates     -> stays  2024-01-01 / 2024-01-10       (unchanged)
     *   additionalneeds  -> stays  "Breakfast"                   (unchanged)
     */
    private static final String PATCH_BODY = "{\n"
            + "  \"firstname\":  \"James\",\n"
            + "  \"totalprice\": 250\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Step 3 - Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;

        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");

        // Step 4 - Create a fresh booking and capture its id for the PATCH tests
        Response createResp = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(INITIAL_BODY)
                .when()
                    .post(BOOKING_ENDPOINT)
                .then()
                    .extract().response();

        Assert.assertEquals(createResp.getStatusCode(), 200,
                "FAILED: pre-condition - POST /booking returned "
                        + createResp.getStatusCode() + " (expected 200)");

        bookingId = createResp.jsonPath().getInt("bookingid");
        Assert.assertTrue(bookingId > 0,
                "FAILED: pre-condition - bookingid was not positive");

        System.out.println("Created fresh booking with id: " + bookingId);
        System.out.println("Initial firstname  = Jim");
        System.out.println("Initial totalprice = 111");
        System.out.println("Initial lastname   = Brown      (will be left untouched by PATCH)");
        System.out.println("Initial dates      = 2024-01-01 / 2024-01-10  (untouched by PATCH)");
    }

    /**
     * Steps 5-6 - Send PATCH /booking/{id} with Basic Auth and a partial body,
     * verify status 200, the updated fields, and the un-touched fields.
     */
    @Test(priority = 1,
          description = "PATCH /booking/{id} with Basic Auth - partially update a booking")
    public void partialUpdateBookingWithPatch() {

        System.out.println("\n[TEST START] partialUpdateBookingWithPatch");

        // Step 5 - Send PATCH with preemptive Basic Auth + partial body.
        // preemptive() is essential for Restful Booker - plain .basic() waits
        // for a 401 challenge that the server does not issue.
        Response response = RestAssured
                .given()
                    .auth().preemptive().basic(USERNAME, PASSWORD)
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .pathParam("id", bookingId)
                    .body(PATCH_BODY)
                .when()
                    .patch(BOOKING_ENDPOINT + "/{id}")
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + BOOKING_ENDPOINT + "/" + bookingId);
        System.out.println("Method         : PATCH");
        System.out.println("Auth           : Basic (admin / ********)");
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        // Step 6 - Status assertion
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK but got " + statusCode);

        // The PATCH response is the full booking object (no envelope wrapper)
        String firstname  = response.jsonPath().getString("firstname");
        String lastname   = response.jsonPath().getString("lastname");
        Integer totalPrice = response.jsonPath().getInt("totalprice");
        Boolean depositPaid = response.jsonPath().getBoolean("depositpaid");
        String checkin    = response.jsonPath().getString("bookingdates.checkin");
        String checkout   = response.jsonPath().getString("bookingdates.checkout");
        String additional = response.jsonPath().getString("additionalneeds");

        System.out.println("\n--- Booking state after PATCH ---");
        System.out.println("firstname        : " + firstname        + "    (PATCHed)");
        System.out.println("totalprice       : " + totalPrice       + "    (PATCHed)");
        System.out.println("lastname         : " + lastname         + "    (untouched)");
        System.out.println("depositpaid      : " + depositPaid      + "    (untouched)");
        System.out.println("bookingdates.checkin  : " + checkin     + "  (untouched)");
        System.out.println("bookingdates.checkout : " + checkout    + "  (untouched)");
        System.out.println("additionalneeds  : " + additional       + "    (untouched)");

        // PATCHed fields - must contain the new values
        Assert.assertEquals(firstname, "James",
                "FAILED: PATCH did not update firstname");
        Assert.assertEquals(totalPrice, Integer.valueOf(250),
                "FAILED: PATCH did not update totalprice");

        // Untouched fields - MUST retain the original values to prove
        // partial-update semantics
        Assert.assertEquals(lastname, "Brown",
                "FAILED: PATCH should not have changed lastname");
        Assert.assertEquals(depositPaid, Boolean.TRUE,
                "FAILED: PATCH should not have changed depositpaid");
        Assert.assertEquals(checkin, "2024-01-01",
                "FAILED: PATCH should not have changed checkin");
        Assert.assertEquals(checkout, "2024-01-10",
                "FAILED: PATCH should not have changed checkout");
        Assert.assertEquals(additional, "Breakfast",
                "FAILED: PATCH should not have changed additionalneeds");

        System.out.println("[TEST PASSED] PATCH updated 2 fields and preserved 5 others.\n");
    }

    /**
     * Bonus - same scenario expressed using REST Assured's fluent
     * then().body() Hamcrest assertions for a more compact idiom.
     */
    @Test(priority = 2,
          description = "PATCH /booking/{id} - fluent then().body() style assertions")
    public void patchBookingWithFluentStyle() {

        System.out.println("\n[TEST START] patchBookingWithFluentStyle");

        RestAssured
                .given()
                    .auth().preemptive().basic(USERNAME, PASSWORD)
                    .header("Content-Type", "application/json")
                    .pathParam("id", bookingId)
                    .body(PATCH_BODY)
                .when()
                    .patch(BOOKING_ENDPOINT + "/{id}")
                .then()
                    .assertThat()
                    .statusCode(200)
                    .contentType(org.hamcrest.Matchers.containsString("json"))
                    // Updated fields
                    .body("firstname",        org.hamcrest.Matchers.equalTo("James"))
                    .body("totalprice",       org.hamcrest.Matchers.equalTo(250))
                    // Untouched fields (proving partial-update semantics)
                    .body("lastname",         org.hamcrest.Matchers.equalTo("Brown"))
                    .body("depositpaid",      org.hamcrest.Matchers.equalTo(true))
                    .body("additionalneeds",  org.hamcrest.Matchers.equalTo("Breakfast"));

        System.out.println("[TEST PASSED] Fluent style PATCH assertions succeeded.\n");
    }

    /**
     * Bonus - PATCH requires authentication. Calling PATCH without
     * credentials should return 403 Forbidden. Documents the contract and
     * proves the auth header is actually being checked.
     */
    @Test(priority = 3,
          description = "PATCH /booking/{id} without auth - expect 403 Forbidden")
    public void patchWithoutAuthIsForbidden() {

        System.out.println("\n[TEST START] patchWithoutAuthIsForbidden");

        int statusCode = RestAssured
                .given()
                    // intentionally NO auth
                    .header("Content-Type", "application/json")
                    .pathParam("id", bookingId)
                    .body(PATCH_BODY)
                .when()
                    .patch(BOOKING_ENDPOINT + "/{id}")
                .then()
                    .extract()
                    .statusCode();

        System.out.println("Status code (no auth) : " + statusCode);

        Assert.assertEquals(statusCode, 403,
                "FAILED: expected 403 Forbidden when no auth header is sent, got " + statusCode);

        System.out.println("[TEST PASSED] PATCH correctly rejected without auth.\n");
    }
}
