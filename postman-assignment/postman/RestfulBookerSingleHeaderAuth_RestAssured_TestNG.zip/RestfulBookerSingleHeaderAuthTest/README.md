# Single Header Auth - REST Assured + TestNG

POST https://restful-booker.herokuapp.com/auth with a SINGLE header (Content-Type: application/json), validate the response, print it.

## Body

```json
{ "username": "admin", "password": "password123" }
```

## Idiom

```java
.given()
    .header("Content-Type", "application/json")   // single header
    .body(authBody)
.when()
    .post("/auth")
.then()
    .statusCode(200)
    .body("token", notNullValue());
```

## Run

```bash
mvn clean test
```

## Notes

- /auth returns `{"token": "<value>"}` on success.
- Status is 200 even on bad credentials (the body changes to a "Bad credentials" message).
