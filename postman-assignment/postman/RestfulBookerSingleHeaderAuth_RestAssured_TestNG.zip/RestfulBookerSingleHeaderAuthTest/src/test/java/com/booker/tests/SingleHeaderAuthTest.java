package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.notNullValue;

/**
 * Hands-On 21: Get the response of an API using a single header.
 *
 * URL    : POST https://restful-booker.herokuapp.com/auth
 * Body   : { "username": "admin", "password": "password123" }
 * Header : Content-Type = application/json
 *
 * Validate the response and print it.
 *
 * Note: /auth returns { "token": "<value>" } on success. The response
 * status code is 200 in both success and failure cases (it returns
 * "Bad credentials" body on failure rather than an HTTP error code).
 */
public class SingleHeaderAuthTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/auth";

    private static final String AUTH_BODY = "{\n"
            + "  \"username\" : \"admin\",\n"
            + "  \"password\" : \"password123\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI = " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * POST /auth with a single Content-Type header. Validate + print.
     */
    @Test(priority = 1, description = "POST /auth with single Content-Type header - validate + print")
    public void authWithSingleHeader() {

        System.out.println("\n[TEST START] authWithSingleHeader");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")   // single header
                    .body(AUTH_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body("token", notNullValue())
                    .extract().response();

        String token = response.jsonPath().getString("token");

        System.out.println("Request URL  : " + BASE_URI + ENDPOINT);
        System.out.println("Header sent  : Content-Type = application/json");
        System.out.println("Status code  : " + response.getStatusCode());
        System.out.println("Token        : " + token);
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        Assert.assertNotNull(token, "FAILED: token was null");
        Assert.assertFalse(token.isEmpty(), "FAILED: token was empty");
        Assert.assertTrue(token.length() >= 8, "FAILED: token shorter than expected");

        System.out.println("[TEST PASSED] /auth returned a token via single-header request.\n");
    }
}
