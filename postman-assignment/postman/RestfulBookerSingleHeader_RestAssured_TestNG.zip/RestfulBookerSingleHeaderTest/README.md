# Get a Single Header from Response - REST Assured + TestNG

Maven-based Java project that automates the **"Handle the response - get
a single header in REST Assured"** scenario. It sends a POST request to
Restful Booker's `/booking` endpoint and reads a single header from the
response using REST Assured's **`header(String headerName)`** method.

## Scenario

1. Send a **POST** to `https://restful-booker.herokuapp.com/booking` with
   the given booking body.
2. Extract the response.
3. Read a single header by name using REST Assured's `header(String name)`
   method.

## What is REST Assured's `.header(String name)` method?

The `Response` interface exposes two equivalent methods that return the
value of a single response header by name:

```java
String header(String name);      // canonical
String getHeader(String name);   // alias - same behaviour
```

Both return the header's value as a `String`, or `null` if the header is
not in the response.

```java
Response r = given().body(body)
        .when().post("/booking")
        .then().extract().response();

String contentType = r.header("Content-Type");
// e.g. "application/json; charset=utf-8"
```

## Two Places You Can Use Header Methods

### 1. After extracting the response (the assignment's ask)

```java
Response r = given().body(body)
        .when().post("/booking")
        .then().extract().response();

String value = r.header("Content-Type");        // pull out by name
String alt   = r.getHeader("Content-Type");     // alias, same thing
```

### 2. Inline inside the .then() chain

```java
.then()
    .statusCode(200)
    .header("Content-Type", containsString("json"))   // matcher form
    .header("Server",       notNullValue());          // assertion form
```

The first form is **what the assignment asks for**. The second is shown
as a bonus in this project.

## Typical Headers from POST /booking on Restful Booker

| Header           | Example value                              |
|------------------|--------------------------------------------|
| Content-Type     | `application/json; charset=utf-8`          |
| Server           | `Cowboy`                                   |
| Connection       | `keep-alive`                               |
| Date             | `<RFC 7231 timestamp>`                     |
| X-Powered-By     | `Express`                                  |
| Content-Length   | `<numeric byte count>`                     |

`Content-Type` is the most commonly read response header in tests because
it tells you whether the response body is JSON, XML, HTML, etc.

## Edge Cases Worth Knowing

| Situation                                    | Behaviour                                         |
|----------------------------------------------|---------------------------------------------------|
| Header is missing                            | `header(name)` returns **null**                    |
| Header appears multiple times in response    | `header(name)` returns the **first** occurrence    |
| Need every value for a multi-occurrence header | Use `response.headers().getList(name)`            |
| Need ALL headers as a collection             | Use `response.getHeaders()` (an `Iterable<Header>`)|
| Header name lookup is case-insensitive       | `header("content-type") == header("Content-Type")` |

## Project Structure

```
RestfulBookerSingleHeaderTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── GetSingleHeaderTest.java
```

## What the Test Class Does

| # | Method                              | Purpose                                                                       |
|---|-------------------------------------|-------------------------------------------------------------------------------|
| 1 | `getSingleHeaderFromResponse`       | Main: extract response, read Content-Type via `.header(name)`.                |
| 2 | `readMultipleHeadersByName`         | Bonus - same idiom applied to several headers in sequence.                    |
| 3 | `demonstrateGetHeaderAlias`         | Bonus - shows `getHeader(name)` is the alias of `header(name)`.               |
| 4 | `verifyHeaderInChain`               | Bonus - assert headers directly in `.then().header(name, matcher)` chain.     |

## Key REST Assured Patterns

```java
// 1. Extract the response so we can call .header(name) on it
Response response = given().body(body)
        .when().post("/booking")
        .then().extract().response();

// 2. Read a single header by name (the assignment's idiom)
String contentType = response.header("Content-Type");

// 3. Read several individual headers
String server  = response.header("Server");
String date    = response.header("Date");
String length  = response.header("Content-Length");

// 4. Alternative form - same behaviour
String alt = response.getHeader("Content-Type");

// 5. In-chain header assertion (bonus pattern)
.then()
   .header("Content-Type", containsString("json"))
   .header("Server",       notNullValue());
```

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request                           | New `@Test` method                                   |
| Set the method to POST                      | `given().when().post(ENDPOINT)`                      |
| Set the URL                                 | `RestAssured.baseURI` + endpoint                     |
| Set raw JSON body                           | `given().body(BOOKING_BODY)`                         |
| Click Send                                  | Execution of the `@Test` method                      |
| Look at "Headers" tab in Postman response   | `response.header("Content-Type")`                    |
| Right-click a header → copy value           | Print the result of `response.header(name)`          |

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=GetSingleHeaderTest#getSingleHeaderFromResponse
```

## Expected Output (abridged)

```
[TEST START] getSingleHeaderFromResponse
Request URL    : https://restful-booker.herokuapp.com/booking
Status code    : 200

--- Single header read via header("Content-Type") ---
Content-Type : application/json; charset=utf-8
[TEST PASSED] Single header read via .header("Content-Type").

[TEST START] readMultipleHeadersByName

--- Headers read via .header(name) ---
Content-Type   : application/json; charset=utf-8
Server         : Cowboy
Date           : Sat, 03 May 2026 12:55:42 GMT
Content-Length : 168
Connection     : keep-alive
[TEST PASSED] Multiple headers read individually by name.

[TEST START] demonstrateGetHeaderAlias
response.header("Content-Type")     = application/json; charset=utf-8
response.getHeader("Content-Type")  = application/json; charset=utf-8
[TEST PASSED] header() and getHeader() are equivalent.

===============================================
Total tests run: 4, Passes: 4, Failures: 0
===============================================
```

## Notes

- Header names are **case-insensitive** per HTTP RFC, and REST Assured
  follows that rule - `header("content-type")` and `header("Content-Type")`
  return the same value.
- For headers that legitimately appear more than once (e.g. `Set-Cookie`),
  use `response.headers().getList(name)` to get every value.
- POST /booking on Restful Booker returns **200 OK**, not 201 Created.
- If the network is unavailable, all tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
