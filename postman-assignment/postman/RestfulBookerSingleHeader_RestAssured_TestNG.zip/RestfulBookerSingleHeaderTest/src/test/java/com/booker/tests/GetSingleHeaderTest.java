package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Hands-On 5: Handle the response - get a single header in REST Assured.
 *
 * Scenario:
 *   Method   : POST
 *   URL      : https://restful-booker.herokuapp.com/booking
 *   Auth     : none
 *   Body     : { firstname, lastname, totalprice, depositpaid,
 *                bookingdates: { checkin, checkout },
 *                additionalneeds }
 *   Goal     : Extract the response and read a single response header
 *              using the header(String headerName) method.
 *
 * Steps covered:
 *  1. Java class created in the rest-assured framework (this file).
 *  2. POST /booking sent through REST Assured with the given body.
 *  3. Response extracted, then a single header read via header(name).
 *
 * About REST Assured's header(String headerName) method:
 *
 *   The Response interface exposes two equivalent methods that return
 *   the value of a single header by name:
 *
 *      String header(String name);      // canonical
 *      String getHeader(String name);   // alias - same thing
 *
 *   Usage:
 *      Response r = given().body(body).when().post("/booking")
 *                          .then().extract().response();
 *      String contentType = r.header("Content-Type");
 *
 *   If the header is not present, both methods return null. If the same
 *   header appears multiple times in the response, header() returns the
 *   first occurrence; use response.headers().getList(name) to get all.
 *
 *   The same approach also exists inside the fluent chain - use
 *   .header(name, matcher) inside .then() to assert directly on a
 *   header without extracting first:
 *
 *      .then().header("Content-Type", containsString("json"));
 *
 * About the API:
 *   POST /booking on Restful Booker returns 200 OK and typical headers:
 *      Content-Type     : application/json; charset=utf-8
 *      Server           : Cowboy
 *      Connection       : keep-alive
 *      Date             : <timestamp>
 *      X-Powered-By     : Express
 *      Content-Length   : <number>
 */
public class GetSingleHeaderTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    /** Step 2 - The exact request body specified in the assignment. */
    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 3 - Extract the response and read a single header using
     * the header(String headerName) method. This is the main task of
     * the assignment.
     */
    @Test(priority = 1,
          description = "POST /booking - extract response and read Content-Type via header(name)")
    public void getSingleHeaderFromResponse() {

        System.out.println("\n[TEST START] getSingleHeaderFromResponse");

        // Step 2 - Send the POST and EXTRACT the response so we can call
        // .header(name) on it
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract()
                    .response();

        // Sanity check the request worked
        Assert.assertEquals(response.getStatusCode(), 200,
                "FAILED: pre-condition status code");

        // Step 3 - Get a single header by name. This is the assignment's
        // specific ask. Each call returns the value as a String.
        String contentType = response.header("Content-Type");

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Status code    : " + response.getStatusCode());
        System.out.println("\n--- Single header read via header(\"Content-Type\") ---");
        System.out.println("Content-Type : " + contentType);

        // Verify what we got
        Assert.assertNotNull(contentType,
                "FAILED: 'Content-Type' header was missing from response");
        Assert.assertTrue(contentType.toLowerCase().contains("json"),
                "FAILED: Content-Type should mention JSON, got: " + contentType);

        System.out.println("[TEST PASSED] Single header read via .header(\"Content-Type\"). \n");
    }

    /**
     * Bonus - the same scenario reading SEVERAL named headers, one per
     * call. Demonstrates that .header(name) is the canonical way to pull
     * any individual header out of an extracted response.
     */
    @Test(priority = 2,
          description = "POST /booking - read multiple individual headers, one per .header(name) call")
    public void readMultipleHeadersByName() {

        System.out.println("\n[TEST START] readMultipleHeadersByName");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract().response();

        // Read several headers by name. Each call uses the same
        // .header(String) method - the assignment's idiom.
        String contentType   = response.header("Content-Type");
        String server        = response.header("Server");
        String date          = response.header("Date");
        String contentLength = response.header("Content-Length");
        String connection    = response.header("Connection");

        System.out.println("\n--- Headers read via .header(name) ---");
        System.out.println("Content-Type   : " + contentType);
        System.out.println("Server         : " + server);
        System.out.println("Date           : " + date);
        System.out.println("Content-Length : " + contentLength);
        System.out.println("Connection     : " + connection);

        // Most servers send Content-Type and Date; the others vary
        Assert.assertNotNull(contentType,
                "FAILED: 'Content-Type' header was missing");
        Assert.assertNotNull(date,
                "FAILED: 'Date' header was missing");

        System.out.println("[TEST PASSED] Multiple headers read individually by name.\n");
    }

    /**
     * Bonus - .getHeader(name) is the alias of .header(name). Functionally
     * identical; choose whichever reads better in your code base.
     */
    @Test(priority = 3,
          description = "POST /booking - getHeader(name) is equivalent to header(name)")
    public void demonstrateGetHeaderAlias() {

        System.out.println("\n[TEST START] demonstrateGetHeaderAlias");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract().response();

        String viaHeader    = response.header("Content-Type");
        String viaGetHeader = response.getHeader("Content-Type");

        System.out.println("response.header(\"Content-Type\")     = " + viaHeader);
        System.out.println("response.getHeader(\"Content-Type\")  = " + viaGetHeader);

        Assert.assertEquals(viaGetHeader, viaHeader,
                "FAILED: header() and getHeader() should return the same value");

        System.out.println("[TEST PASSED] header() and getHeader() are equivalent.\n");
    }

    /**
     * Bonus - the same header check expressed directly in the fluent chain
     * with .then().header(name, matcher). Useful when no extraction is
     * needed for any other reason.
     */
    @Test(priority = 4,
          description = "POST /booking - header check directly in the .then() chain")
    public void verifyHeaderInChain() {

        System.out.println("\n[TEST START] verifyHeaderInChain");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .header("Content-Type", containsString("json"))   // chain-style header check
                    .header("Server",       notNullValue());          // matcher form

        System.out.println("Verified Content-Type contains 'json' and Server header is not null.");
        System.out.println("[TEST PASSED] In-chain header() assertions succeeded.\n");
    }
}
