# Verify Status Code with statusCode() Method - REST Assured + TestNG

Maven-based Java project that automates the **"Verify the response status
code with statusCode() method in REST Assured"** scenario. It sends a
POST request to Restful Booker's `/booking` endpoint and verifies the
response status code using REST Assured's fluent `.statusCode()` method
- the canonical way to assert HTTP status in REST Assured.

## Scenario

Send a **POST** request to:

```
https://restful-booker.herokuapp.com/booking
```

with the following body, then verify the response **status code** using
REST Assured's `.statusCode()` method:

```json
{
    "firstname": "Jim",
    "lastname": "Brown",
    "totalprice": 111,
    "depositpaid": true,
    "bookingdates": {
        "checkin":  "2018-01-01",
        "checkout": "2019-01-01"
    },
    "additionalneeds": "Breakfast"
}
```

## What is REST Assured's `.statusCode()` method?

`.statusCode(N)` is part of REST Assured's fluent
`ValidatableResponse` API. It is the **idiomatic way** to assert HTTP
status inside the `given().when().then()` chain - no separate `Assert`
call required.

```java
given()
    .body(body)
.when()
    .post("/booking")
.then()
    .statusCode(200);          // <-- the status code method
```

If the actual response status differs from 200, REST Assured raises an
`AssertionError` itself - no `Assert.assertEquals` required.

## How POST /booking responds

| Aspect       | Value                                                           |
|--------------|-----------------------------------------------------------------|
| Status code  | **200 OK** (note: NOT 201 Created - Restful Booker quirk)       |
| Auth         | Not required (POST is open; PUT/PATCH/DELETE require auth)      |
| Body shape   | `{ "bookingid": <int>, "booking": { ...echoed input... } }`     |

## Project Structure

```
RestfulBookerStatusCodeMethodTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── VerifyStatusCodeMethodTest.java
```

## What the Test Class Does

| # | Method                                  | Purpose                                                                              |
|---|-----------------------------------------|--------------------------------------------------------------------------------------|
| 1 | `verifyStatusCodeUsingStatusCodeMethod` | Main: pure `.then().statusCode(200)` - the assignment's specific ask.                |
| 2 | `verifyStatusCodeAndPrintResponse`      | Bonus - `.statusCode(200)` chained with `.extract()` to keep working with response.   |
| 3 | `verifyStatusCodeUsingTestNGAssert`     | Bonus - alternative: `.extract().statusCode()` + `Assert.assertEquals` with message.  |

## Three Ways REST Assured Verifies Status Codes

```java
// Pattern 1 - The canonical "status code method" (what the assignment asks for)
given().body(body)
   .when().post("/booking")
   .then().statusCode(200);                   // throws AssertionError if not 200

// Pattern 2 - statusCode() PLUS keep the response for further inspection
Response r = given().body(body)
        .when().post("/booking")
        .then()
            .statusCode(200)                  // assert
            .extract().response();            // and continue working with body
String message = r.jsonPath().getString("...");

// Pattern 3 - Extract status, assert with TestNG (custom message available)
int sc = given().body(body)
        .when().post("/booking")
        .then().extract().statusCode();
Assert.assertEquals(sc, 200, "custom failure message here");
```

The assignment specifically asks for **Pattern 1** - the `.statusCode()`
method directly inside the chain.

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request                           | New `@Test` method                                   |
| Set the method to POST                      | `given().when().post(ENDPOINT)`                      |
| Set the URL                                 | `RestAssured.baseURI` + endpoint path                |
| Set raw JSON body                           | `given().body(BOOKING_BODY)`                         |
| Click Send                                  | Execution of the `@Test` method                      |
| Verify "Status: 200 OK" in Postman          | `.then().statusCode(200)`                            |

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=VerifyStatusCodeMethodTest#verifyStatusCodeUsingStatusCodeMethod
```

## Expected Output (abridged)

```
[TEST START] verifyStatusCodeUsingStatusCodeMethod
Verifying status code with REST Assured's fluent .statusCode() method.
Request URL    : https://restful-booker.herokuapp.com/booking
Method         : POST
Verified that the response status code is 200.
[TEST PASSED] .statusCode(200) succeeded.

[TEST START] verifyStatusCodeAndPrintResponse
Status code (post-assertion) : 200
Response time                : 287 ms

--- Pretty-printed response body ---
{
    "bookingid": 4271,
    "booking": {
        "firstname": "Jim",
        "lastname": "Brown",
        "totalprice": 111,
        "depositpaid": true,
        "bookingdates": {
            "checkin":  "2018-01-01",
            "checkout": "2019-01-01"
        },
        "additionalneeds": "Breakfast"
    }
}

bookingid extracted: 4271
[TEST PASSED] .statusCode(200) plus body extraction succeeded.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- POST /booking on Restful Booker returns **200**, not 201 Created. The
  test asserts on 200 to match the actual API behaviour.
- Each successful POST creates a real booking on the server. Restful
  Booker resets all data every 10 minutes anyway.
- If the network is unavailable, all tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
