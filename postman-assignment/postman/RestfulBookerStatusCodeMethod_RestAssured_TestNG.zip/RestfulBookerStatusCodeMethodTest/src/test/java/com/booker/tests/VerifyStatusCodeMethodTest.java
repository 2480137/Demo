package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hands-On 1: Verify the response status code with the statusCode() method
 * in REST Assured - POST /booking on Restful Booker.
 *
 * Scenario:
 *   Method   : POST
 *   URL      : https://restful-booker.herokuapp.com/booking
 *   Auth     : none (POST /booking is open on Restful Booker)
 *   Body     : { firstname, lastname, totalprice, depositpaid,
 *                bookingdates: { checkin, checkout },
 *                additionalneeds }
 *   Verify   : Response status code (using REST Assured's statusCode() method).
 *
 * Steps covered:
 *  1. Java class created in the rest-assured framework (this file).
 *  2. POST /booking sent through REST Assured with the given body.
 *  3. Status code verified using REST Assured's fluent .statusCode() method.
 *
 * About the statusCode() method:
 *   REST Assured's then().statusCode(N) is the canonical way to assert on
 *   the HTTP status code of a response. It is part of the fluent
 *   ValidatableResponse API and integrates directly with the
 *   given().when().then() chain - no extra Assert call required.
 *
 *   given()
 *      .body(body)
 *   .when()
 *      .post("/booking")
 *   .then()
 *      .statusCode(200);     // <-- the assignment's "status code method"
 *
 * About the API:
 *   POST /booking on Restful Booker returns 200 OK (NOT 201). Response shape:
 *      {
 *          "bookingid": <int>,
 *          "booking": { ...echoed input... }
 *      }
 *   No authentication is required - the booking endpoint is open. PUT,
 *   PATCH, and DELETE on /booking/{id} require auth, but POST does not.
 */
public class VerifyStatusCodeMethodTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    /** Step 2 - The exact request body specified in the assignment. */
    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 3 - Send POST and verify the response status code using REST
     * Assured's .statusCode() method. This is the most idiomatic form -
     * the assertion lives inside the same fluent chain as the request.
     */
    @Test(priority = 1,
          description = "POST /booking - verify status code 200 using .statusCode() method")
    public void verifyStatusCodeUsingStatusCodeMethod() {

        System.out.println("\n[TEST START] verifyStatusCodeUsingStatusCodeMethod");
        System.out.println("Verifying status code with REST Assured's fluent .statusCode() method.");

        // The "status code method" the assignment refers to.
        // If the actual status differs from 200, REST Assured itself will
        // raise an AssertionError - no Assert.* needed.
        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200);                 // <-- the status code method

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Method         : POST");
        System.out.println("Verified that the response status code is 200.");
        System.out.println("[TEST PASSED] .statusCode(200) succeeded.\n");
    }

    /**
     * Bonus - also extract the response so the body can be printed for
     * visibility. Demonstrates that .statusCode() can be combined with
     * .extract().response() to keep working with the response after the
     * assertion. This is the most common production pattern.
     */
    @Test(priority = 2,
          description = "POST /booking - .statusCode(200) + extract response for inspection")
    public void verifyStatusCodeAndPrintResponse() {

        System.out.println("\n[TEST START] verifyStatusCodeAndPrintResponse");

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)                  // assert + continue
                    .extract()
                    .response();

        // The .statusCode(200) above already proved the status. The print
        // below is purely for log visibility; it would only run if the
        // assertion above had passed.
        System.out.println("Status code (post-assertion) : " + response.getStatusCode());
        System.out.println("Response time                : " + response.getTime() + " ms");
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        Integer bookingId = response.jsonPath().getInt("bookingid");
        System.out.println("\nbookingid extracted: " + bookingId);

        Assert.assertNotNull(bookingId,
                "FAILED: 'bookingid' missing from response");
        Assert.assertTrue(bookingId > 0,
                "FAILED: bookingid should be positive, got " + bookingId);

        System.out.println("[TEST PASSED] .statusCode(200) plus body extraction succeeded.\n");
    }

    /**
     * Bonus - alternative pattern: extract the status code and assert with
     * TestNG. Shows the relationship between REST Assured's fluent
     * statusCode() method and the underlying numeric value.
     *
     * This pattern is sometimes preferred when:
     *  - The expected code depends on test-method input data.
     *  - A custom failure message is needed.
     *  - Multiple status codes are acceptable (e.g. assert 200 OR 201).
     */
    @Test(priority = 3,
          description = "POST /booking - extract status code and verify with TestNG Assert")
    public void verifyStatusCodeUsingTestNGAssert() {

        System.out.println("\n[TEST START] verifyStatusCodeUsingTestNGAssert");

        int statusCode = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract()
                    .statusCode();              // returns int instead of asserting

        System.out.println("Extracted status code: " + statusCode);

        // TestNG-style assertion with a custom failure message
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected status code 200 but got " + statusCode
                        + " - check that POST /booking is still returning 200 (and not 201)");

        System.out.println("[TEST PASSED] TestNG-style status code assertion succeeded.\n");
    }
}
