# Verify with statusLine() + Hamcrest Matchers - REST Assured + TestNG

Maven-based Java project that automates the **"Verify the response status
code with assertion using Hamcrest matchers and the statusLine() method"**
scenario. It sends a POST request to Restful Booker's `/booking` endpoint
and verifies the response status using both:

1. REST Assured's **`.statusLine()`** method
2. **Hamcrest matchers** (`equalTo`, `is`, `containsString`, `startsWith`,
   `greaterThan`, `notNullValue`, ...)

## Scenario

Send a **POST** request to:

```
https://restful-booker.herokuapp.com/booking
```

with the following body, then verify the response status using
REST Assured's `.statusLine()` and Hamcrest matchers:

```json
{
    "firstname": "Jim",
    "lastname": "Brown",
    "totalprice": 111,
    "depositpaid": true,
    "bookingdates": {
        "checkin":  "2018-01-01",
        "checkout": "2019-01-01"
    },
    "additionalneeds": "Breakfast"
}
```

## Note on the Assignment Wording

The assignment **title** says "Hamcrest matchers" but **step 3** says
"statusLine method". These are complementary, not contradictory:

- `.statusLine()` is the REST Assured method that asserts on the **full
  HTTP status line** (e.g. `"HTTP/1.1 200 OK"`).
- It has overloads accepting either a literal string OR a Hamcrest
  matcher.

This project covers **both interpretations**:

| Test method                                    | Step 3 (statusLine) | Title (Hamcrest) |
|------------------------------------------------|---------------------|------------------|
| `verifyStatusLineWithLiteralString`            | YES (literal)       | no               |
| `verifyStatusLineWithHamcrestMatchers`         | YES                 | YES              |
| `verifyStatusCodeWithHamcrestMatchers`         | partial             | YES              |
| `verifyResponseBodyWithHamcrestMatchers`       | partial             | YES (body)       |

## What is the HTTP Status Line?

The status line is the **first line** of every HTTP response and contains
three parts:

```
HTTP/1.1 200 OK
└──┬──┘ └┬┘ └┬┘
   │     │   └─ Reason phrase ("OK", "Not Found", "Bad Request", ...)
   │     └─── Status code (200, 404, 400, ...)
   └─────────  HTTP version ("HTTP/1.1", "HTTP/2", ...)
```

`.statusLine(...)` asserts on this entire line, not just the numeric code.

## REST Assured + Hamcrest - The Combination

Both `.statusCode()` and `.statusLine()` have **two overloads**:

```java
// Literal value form
.statusCode(200)
.statusLine("HTTP/1.1 200 OK")

// Matcher form (Hamcrest)
.statusCode(is(200))
.statusCode(equalTo(200))
.statusCode(greaterThan(199))
.statusLine(equalTo("HTTP/1.1 200 OK"))
.statusLine(containsString("200"))
.statusLine(startsWith("HTTP/"))
```

The matcher form is more flexible:
- `containsString("200")` survives variations in HTTP version or whitespace.
- `greaterThan(199)` accepts any 2xx code.
- `anyOf(is(200), is(204))` accepts either a 200 or 204.

## Common Hamcrest Matchers Used in REST Assured

| Matcher                                          | What it does                                     |
|--------------------------------------------------|--------------------------------------------------|
| `equalTo(value)`                                 | Strict equality                                  |
| `is(value)`                                      | Reads more naturally; same as `equalTo`          |
| `containsString(substr)`                         | Substring match for strings                      |
| `startsWith(prefix)` / `endsWith(suffix)`        | Anchored substring match                         |
| `greaterThan(N)` / `lessThan(N)`                 | Numeric comparison                               |
| `notNullValue()` / `nullValue()`                 | Null check                                       |
| `not(otherMatcher)`                              | Negation                                         |
| `anyOf(m1, m2, ...)` / `allOf(m1, m2, ...)`      | Boolean combinations                             |
| `hasSize(N)` / `empty()`                         | Collection assertions                            |
| `everyItem(matcher)`                             | Check every element of a collection              |

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request                           | New `@Test` method                                   |
| Set the method to POST                      | `given().when().post(ENDPOINT)`                      |
| Set the URL                                 | `RestAssured.baseURI` + endpoint                     |
| Set raw JSON body                           | `given().body(BOOKING_BODY)`                         |
| Click Send                                  | Execution of the `@Test` method                      |
| `pm.response.to.have.status(200)` in Tests  | `.then().statusCode(200)` or `.statusLine(...)`      |
| `pm.expect(...).to.include(...)`            | `.body(..., containsString(...))` Hamcrest           |

## Project Structure

```
RestfulBookerStatusLineHamcrestTest/
├── pom.xml                              # Maven dependencies (incl. Hamcrest 2.2)
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── VerifyStatusLineHamcrestTest.java
```

## What the Test Class Does

| # | Method                                         | Purpose                                                                       |
|---|------------------------------------------------|-------------------------------------------------------------------------------|
| 1 | `verifyStatusLineWithLiteralString`            | `.statusLine("HTTP/1.1 200 OK")` - literal status line check.                 |
| 2 | `verifyStatusLineWithHamcrestMatchers`         | `.statusLine()` x3 with `containsString` and `startsWith` matchers.            |
| 3 | `verifyStatusCodeWithHamcrestMatchers`         | `.statusCode()` with `is`, `equalTo`, `greaterThan` + statusLine `equalTo`.    |
| 4 | `verifyResponseBodyWithHamcrestMatchers`       | Bonus - 9 body matchers showing the full Hamcrest vocabulary on response body. |

## Key REST Assured Patterns

```java
// 1. statusLine() with a literal value
.then().statusLine("HTTP/1.1 200 OK");

// 2. statusLine() with Hamcrest matchers (more flexible)
.then().statusLine(containsString("200"))
       .statusLine(startsWith("HTTP/"));

// 3. statusCode() with Hamcrest matchers (this is the canonical
//    "Hamcrest in REST Assured" idiom)
.then().statusCode(is(200))
       .statusCode(greaterThan(199));

// 4. body() with Hamcrest matchers - the most common use of Hamcrest
//    in REST Assured tests
.then()
   .body("bookingid",         greaterThan(0))
   .body("booking.firstname", equalTo("Jim"))
   .body("booking.additionalneeds", containsString("Break"));
```

## Hamcrest Static Imports

```java
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.startsWith;
```

These are essential - without them you would have to write
`Matchers.equalTo(...)` everywhere, which kills readability.

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- **Hamcrest `2.2`** - the focus of this assignment

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=VerifyStatusLineHamcrestTest#verifyStatusLineWithHamcrestMatchers
```

## Expected Output (abridged)

```
[TEST START] verifyStatusLineWithLiteralString
Verifying status with REST Assured's .statusLine() method (string).
Verified: status line is exactly "HTTP/1.1 200 OK".
[TEST PASSED] .statusLine("HTTP/1.1 200 OK") succeeded.

[TEST START] verifyStatusLineWithHamcrestMatchers
Verifying status line with multiple Hamcrest matchers.
Verified: status line contains "200", contains "OK", and starts with "HTTP/".
[TEST PASSED] statusLine() + 3 Hamcrest matchers succeeded.

[TEST START] verifyStatusCodeWithHamcrestMatchers
Verified: statusCode is(200), equalTo(200), greaterThan(199); statusLine equalTo "HTTP/1.1 200 OK".
[TEST PASSED] statusCode() and statusLine() with Hamcrest matchers succeeded.

[TEST START] verifyResponseBodyWithHamcrestMatchers
All Hamcrest body matchers passed.
[TEST PASSED] Rich Hamcrest body assertions succeeded.

===============================================
Total tests run: 4, Passes: 4, Failures: 0
===============================================
```

## Notes

- POST /booking on Restful Booker returns **200 OK**, not 201 Created.
- The exact status line format depends on the server. Restful Booker
  currently returns `HTTP/1.1 200 OK`. If the server upgrades to HTTP/2
  in the future, the literal-string version of the test would fail; the
  Hamcrest `containsString("200")` version would still pass. **This is
  one reason production tests prefer matchers over literals.**
- Each successful POST creates a real booking on the server; Restful
  Booker resets all data every 10 minutes anyway.
- If the network is unavailable, all tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
