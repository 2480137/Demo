package com.booker.tests;

import io.restassured.RestAssured;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.startsWith;

/**
 * Hands-On 4: Verify the response status code with assertion using
 * Hamcrest matchers and the statusLine() method - POST /booking on
 * Restful Booker.
 *
 * Scenario:
 *   Method   : POST
 *   URL      : https://restful-booker.herokuapp.com/booking
 *   Auth     : none
 *   Body     : { firstname, lastname, totalprice, depositpaid,
 *                bookingdates: { checkin, checkout },
 *                additionalneeds }
 *   Verify   : Response status using REST Assured's statusLine() method
 *              and/or Hamcrest matchers.
 *
 * The assignment title and step #3 reference two related but distinct
 * concepts; this class covers both:
 *
 *   1. statusLine() method - REST Assured's fluent assertion that checks
 *      the FULL HTTP status line, not just the numeric code:
 *        e.g. "HTTP/1.1 200 OK"  (includes protocol + code + reason)
 *
 *   2. Hamcrest matchers - the static matcher library used by REST Assured
 *      for flexible assertions:
 *        equalTo, is, containsString, startsWith, greaterThan, notNullValue, ...
 *
 *  These combine: statusLine() and statusCode() each have an overload that
 *  accepts a Hamcrest Matcher instead of a literal value:
 *
 *    .then().statusLine("HTTP/1.1 200 OK")          // string literal
 *    .then().statusLine(equalTo("HTTP/1.1 200 OK")) // Hamcrest matcher
 *    .then().statusLine(containsString("200"))      // Hamcrest matcher
 *
 *    .then().statusCode(200)                        // int literal
 *    .then().statusCode(is(200))                    // Hamcrest matcher
 *
 * About the API:
 *   POST /booking on Restful Booker returns 200 OK (NOT 201).
 *   Response body shape: { "bookingid": <int>, "booking": {...} }
 *   No authentication required.
 */
public class VerifyStatusLineHamcrestTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    /** Step 2 - The exact request body specified in the assignment. */
    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 3 (statusLine interpretation) - Verify status using REST
     * Assured's statusLine() method with a literal expected string.
     *
     * The status line is the FIRST line of an HTTP response and contains
     * three parts: HTTP version + status code + reason phrase.
     *   e.g. "HTTP/1.1 200 OK"
     */
    @Test(priority = 1,
          description = "POST /booking - verify the full HTTP status line with statusLine()")
    public void verifyStatusLineWithLiteralString() {

        System.out.println("\n[TEST START] verifyStatusLineWithLiteralString");
        System.out.println("Verifying status with REST Assured's .statusLine() method (string).");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusLine("HTTP/1.1 200 OK");      // literal full status line

        System.out.println("Verified: status line is exactly \"HTTP/1.1 200 OK\".");
        System.out.println("[TEST PASSED] .statusLine(\"HTTP/1.1 200 OK\") succeeded.\n");
    }

    /**
     * Scenario title (Hamcrest interpretation) - Verify the status using
     * Hamcrest matchers with REST Assured's statusLine() method.
     *
     * Hamcrest's containsString() is more flexible than a literal string -
     * the assertion passes as long as the status line CONTAINS "200".
     * This survives minor variations like a different HTTP version or
     * extra whitespace.
     */
    @Test(priority = 2,
          description = "POST /booking - statusLine() with Hamcrest matchers")
    public void verifyStatusLineWithHamcrestMatchers() {

        System.out.println("\n[TEST START] verifyStatusLineWithHamcrestMatchers");
        System.out.println("Verifying status line with multiple Hamcrest matchers.");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    // Three Hamcrest checks against the same status line:
                    .statusLine(containsString("200"))           // contains "200"
                    .statusLine(containsString("OK"))            // contains "OK"
                    .statusLine(startsWith("HTTP/"));            // starts with "HTTP/"

        System.out.println("Verified: status line contains \"200\", contains \"OK\", and starts with \"HTTP/\".");
        System.out.println("[TEST PASSED] statusLine() + 3 Hamcrest matchers succeeded.\n");
    }

    /**
     * Bonus - the canonical "Hamcrest with status code" idiom. Both
     * statusCode() and statusLine() accept Matcher<Integer> /
     * Matcher<String> overloads, so any matcher (is, equalTo, anyOf, ...)
     * can be used in place of a literal.
     */
    @Test(priority = 3,
          description = "POST /booking - statusCode() with Hamcrest matchers")
    public void verifyStatusCodeWithHamcrestMatchers() {

        System.out.println("\n[TEST START] verifyStatusCodeWithHamcrestMatchers");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(is(200))                         // is(200) - reads naturally
                    .statusCode(equalTo(200))                    // explicit equality
                    .statusCode(greaterThan(199))                // numeric comparison
                    .statusLine(equalTo("HTTP/1.1 200 OK"));     // statusLine matcher form

        System.out.println("Verified: statusCode is(200), equalTo(200), greaterThan(199); statusLine equalTo \"HTTP/1.1 200 OK\".");
        System.out.println("[TEST PASSED] statusCode() and statusLine() with Hamcrest matchers succeeded.\n");
    }

    /**
     * Bonus - Hamcrest matchers really shine in body assertions. Demonstrates
     * a richer matcher vocabulary on the response body fields, which is
     * what most production REST Assured tests look like.
     */
    @Test(priority = 4,
          description = "POST /booking - Hamcrest matchers on body fields")
    public void verifyResponseBodyWithHamcrestMatchers() {

        System.out.println("\n[TEST START] verifyResponseBodyWithHamcrestMatchers");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(is(200))
                    .body("bookingid",                  greaterThan(0))
                    .body("booking",                    notNullValue())
                    .body("booking.firstname",          equalTo("Jim"))
                    .body("booking.lastname",           is("Brown"))
                    .body("booking.totalprice",         equalTo(111))
                    .body("booking.depositpaid",        is(true))
                    .body("booking.bookingdates.checkin",  equalTo("2018-01-01"))
                    .body("booking.bookingdates.checkout", equalTo("2019-01-01"))
                    .body("booking.additionalneeds",    containsString("Break"));

        System.out.println("All Hamcrest body matchers passed.");
        System.out.println("[TEST PASSED] Rich Hamcrest body assertions succeeded.\n");
    }
}
