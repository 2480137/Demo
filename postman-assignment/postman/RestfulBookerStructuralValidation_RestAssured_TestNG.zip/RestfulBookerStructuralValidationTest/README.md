# Structural Validation with rootPath() - REST Assured + TestNG

Maven-based Java project that automates the **"Structural Validation in
REST Assured"** scenario. It sends a POST to Restful Booker's `/booking`
endpoint, sets a JSON root via REST Assured's **`rootPath()`** method,
then verifies the existence of fields beneath that root using `.body()`
with **relative** paths.

## Scenario

1. Send a **POST** to `https://restful-booker.herokuapp.com/booking` with
   the given booking body.
2. Use **`rootPath(...)`** to set a root JSON path; check existence of
   fields with **`body(relativePath, matcher)`**.
3. Print the response to the console.

```json
{
    "firstname": "Jim",
    "lastname": "Brown",
    "totalprice": 111,
    "depositpaid": true,
    "bookingdates": {
        "checkin":  "2018-01-01",
        "checkout": "2019-01-01"
    },
    "additionalneeds": "Breakfast"
}
```

## What is REST Assured's `rootPath()`?

The `ValidatableResponse` interface (returned by `.then()`) exposes:

```java
ValidatableResponse rootPath(String rootPath);
ValidatableResponse root(String rootPath);     // alias
```

It sets a **base JSON path** for the chain. After this call, every
subsequent `.body(path, matcher)` interprets `path` as **relative** to
the root:

```java
.then()
    .rootPath("booking")
    .body("firstname", equalTo("Jim"))           // -> booking.firstname
    .body("lastname",  equalTo("Brown"))         // -> booking.lastname
    .body("bookingdates.checkin",
          equalTo("2018-01-01"));                // -> booking.bookingdates.checkin
```

## The rootPath Family of Methods

| Method                          | Effect                                                  |
|---------------------------------|---------------------------------------------------------|
| `rootPath(String r)`            | **Replace** the current root path                       |
| `root(String r)`                | Alias of `rootPath(...)`                                |
| `appendRootPath(String r)`      | **Append** to existing root with a `.`                  |
| `detachRootPath(String r)`      | **Remove** a piece from the existing root               |
| `noRootPath()`                  | **Clear** the root entirely (back to absolute paths)    |

## Why Use rootPath - Readability Win

Without `rootPath`, every path is fully qualified:

```java
.then()
    .body("booking.firstname",                equalTo("Jim"))
    .body("booking.lastname",                 equalTo("Brown"))
    .body("booking.totalprice",               equalTo(111))
    .body("booking.depositpaid",              equalTo(true))
    .body("booking.bookingdates.checkin",     equalTo("2018-01-01"))
    .body("booking.bookingdates.checkout",    equalTo("2019-01-01"));
```

With `rootPath("booking")`, paths are shorter and grouped:

```java
.then()
    .rootPath("booking")
    .body("firstname",                equalTo("Jim"))
    .body("lastname",                 equalTo("Brown"))
    .body("totalprice",               equalTo(111))
    .body("depositpaid",              equalTo(true))
    .body("bookingdates.checkin",     equalTo("2018-01-01"))
    .body("bookingdates.checkout",    equalTo("2019-01-01"));
```

Both produce identical assertions. The win scales with the number of
fields under the same parent.

## What "Structural Validation" Means in This Context

The assignment phrases the goal as: *use rootPath, then check for the
**existence** of fields with body()*. The natural matcher for that is
`notNullValue()`:

```java
.then()
    .rootPath("booking")
    .body("firstname",                notNullValue())
    .body("lastname",                 notNullValue())
    .body("bookingdates",             notNullValue())
    .body("bookingdates.checkin",     notNullValue())
    .body("bookingdates.checkout",    notNullValue())
    .body("additionalneeds",          notNullValue());
```

This proves the **structure** of the response is correct - every expected
field is present at its expected relative path. Combined with value
matchers it gives full structure-AND-data verification.

## Project Structure

```
RestfulBookerStructuralValidationTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── StructuralValidationTest.java
```

## What the Test Class Does

| # | Method                                        | Purpose                                                                            |
|---|-----------------------------------------------|------------------------------------------------------------------------------------|
| 1 | `structuralValidationUsingRootPath`           | Main: `rootPath("booking")` + 8 `notNullValue()` existence checks + print response. |
| 2 | `structuralValidationUsingRootAlias`          | Bonus - shows `root(...)` is the alias of `rootPath(...)`.                          |
| 3 | `structuralValidationWithAppendRootPath`      | Bonus - `rootPath("booking")` then `appendRootPath("bookingdates")` for deeper navigation. |
| 4 | `contrastWithoutAndWithRootPath`              | Bonus - the same field validations expressed both with AND without rootPath.        |
| 5 | `structureAndDataValidationUnderRoot`         | Bonus - structure (`notNullValue`) + data (`equalTo`) under the same root.          |

## Key REST Assured Patterns

```java
// 1. The canonical idiom (this assignment's specific ask)
.then()
    .rootPath("booking")
    .body("firstname",                notNullValue())
    .body("lastname",                 notNullValue())
    .body("bookingdates",             notNullValue())
    .body("bookingdates.checkin",     notNullValue())
    .body("additionalneeds",          notNullValue());

// 2. root() alias - same thing
.then().root("booking").body("firstname", equalTo("Jim"));

// 3. Append to existing root for deeper navigation
.then()
    .rootPath("booking")                              // root = booking
    .body("firstname", equalTo("Jim"))                // booking.firstname
    .appendRootPath("bookingdates")                   // root = booking.bookingdates
    .body("checkin",  equalTo("2018-01-01"));         // booking.bookingdates.checkin

// 4. Clear / detach to go back
.then()
    .rootPath("booking")
    .body("firstname", equalTo("Jim"))
    .detachRootPath("booking")                        // root cleared
    .body("bookingid", greaterThan(0));               // top-level again
// (or use noRootPath() to clear unconditionally)
```

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request, set POST + URL + body    | `given().body(...).when().post(...)`                 |
| Tests tab: `pm.response.json().booking.firstname` etc. | `.rootPath("booking").body("firstname", matcher)`   |

Postman has no direct equivalent to `rootPath()` - this is a REST Assured
convenience for chaining many field assertions under the same parent.

## How rootPath Fits in the REST Assured Validation Family

| Hands-On | Method                                      | Purpose                            |
|----------|---------------------------------------------|------------------------------------|
| 7        | `.header(name, matcher)`                    | One header                         |
| 8        | `.headers(name1, m1, name2, m2, ...)`       | Multiple headers in one call       |
| 9        | `.body(matchesJsonSchemaInClasspath)`       | Whole-body shape (JSON Schema)     |
| 10       | `.body(path, matcher)`                      | Individual fields, absolute paths  |
| 11       | `.rootPath(...).body(relativePath, matcher)`| **Structural** - this project      |

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=StructuralValidationTest#structuralValidationUsingRootPath
```

## Expected Output (abridged)

```
[TEST START] structuralValidationUsingRootPath
Request URL    : https://restful-booker.herokuapp.com/booking
Status code    : 200

--- Existence verified for these fields under root "booking" ---
  firstname             (booking.firstname)
  lastname              (booking.lastname)
  totalprice            (booking.totalprice)
  depositpaid           (booking.depositpaid)
  bookingdates          (booking.bookingdates)
  bookingdates.checkin  (booking.bookingdates.checkin)
  bookingdates.checkout (booking.bookingdates.checkout)
  additionalneeds       (booking.additionalneeds)

--- Pretty-printed response body ---
{
    "bookingid": 4271,
    "booking": {
        "firstname": "Jim",
        "lastname": "Brown",
        "totalprice": 111,
        "depositpaid": true,
        "bookingdates": { "checkin": "2018-01-01", "checkout": "2019-01-01" },
        "additionalneeds": "Breakfast"
    }
}
[TEST PASSED] Structural validation succeeded with rootPath("booking").

[TEST START] structuralValidationWithAppendRootPath
Validated nested fields using rootPath() + appendRootPath().
[TEST PASSED] appendRootPath() succeeded.

===============================================
Total tests run: 5, Passes: 5, Failures: 0
===============================================
```

## Notes

- POST /booking on Restful Booker returns **200 OK**, not 201 Created.
- `rootPath()` does NOT survive across separate request chains - it is
  only active for the duration of the single `.then()` chain in which
  it was set. Each new `given()...when()...then()` starts fresh.
- For permanent root configuration across the whole test suite, use
  `RestAssured.rootPath = "..."` (a static field), but this is rarely
  needed in practice.
- If the network is unavailable, all tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
