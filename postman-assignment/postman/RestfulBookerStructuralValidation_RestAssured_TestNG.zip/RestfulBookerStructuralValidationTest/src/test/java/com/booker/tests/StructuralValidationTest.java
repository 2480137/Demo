package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.greaterThan;
import static org.hamcrest.Matchers.notNullValue;

/**
 * Hands-On 11: Structural Validation in REST Assured.
 *
 * Scenario:
 *   Method   : POST
 *   URL      : https://restful-booker.herokuapp.com/booking
 *   Auth     : none
 *   Body     : { firstname, lastname, totalprice, depositpaid,
 *                bookingdates: { checkin, checkout },
 *                additionalneeds }
 *   Goal     : Use rootPath() to set a JSON root, then check for the
 *              existence of fields with the body() method.
 *
 * Steps covered:
 *  1. POST /booking sent through REST Assured.
 *  2. .rootPath() used to set a root JSON path; .body() then verifies
 *     existence/values of fields RELATIVE to that root.
 *  3. Response printed to the console.
 *
 * About REST Assured's rootPath() method:
 *
 *   The ValidatableResponse interface (returned by .then()) exposes:
 *
 *      ValidatableResponse rootPath(String rootPath);
 *      ValidatableResponse root(String rootPath);     // alias
 *
 *   rootPath() sets a base JSON path. After this call, every subsequent
 *   .body(path, matcher) interprets 'path' as RELATIVE to the root:
 *
 *      .then()
 *          .rootPath("booking")
 *          .body("firstname", equalTo("Jim"))           // -> booking.firstname
 *          .body("lastname",  equalTo("Brown"))          // -> booking.lastname
 *          .body("bookingdates.checkin",
 *                equalTo("2018-01-01"));                 // -> booking.bookingdates.checkin
 *
 *   Related methods on ValidatableResponse:
 *       rootPath(String)        - replace current root path
 *       root(String)            - alias of rootPath
 *       appendRootPath(String)  - append to existing root with a "."
 *       detachRootPath(String)  - remove a piece from the existing root
 *       noRootPath()            - clear the root entirely
 *
 *   "Structural validation" in the assignment's title means: verify the
 *   STRUCTURE of the response by setting roots and checking that fields
 *   exist (typically with notNullValue()) at the expected relative paths.
 *
 * Response shape:
 *   {
 *     "bookingid": <int>,
 *     "booking": {
 *       "firstname": "Jim",
 *       "lastname":  "Brown",
 *       "totalprice": 111,
 *       "depositpaid": true,
 *       "bookingdates": { "checkin": "2018-01-01", "checkout": "2019-01-01" },
 *       "additionalneeds": "Breakfast"
 *     }
 *   }
 */
public class StructuralValidationTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    /** Step 1 - The exact request body specified in the assignment. */
    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Steps 2-3 - Use rootPath("booking") to set a root, then check for
     * the existence of fields with body() using relative paths. Print
     * the response afterwards.
     */
    @Test(priority = 1,
          description = "POST /booking - rootPath(\"booking\") + body() existence checks + print response")
    public void structuralValidationUsingRootPath() {

        System.out.println("\n[TEST START] structuralValidationUsingRootPath");

        // Step 1 - Send the POST and use rootPath() so all the subsequent
        // body() calls can use short paths relative to "booking".
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    // top-level field check (no root yet)
                    .body("bookingid", notNullValue())
                    // Step 2 - set the root, then check existence of every
                    // field beneath it using relative paths
                    .rootPath("booking")
                    .body("firstname",                notNullValue())
                    .body("lastname",                 notNullValue())
                    .body("totalprice",               notNullValue())
                    .body("depositpaid",              notNullValue())
                    .body("bookingdates",             notNullValue())
                    .body("bookingdates.checkin",     notNullValue())
                    .body("bookingdates.checkout",    notNullValue())
                    .body("additionalneeds",          notNullValue())
                    .extract()
                    .response();

        // Step 3 - Print the response for console visibility
        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Status code    : " + response.getStatusCode());

        System.out.println("\n--- Existence verified for these fields under root \"booking\" ---");
        System.out.println("  firstname             (booking.firstname)");
        System.out.println("  lastname              (booking.lastname)");
        System.out.println("  totalprice            (booking.totalprice)");
        System.out.println("  depositpaid           (booking.depositpaid)");
        System.out.println("  bookingdates          (booking.bookingdates)");
        System.out.println("  bookingdates.checkin  (booking.bookingdates.checkin)");
        System.out.println("  bookingdates.checkout (booking.bookingdates.checkout)");
        System.out.println("  additionalneeds       (booking.additionalneeds)");

        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        System.out.println("[TEST PASSED] Structural validation succeeded with rootPath(\"booking\").\n");
    }

    /**
     * Bonus - root() is the alias of rootPath(). Functionally identical.
     */
    @Test(priority = 2,
          description = "POST /booking - root() is the alias of rootPath()")
    public void structuralValidationUsingRootAlias() {

        System.out.println("\n[TEST START] structuralValidationUsingRootAlias");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .root("booking")                              // alias of rootPath
                    .body("firstname",       equalTo("Jim"))
                    .body("lastname",        equalTo("Brown"))
                    .body("totalprice",      equalTo(111))
                    .body("depositpaid",     equalTo(true))
                    .body("additionalneeds", equalTo("Breakfast"));

        System.out.println("[TEST PASSED] root(\"booking\") works identically to rootPath().\n");
    }

    /**
     * Bonus - appendRootPath() lets you ADD on to the current root, which
     * is handy when you want to dive deeper into a sub-object without
     * losing the parent context.
     *
     * Sequence: root("booking") -> path is "booking"
     *           appendRootPath("bookingdates") -> path is "booking.bookingdates"
     */
    @Test(priority = 3,
          description = "POST /booking - rootPath() + appendRootPath() to navigate deeper")
    public void structuralValidationWithAppendRootPath() {

        System.out.println("\n[TEST START] structuralValidationWithAppendRootPath");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    // Set root to "booking"
                    .rootPath("booking")
                    .body("firstname", equalTo("Jim"))             // booking.firstname
                    .body("lastname",  equalTo("Brown"))           // booking.lastname
                    // Append "bookingdates" - new root is "booking.bookingdates"
                    .appendRootPath("bookingdates")
                    .body("checkin",  equalTo("2018-01-01"))       // booking.bookingdates.checkin
                    .body("checkout", equalTo("2019-01-01"));      // booking.bookingdates.checkout

        System.out.println("Validated nested fields using rootPath() + appendRootPath().");
        System.out.println("[TEST PASSED] appendRootPath() succeeded.\n");
    }

    /**
     * Bonus - contrast WITHOUT and WITH rootPath() to show the
     * readability win when validating many fields under the same parent.
     */
    @Test(priority = 4,
          description = "Contrast WITHOUT and WITH rootPath() - readability comparison")
    public void contrastWithoutAndWithRootPath() {

        System.out.println("\n[TEST START] contrastWithoutAndWithRootPath");

        // Form 1 - WITHOUT rootPath: every path is fully qualified
        System.out.println("Form 1: WITHOUT rootPath() - paths fully qualified");
        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .body("booking.firstname",                  equalTo("Jim"))
                    .body("booking.lastname",                   equalTo("Brown"))
                    .body("booking.totalprice",                 equalTo(111))
                    .body("booking.depositpaid",                equalTo(true))
                    .body("booking.bookingdates.checkin",       equalTo("2018-01-01"))
                    .body("booking.bookingdates.checkout",      equalTo("2019-01-01"))
                    .body("booking.additionalneeds",            equalTo("Breakfast"));

        // Form 2 - WITH rootPath: paths shorter and grouped clearly
        System.out.println("Form 2: WITH rootPath() - paths relative to root");
        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .rootPath("booking")
                    .body("firstname",                  equalTo("Jim"))
                    .body("lastname",                   equalTo("Brown"))
                    .body("totalprice",                 equalTo(111))
                    .body("depositpaid",                equalTo(true))
                    .body("bookingdates.checkin",       equalTo("2018-01-01"))
                    .body("bookingdates.checkout",      equalTo("2019-01-01"))
                    .body("additionalneeds",            equalTo("Breakfast"));

        System.out.println("Both forms produce identical assertions; rootPath() makes the");
        System.out.println("chain shorter and groups related fields visibly together.");
        System.out.println("[TEST PASSED] Functional equivalence demonstrated.\n");
    }

    /**
     * Bonus - structural validation can also pair the existence check
     * with type/value matchers to validate STRUCTURE *and* DATA at once.
     * This is closer to a production-quality field-level assertion.
     */
    @Test(priority = 5,
          description = "POST /booking - structure + data validation under root")
    public void structureAndDataValidationUnderRoot() {

        System.out.println("\n[TEST START] structureAndDataValidationUnderRoot");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(200)
                    .body("bookingid", notNullValue())
                    .body("bookingid", greaterThan(0))
                    .rootPath("booking")
                    .body("firstname",       notNullValue())          // exists
                    .body("firstname",       equalTo("Jim"))           // and equals Jim
                    .body("lastname",        equalTo("Brown"))
                    .body("totalprice",      equalTo(111))
                    .body("depositpaid",     equalTo(true))
                    .body("bookingdates",    notNullValue())          // sub-object exists
                    .body("bookingdates.checkin",  equalTo("2018-01-01"))
                    .body("bookingdates.checkout", equalTo("2019-01-01"))
                    .body("additionalneeds", equalTo("Breakfast"));

        System.out.println("[TEST PASSED] Structure + data validation under root.\n");
    }
}
