# Restful Booker Update Booking - REST Assured + TestNG

Maven-based Java project that automates the **"Get the response of PUT API
request"** scenario using **REST Assured** and **TestNG**. The test creates
a fresh booking via POST, then sends `PUT /booking/{id}` with **Basic Auth**
(`admin` / `password123`) and a full updated booking body, and verifies the
response.

This is the **REST Assured automated equivalent** of the manual Postman
walkthrough.

## Scenario

1. **Pre-condition** (in `@BeforeClass`): POST to `/booking` to create a
   fresh booking and capture its id.
2. PUT to `https://restful-booker.herokuapp.com/booking/{id}` with:
   - **Basic Auth** header (admin / password123)
   - JSON body containing the full updated booking
3. Verify the response is `200 OK` and contains the updated booking object.

## Why @BeforeClass creates a fresh booking

Restful Booker resets its data **every 10 minutes**, so any hard-coded id
(1, 2, 119, etc.) may have been wiped between runs. Creating a fresh
booking with `POST /booking` in `@BeforeClass` guarantees the test always
has a valid id to update, regardless of how recently the API was reset.

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request                           | New `@Test` method                                   |
| Set the method to PUT                       | `given().when().put(ENDPOINT)`                       |
| Set Basic Auth (admin / password123)        | `given().auth().preemptive().basic(USER, PASS)`      |
| Set URL with `:id`                          | `pathParam("id", bookingId).put("/booking/{id}")`    |
| Set request body                            | `given().body(UPDATED_BODY)`                         |
| Click Send → verify response                | `Assert.assertEquals(...)` / fluent `then().body()`  |

## IMPORTANT - Why preemptive Basic Auth?

```java
.auth().preemptive().basic(USERNAME, PASSWORD)
```

REST Assured's plain `.basic(user, pass)` waits for the server to send a
**401 Unauthorized** challenge before resending the request with credentials.
This is the textbook HTTP Basic Auth flow but adds a round-trip and only
works if the server actually issues the challenge.

`.preemptive().basic(user, pass)` sends the `Authorization: Basic <base64>`
header on the **very first** request without waiting for a challenge.
Restful Booker expects this preemptive form - if you use plain `.basic()` the
test will fail with `403 Forbidden`. Always use `preemptive()` with Restful
Booker.

## About PUT Semantics

PUT **replaces the entire resource** - it is not a partial update. The
request body must contain every field the booking should have AFTER the
update. Missing fields will either be set to null or cause a 400 Bad
Request, depending on the API.

For partial updates, use PATCH instead. Restful Booker supports both.

## Sample Request Body (Input)

The assignment refers to a request body "from the input file column". One
was not provided, so the project ships with this representative payload
(different from the original to demonstrate the update worked):

```json
{
  "firstname":  "James",
  "lastname":   "Brown",
  "totalprice": 200,
  "depositpaid": false,
  "bookingdates": {
    "checkin":  "2024-02-01",
    "checkout": "2024-02-10"
  },
  "additionalneeds": "Lunch"
}
```

The original booking (created in `@BeforeClass`) has firstname `Jim`,
totalprice `111`, depositpaid `true`, dates `2024-01-01` / `2024-01-10`, and
additionalneeds `Breakfast`. The PUT changes every field.

## About the Response

`PUT /booking/{id}` returns the **booking object directly** (no wrapping
`bookingid` / `booking` envelope, unlike `POST /booking`):

```json
{
    "firstname":  "James",
    "lastname":   "Brown",
    "totalprice": 200,
    "depositpaid": false,
    "bookingdates": {
        "checkin":  "2024-02-01",
        "checkout": "2024-02-10"
    },
    "additionalneeds": "Lunch"
}
```

## Project Structure

```
RestfulBookerUpdateBookingTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── RestfulBookerUpdateBookingTest.java
```

## What the Test Class Does

`@BeforeClass` creates a fresh booking and captures its id in the
`bookingId` field. Every subsequent test uses that id.

| # | Method                            | Purpose                                                                  |
|---|-----------------------------------|--------------------------------------------------------------------------|
| 1 | `updateBookingWithBasicAuth`      | Main: PUT with Basic Auth + full body, asserts every echoed field.       |
| 2 | `updateBookingWithFluentStyle`    | Bonus - same checks expressed in REST Assured's fluent matcher style.    |
| 3 | `putWithoutAuthIsForbidden`       | Bonus - documents that PUT without auth returns 403 Forbidden.           |

## Key REST Assured Patterns

```java
// 1. Preemptive Basic Auth (essential for Restful Booker)
.given()
    .auth().preemptive().basic("admin", "password123")
    .header("Content-Type", "application/json")
    .pathParam("id", bookingId)
    .body(UPDATED_BODY)
.when()
    .put("/booking/{id}")
.then()
    .statusCode(200);

// 2. Extract every field from the PUT response (no envelope wrapper)
String firstname = response.jsonPath().getString("firstname");
Integer price    = response.jsonPath().getInt("totalprice");
String checkin   = response.jsonPath().getString("bookingdates.checkin");
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=RestfulBookerUpdateBookingTest#updateBookingWithBasicAuth
```

## Expected Output (abridged)

```
Created fresh booking with id: 4271

[TEST START] updateBookingWithBasicAuth
Request URL    : https://restful-booker.herokuapp.com/booking/4271
Method         : PUT
Auth           : Basic (admin / ********)
Status code    : 200

--- Pretty-printed response body ---
{
    "firstname": "James",
    "lastname": "Brown",
    "totalprice": 200,
    "depositpaid": false,
    "bookingdates": {
        "checkin":  "2024-02-01",
        "checkout": "2024-02-10"
    },
    "additionalneeds": "Lunch"
}

--- Updated booking field values ---
firstname        : James
lastname         : Brown
totalprice       : 200
depositpaid      : false
checkin          : 2024-02-01
checkout         : 2024-02-10
additionalneeds  : Lunch
[TEST PASSED] Booking 4271 updated successfully via PUT.

[TEST START] putWithoutAuthIsForbidden
Status code (no auth) : 403
[TEST PASSED] PUT correctly rejected without auth.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- The booking id will differ on every run (fresh booking each time).
- Restful Booker also supports auth via `Cookie: token=<token>` (where the
  token is obtained from POST /auth). This project uses Basic Auth as the
  assignment specifies, but Cookie-based auth is interchangeable.
- If the network is unavailable, all tests will fail with connection errors
  - this is an infrastructure issue, not a code defect.
