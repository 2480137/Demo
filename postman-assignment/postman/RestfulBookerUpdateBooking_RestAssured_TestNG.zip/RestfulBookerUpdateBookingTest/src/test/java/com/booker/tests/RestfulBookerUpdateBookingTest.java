package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hands-On 8: Get the response of PUT API request - automated with REST Assured.
 *
 * Postman scenario (automated equivalent below):
 *   Method   : PUT
 *   URL      : https://restful-booker.herokuapp.com/booking/{id}
 *   Auth     : Basic Auth (admin / password123)
 *   Body     : Full booking JSON (PUT replaces the entire booking)
 *   Action   : Click Send and verify the response
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. baseURI configured to https://restful-booker.herokuapp.com
 *  4. Booking id obtained from a freshly-created booking (chained in @BeforeClass).
 *  5. PUT sent with Basic Auth (admin / password123) and a full booking body.
 *  6. Status 200 and the updated booking object verified in the response.
 *
 * Why we create a fresh booking in @BeforeClass:
 *   Restful Booker resets its data every 10 minutes, so any hard-coded id
 *   (e.g. 1, 2, 119) may have been wiped between runs. Creating a fresh
 *   booking via POST /booking guarantees we have a valid id to update.
 *
 * Note on PUT semantics:
 *   PUT replaces the entire resource, so the request body must contain
 *   every field the booking should have AFTER the update. Missing required
 *   fields cause Restful Booker to reject the request with a 400. The
 *   bonus test 'putWithMissingFieldsIsRejected' demonstrates this.
 */
public class RestfulBookerUpdateBookingTest {

    private static final String BASE_URI         = "https://restful-booker.herokuapp.com";
    private static final String BOOKING_ENDPOINT = "/booking";
    private static final String USERNAME         = "admin";
    private static final String PASSWORD         = "password123";

    /** Booking id created in @BeforeClass and reused by every PUT test. */
    private int bookingId;

    /** Full updated payload sent on PUT. PUT replaces every field. */
    private static final String UPDATED_BODY = "{\n"
            + "  \"firstname\":  \"James\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 200,\n"
            + "  \"depositpaid\": false,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2024-02-01\",\n"
            + "    \"checkout\": \"2024-02-10\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Lunch\"\n"
            + "}";

    /** The original payload used to create the booking in @BeforeClass. */
    private static final String INITIAL_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2024-01-01\",\n"
            + "    \"checkout\": \"2024-01-10\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Step 3 - Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;

        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");

        // Step 4 - Create a fresh booking and capture its id for the PUT tests
        Response createResp = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(INITIAL_BODY)
                .when()
                    .post(BOOKING_ENDPOINT)
                .then()
                    .extract().response();

        Assert.assertEquals(createResp.getStatusCode(), 200,
                "FAILED: pre-condition - POST /booking returned "
                        + createResp.getStatusCode() + " (expected 200)");

        bookingId = createResp.jsonPath().getInt("bookingid");
        Assert.assertTrue(bookingId > 0,
                "FAILED: pre-condition - bookingid was not positive");

        System.out.println("Created fresh booking with id: " + bookingId);
    }

    /**
     * Steps 5-6 - Send PUT /booking/{id} with Basic Auth and a full body,
     * verify status 200 and the updated booking in the response.
     */
    @Test(priority = 1,
          description = "PUT /booking/{id} with Basic Auth - update a booking and verify response")
    public void updateBookingWithBasicAuth() {

        System.out.println("\n[TEST START] updateBookingWithBasicAuth");

        // Step 5 - Send the PUT with preemptive Basic Auth + body.
        // preemptive() makes RestAssured send the Authorization header on the
        // FIRST request, instead of waiting for the server to issue a 401
        // challenge. Restful Booker expects this preemptive form.
        Response response = RestAssured
                .given()
                    .auth().preemptive().basic(USERNAME, PASSWORD)
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .pathParam("id", bookingId)
                    .body(UPDATED_BODY)
                .when()
                    .put(BOOKING_ENDPOINT + "/{id}")
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + BOOKING_ENDPOINT + "/" + bookingId);
        System.out.println("Method         : PUT");
        System.out.println("Auth           : Basic (admin / ********)");
        System.out.println("Status code    : " + statusCode);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        // Step 6 - Assertions
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK but got " + statusCode);

        // Note - on PUT, the response is the booking object itself
        // (no 'bookingid' wrapper, unlike POST /booking)
        String firstname  = response.jsonPath().getString("firstname");
        String lastname   = response.jsonPath().getString("lastname");
        Integer totalPrice = response.jsonPath().getInt("totalprice");
        Boolean depositPaid = response.jsonPath().getBoolean("depositpaid");
        String checkin    = response.jsonPath().getString("bookingdates.checkin");
        String checkout   = response.jsonPath().getString("bookingdates.checkout");
        String additional = response.jsonPath().getString("additionalneeds");

        System.out.println("\n--- Updated booking field values ---");
        System.out.println("firstname        : " + firstname);
        System.out.println("lastname         : " + lastname);
        System.out.println("totalprice       : " + totalPrice);
        System.out.println("depositpaid      : " + depositPaid);
        System.out.println("checkin          : " + checkin);
        System.out.println("checkout         : " + checkout);
        System.out.println("additionalneeds  : " + additional);

        // Verify the response reflects the values we sent on PUT
        Assert.assertEquals(firstname, "James",
                "FAILED: firstname did not update correctly (PUT did not replace the resource)");
        Assert.assertEquals(lastname, "Brown",
                "FAILED: lastname did not update correctly");
        Assert.assertEquals(totalPrice, Integer.valueOf(200),
                "FAILED: totalprice did not update correctly");
        Assert.assertEquals(depositPaid, Boolean.FALSE,
                "FAILED: depositpaid did not update correctly");
        Assert.assertEquals(checkin, "2024-02-01",
                "FAILED: checkin did not update correctly");
        Assert.assertEquals(checkout, "2024-02-10",
                "FAILED: checkout did not update correctly");
        Assert.assertEquals(additional, "Lunch",
                "FAILED: additionalneeds did not update correctly");

        System.out.println("[TEST PASSED] Booking " + bookingId
                + " updated successfully via PUT.\n");
    }

    /**
     * Bonus - same scenario expressed using REST Assured's fluent
     * then().body() Hamcrest assertions for a more compact idiom.
     */
    @Test(priority = 2,
          description = "PUT /booking/{id} - fluent then().body() style assertions")
    public void updateBookingWithFluentStyle() {

        System.out.println("\n[TEST START] updateBookingWithFluentStyle");

        RestAssured
                .given()
                    .auth().preemptive().basic(USERNAME, PASSWORD)
                    .header("Content-Type", "application/json")
                    .pathParam("id", bookingId)
                    .body(UPDATED_BODY)
                .when()
                    .put(BOOKING_ENDPOINT + "/{id}")
                .then()
                    .assertThat()
                    .statusCode(200)
                    .contentType(org.hamcrest.Matchers.containsString("json"))
                    .body("firstname",        org.hamcrest.Matchers.equalTo("James"))
                    .body("lastname",         org.hamcrest.Matchers.equalTo("Brown"))
                    .body("totalprice",       org.hamcrest.Matchers.equalTo(200))
                    .body("depositpaid",      org.hamcrest.Matchers.equalTo(false))
                    .body("additionalneeds",  org.hamcrest.Matchers.equalTo("Lunch"));

        System.out.println("[TEST PASSED] Fluent style PUT assertions succeeded.\n");
    }

    /**
     * Bonus - PUT requires authentication. Calling PUT WITHOUT credentials
     * should return 403 Forbidden. This documents the contract and proves
     * the auth header is actually being checked by the server.
     */
    @Test(priority = 3,
          description = "PUT /booking/{id} without auth - expect 403 Forbidden")
    public void putWithoutAuthIsForbidden() {

        System.out.println("\n[TEST START] putWithoutAuthIsForbidden");

        int statusCode = RestAssured
                .given()
                    // intentionally NO auth
                    .header("Content-Type", "application/json")
                    .pathParam("id", bookingId)
                    .body(UPDATED_BODY)
                .when()
                    .put(BOOKING_ENDPOINT + "/{id}")
                .then()
                    .extract()
                    .statusCode();

        System.out.println("Status code (no auth) : " + statusCode);

        Assert.assertEquals(statusCode, 403,
                "FAILED: expected 403 Forbidden when no auth header is sent, got " + statusCode);

        System.out.println("[TEST PASSED] PUT correctly rejected without auth.\n");
    }
}
