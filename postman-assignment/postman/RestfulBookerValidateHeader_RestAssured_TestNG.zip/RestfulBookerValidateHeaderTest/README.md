# Validate a Header in REST Assured + TestNG

Maven-based Java project that automates the **"Validating a header in REST
Assured"** scenario. It sends a POST request to Restful Booker's `/booking`
endpoint and validates the value of a specific response header using
REST Assured's **`header(String headerName, Matcher<?> matcher)`** method.

## Scenario

1. Send a **POST** to `https://restful-booker.herokuapp.com/booking` with
   the given booking body.
2. Validate a specific response header using `.header(name, matcher)`
   with a Hamcrest matcher.
3. Print the response to the console.

```json
{
    "firstname": "Jim",
    "lastname": "Brown",
    "totalprice": 111,
    "depositpaid": true,
    "bookingdates": {
        "checkin":  "2018-01-01",
        "checkout": "2019-01-01"
    },
    "additionalneeds": "Breakfast"
}
```

## What is REST Assured's `.header(String, Matcher)` Method?

The `ValidatableResponse` interface (the type returned by `.then()`) exposes:

```java
ValidatableResponse header(String headerName, Matcher<?> matcher);
```

This validates a **single header in-chain** using a Hamcrest matcher.
The assertion happens immediately - if the header value does not satisfy
the matcher, REST Assured throws an `AssertionError` with a clear message.

```java
.then()
    .header("Content-Type", containsString("json"))
    .header("Server",       equalTo("Cowboy"))
    .header("X-Frame-Options", notNullValue());
```

There is also a **literal-value overload** for exact equality:

```java
ValidatableResponse header(String headerName, String expectedValue);

// Used as:
.then().header("Content-Type", "application/json; charset=utf-8");
```

The matcher form is more flexible and is the focus of this assignment.

## Hands-On 5 vs Hands-On 7 - The Two Single-Header Methods

| Aspect                  | Hands-On 5 (extract single)        | Hands-On 7 (validate single) - this |
|-------------------------|------------------------------------|-------------------------------------|
| Method                  | `Response.header(String name)`     | `ValidatableResponse.header(String name, Matcher matcher)` |
| Where it lives          | On the extracted `Response`        | Inside the fluent `.then()` chain   |
| Returns                 | `String` (the value)               | `ValidatableResponse` (chain continues) |
| What it does            | Read the value                     | Read AND assert against a matcher   |
| Use when                | You need the value for further work | You only need to validate           |

## Common Hamcrest Matchers for Header Validation

| Matcher                                          | Example                                          |
|--------------------------------------------------|--------------------------------------------------|
| `equalTo(value)`                                 | `.header("Content-Type", equalTo("application/json"))` |
| `is(value)`                                      | `.header("Server", is("Cowboy"))`                |
| `containsString(substr)`                         | `.header("Content-Type", containsString("json"))` |
| `startsWith(prefix)`                             | `.header("Content-Type", startsWith("application/"))` |
| `endsWith(suffix)`                               | `.header("Content-Type", endsWith("utf-8"))`     |
| `notNullValue()` / `nullValue()`                 | `.header("Server", notNullValue())`              |
| `not(otherMatcher)`                              | `.header("X-Foo", not(equalTo("bar")))`           |
| `anyOf(m1, m2, ...)`                             | `.header("Content-Type", anyOf(containsString("json"), containsString("xml")))` |

## Project Structure

```
RestfulBookerValidateHeaderTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── ValidateHeaderTest.java
```

## What the Test Class Does

| # | Method                                   | Purpose                                                                       |
|---|------------------------------------------|-------------------------------------------------------------------------------|
| 1 | `validateHeaderWithMatcher`              | Main: `.then().header("Content-Type", containsString("json"))` + print response. |
| 2 | `validateMultipleHeadersInOneChain`      | Bonus - 5 chained header validations on the same response.                    |
| 3 | `validateHeaderWithLiteralValue`         | Bonus - the literal-value overload `.header(name, "exact value")`.            |
| 4 | `validateHeaderUsingExtractedResponse`   | Bonus - extract + `MatcherAssert.assertThat` (alternative pattern).            |
| 5 | `validateHeaderWithVariousMatchers`      | Bonus - 5 matcher flavours on the same Content-Type header.                   |

## Key REST Assured Patterns

```java
// 1. The canonical idiom (this assignment's specific ask)
.then().header("Content-Type", containsString("json"));

// 2. Multiple header validations chained
.then()
    .statusCode(200)
    .header("Content-Type", containsString("json"))
    .header("Server",       notNullValue())
    .header("Content-Length", notNullValue());

// 3. Literal-value overload (uses equalTo internally)
.then().header("Content-Type", "application/json; charset=utf-8");

// 4. Extract + external assertion (alternative pattern)
Response r = ...post().then().extract().response();
String ct = r.header("Content-Type");
MatcherAssert.assertThat(ct, containsString("json"));

// 5. Various matcher styles on the same header
.then()
    .header("Content-Type", is(notNullValue()))
    .header("Content-Type", containsString("json"))
    .header("Content-Type", startsWith("application/"))
    .header("Content-Type", endsWith("utf-8"))
    .header("Content-Type", equalTo("application/json; charset=utf-8"));
```

## Postman → REST Assured Mapping

| Postman step                                   | REST Assured equivalent                              |
|------------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection          | Maven project + test class                           |
| Add a new request, set POST + URL + body       | `given().body(...).when().post(...)`                 |
| In Tests tab: `pm.response.to.have.header(...)` | `.then().header(name, matcher)`                      |
| Custom header value check via `pm.expect`      | `.then().header(name, matcher)` with Hamcrest         |

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- **Hamcrest `2.2`** - the matcher library used by `.header(name, matcher)`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=ValidateHeaderTest#validateHeaderWithMatcher
```

## Expected Output (abridged)

```
[TEST START] validateHeaderWithMatcher
Request URL    : https://restful-booker.herokuapp.com/booking
Status code    : 200
Status line    : HTTP/1.1 200 OK
Validated header (Content-Type contains 'json') : application/json; charset=utf-8

--- Pretty-printed response body ---
{
    "bookingid": 4271,
    "booking": {
        "firstname": "Jim",
        "lastname": "Brown",
        "totalprice": 111,
        "depositpaid": true,
        "bookingdates": {
            "checkin":  "2018-01-01",
            "checkout": "2019-01-01"
        },
        "additionalneeds": "Breakfast"
    }
}
[TEST PASSED] Content-Type validated via .header(name, matcher).

[TEST START] validateMultipleHeadersInOneChain
Validated 5 header expectations in one chain via .header(name, matcher).
[TEST PASSED] All header matchers succeeded.

[TEST START] validateHeaderWithVariousMatchers
Validated Content-Type with 5 different matcher styles.
[TEST PASSED] Various matcher styles succeeded.

===============================================
Total tests run: 5, Passes: 5, Failures: 0
===============================================
```

## Notes

- POST /booking on Restful Booker returns **200 OK**, not 201 Created.
- Header names are **case-insensitive** per HTTP RFC, and REST Assured
  follows that rule.
- This pairs naturally with Hands-On 5 (extract a single header) and
  Hands-On 6 (extract all headers). Together they cover the three main
  REST Assured idioms for header handling:
    - **Hands-On 5**: `Response.header(name)` to **read**.
    - **Hands-On 6**: `Response.headers()` to **read all**.
    - **Hands-On 7**: `.then().header(name, matcher)` to **validate**.
- If the network is unavailable, all tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
