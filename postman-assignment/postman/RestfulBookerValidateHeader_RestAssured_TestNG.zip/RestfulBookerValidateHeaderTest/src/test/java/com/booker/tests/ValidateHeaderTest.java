package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.hamcrest.MatcherAssert;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.endsWith;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.startsWith;

/**
 * Hands-On 7: Validating a header in REST Assured.
 *
 * Scenario:
 *   Method   : POST
 *   URL      : https://restful-booker.herokuapp.com/booking
 *   Auth     : none
 *   Body     : { firstname, lastname, totalprice, depositpaid,
 *                bookingdates: { checkin, checkout },
 *                additionalneeds }
 *   Goal     : Validate the value of a specific response header using
 *              REST Assured's header(String headerName, Matcher<?> matcher).
 *
 * Steps covered:
 *  1. POST /booking sent through REST Assured with the given body.
 *  2. Specific header validated via .header(name, matcher) using a
 *     Hamcrest matcher.
 *  3. Response printed to the console for visibility.
 *
 * About REST Assured's header(String, Matcher) method:
 *
 *   The ValidatableResponse interface (returned by .then()) exposes:
 *
 *      ValidatableResponse header(String headerName, Matcher<?> matcher);
 *
 *   This validates a single header in-chain using a Hamcrest matcher:
 *
 *      .then()
 *          .header("Content-Type", containsString("json"))
 *          .header("Server",       equalTo("Cowboy"));
 *
 *   The assertion happens immediately - if the header value does not
 *   match, REST Assured throws an AssertionError with a clear message.
 *   No extract() or external Assert call is needed.
 *
 *   It also has a literal-value overload:
 *       .header(String name, String expectedValue)
 *   ...but the matcher form (this assignment's focus) is more flexible.
 *
 * About the API:
 *   POST /booking on Restful Booker returns 200 OK with typical headers:
 *      Content-Type     : application/json; charset=utf-8
 *      Server           : Cowboy
 *      Connection       : keep-alive
 *      Date             : <timestamp>
 *      X-Powered-By     : Express
 *      Content-Length   : <number>
 */
public class ValidateHeaderTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    /** Step 1 - The exact request body specified in the assignment. */
    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Steps 2-3 - Validate a specific header using the
     * header(String headerName, Matcher<?> matcher) method, then print
     * the response to the console.
     */
    @Test(priority = 1,
          description = "POST /booking - validate Content-Type via .header(name, matcher) and print response")
    public void validateHeaderWithMatcher() {

        System.out.println("\n[TEST START] validateHeaderWithMatcher");

        // Step 1 - Send the POST and validate the Content-Type header
        // in-chain. .extract().response() at the end gives us the response
        // for printing afterwards (Step 3).
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    // Step 2 - validate header using header(name, matcher)
                    .header("Content-Type", containsString("json"))
                    .extract()
                    .response();

        // Step 3 - Print the response for console visibility
        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Status code    : " + response.getStatusCode());
        System.out.println("Status line    : " + response.getStatusLine());
        System.out.println("Validated header (Content-Type contains 'json') : "
                + response.header("Content-Type"));

        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        System.out.println("[TEST PASSED] Content-Type validated via .header(name, matcher).\n");
    }

    /**
     * Bonus - validate MULTIPLE headers in one chain. .header(name, matcher)
     * can be repeated as many times as needed; each call adds one more
     * expectation. This is the most common production pattern.
     */
    @Test(priority = 2,
          description = "POST /booking - validate multiple headers in a single chain")
    public void validateMultipleHeadersInOneChain() {

        System.out.println("\n[TEST START] validateMultipleHeadersInOneChain");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(200)
                    // Multiple header validations chained:
                    .header("Content-Type",   containsString("json"))     // substring
                    .header("Content-Type",   containsString("charset"))  // 2nd check on same header
                    .header("Content-Type",   startsWith("application/")) // anchored match
                    .header("Server",         notNullValue())             // existence check
                    .header("Content-Length", notNullValue());            // length present

        System.out.println("Validated 5 header expectations in one chain via .header(name, matcher).");
        System.out.println("[TEST PASSED] All header matchers succeeded.\n");
    }

    /**
     * Bonus - the literal-value overload .header(name, expectedValue) is a
     * convenience that internally builds an equalTo() matcher. Useful when
     * an exact match is required.
     */
    @Test(priority = 3,
          description = "POST /booking - .header(name, literalValue) is shorthand for equalTo")
    public void validateHeaderWithLiteralValue() {

        System.out.println("\n[TEST START] validateHeaderWithLiteralValue");

        // .header(name, value) overload uses equalTo() under the hood.
        // The literal value below should match exactly what the server sends.
        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .header("Content-Type", "application/json; charset=utf-8");

        System.out.println("Verified Content-Type is exactly 'application/json; charset=utf-8'.");
        System.out.println("[TEST PASSED] Literal-value header validation succeeded.\n");
    }

    /**
     * Bonus - the alternative pattern where the response is extracted first,
     * then the header is validated externally with a Hamcrest assertion
     * library. This is what the assignment's wording "Extract the response
     * AND Validate" most literally describes.
     */
    @Test(priority = 4,
          description = "POST /booking - extract response, then validate header via MatcherAssert.assertThat")
    public void validateHeaderUsingExtractedResponse() {

        System.out.println("\n[TEST START] validateHeaderUsingExtractedResponse");

        // 1. Extract the response
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .extract()
                    .response();

        // 2. Validate the header value externally using Hamcrest's
        //    MatcherAssert. This is the alternative to in-chain .header(...).
        String contentType = response.header("Content-Type");
        System.out.println("Extracted Content-Type : " + contentType);

        MatcherAssert.assertThat(
                "Content-Type should mention json",
                contentType,
                containsString("json"));

        MatcherAssert.assertThat(
                "Content-Type should start with application/",
                contentType,
                startsWith("application/"));

        MatcherAssert.assertThat(
                "Content-Type should not be null",
                contentType,
                notNullValue());

        // 3. Print response for visibility
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        System.out.println("[TEST PASSED] Extracted response, validated header with MatcherAssert.\n");
    }

    /**
     * Bonus - a tour of useful matcher styles for header validation.
     * Demonstrates how the same header can be checked many different ways
     * depending on what the test cares about.
     */
    @Test(priority = 5,
          description = "POST /booking - showcase various Hamcrest matcher styles for header validation")
    public void validateHeaderWithVariousMatchers() {

        System.out.println("\n[TEST START] validateHeaderWithVariousMatchers");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(200)
                    // Various matcher flavours, all on the SAME Content-Type header:
                    .header("Content-Type", is(notNullValue()))                        // existence
                    .header("Content-Type", containsString("json"))                    // substring
                    .header("Content-Type", startsWith("application/"))                // prefix
                    .header("Content-Type", endsWith("utf-8"))                         // suffix
                    .header("Content-Type", equalTo("application/json; charset=utf-8"));// exact

        System.out.println("Validated Content-Type with 5 different matcher styles.");
        System.out.println("[TEST PASSED] Various matcher styles succeeded.\n");
    }
}
