# Validate Multiple Headers in REST Assured + TestNG

Maven-based Java project that automates the **"Validating multiple headers
in REST Assured"** scenario. It sends a POST request to Restful Booker's
`/booking` endpoint and validates **multiple response headers in a SINGLE
call** using REST Assured's variadic **`.headers(...)`** method.

## Scenario

1. Send a **POST** to `https://restful-booker.herokuapp.com/booking` with
   the given booking body.
2. Validate multiple response headers at once using the variadic
   `.headers(name, matcher, ...)` method.
3. Print the response to the console.

```json
{
    "firstname": "Jim",
    "lastname": "Brown",
    "totalprice": 111,
    "depositpaid": true,
    "bookingdates": {
        "checkin":  "2018-01-01",
        "checkout": "2019-01-01"
    },
    "additionalneeds": "Breakfast"
}
```

## What is REST Assured's `.headers(...)` Method?

The `ValidatableResponse` interface (returned by `.then()`) exposes a
**variadic** form for validating multiple headers in a single call:

```java
ValidatableResponse headers(
    String firstHeaderName,
    Matcher<?> firstMatcher,
    Object... additionalHeaderNameMatcherPairs);
```

The arguments come in interleaved **name/matcher pairs**:

```java
.then().headers(
    "Content-Type",   containsString("json"),
    "Server",         equalTo("Cowboy"),
    "Content-Length", notNullValue());
```

There is also a **Map overload**:

```java
ValidatableResponse headers(Map<String, ?> expectedHeaders);
```

Both forms validate every pair against the response and throw an
`AssertionError` if any expectation fails.

## Hands-On 7 vs Hands-On 8 - The Two Validation Methods

| Aspect           | Hands-On 7 (`header`)                     | Hands-On 8 (`headers`) - this        |
|------------------|--------------------------------------------|--------------------------------------|
| Method           | `.header(name, matcher)`                  | `.headers(name1, m1, name2, m2, ...)` |
| Validates        | ONE header per call                       | MULTIPLE headers per call            |
| Use when         | Just one header check                     | Several header checks at once        |
| Compactness      | Verbose for many headers                  | Compact for many headers             |
| Repeat same name | Fine - chain `.header(name, m1)` twice    | Variadic OK; Map cannot              |

Both produce identical results for the same set of expectations - the
choice is stylistic (compactness vs readability).

## Three Forms of `.headers(...)`

```java
// Form 1 - Variadic with all Matchers
.then().headers(
    "Content-Type",   containsString("json"),
    "Server",         notNullValue(),
    "Content-Length", notNullValue());

// Form 2 - Variadic with a mix of literal Strings and Matchers
.then().headers(
    "Content-Type",   "application/json; charset=utf-8",  // literal -> equalTo internally
    "Server",         notNullValue(),                      // Matcher
    "Content-Length", notNullValue());                     // Matcher

// Form 3 - Map overload
Map<String, Object> expected = new LinkedHashMap<>();
expected.put("Content-Type",   containsString("json"));
expected.put("Server",         notNullValue());
expected.put("Content-Length", notNullValue());
.then().headers(expected);
```

## When the Map Form Has a Limitation

A `Map<String, ?>` can hold **only one entry per key**. If you need to
validate the same header against **multiple expectations** (e.g.
"contains json AND starts with application/"), the Map form will overwrite
the first entry. Use the variadic form (or chained `.header(...)` calls)
instead:

```java
// Variadic form - both expectations on Content-Type are kept
.then().headers(
    "Content-Type", containsString("json"),
    "Content-Type", startsWith("application/"));

// Map form - the second put() OVERWRITES the first; only the second
// expectation runs
Map<String, Object> m = new HashMap<>();
m.put("Content-Type", containsString("json"));
m.put("Content-Type", startsWith("application/"));   // overrides
```

## Project Structure

```
RestfulBookerValidateMultipleHeadersTest/
├── pom.xml                              # Maven dependencies
├── testng.xml                           # TestNG suite file
├── README.md
└── src/test/java/com/booker/tests/
    └── ValidateMultipleHeadersTest.java
```

## What the Test Class Does

| # | Method                                              | Purpose                                                                |
|---|-----------------------------------------------------|------------------------------------------------------------------------|
| 1 | `validateMultipleHeadersWithVariadicMethod`         | Main: 4 headers in a single `.headers(name, matcher, ...)` call.        |
| 2 | `validateMultipleHeadersUsingMap`                   | Bonus - the `Map<String, Object>` overload of `.headers(...)`.          |
| 3 | `validateMultipleHeadersWithMixedLiteralsAndMatchers`| Bonus - mix of literal Strings and Matchers in the same call.           |
| 4 | `contrastVariadicVsChainedSingleHeaderCalls`        | Bonus - shows `.headers(...)` and `N x .header(...)` are equivalent.    |
| 5 | `validateMultipleHeadersWithPlainHashMap`           | Bonus - the plain `HashMap` Map form (no insertion order guarantees).   |

## Key REST Assured Patterns

```java
// 1. The canonical idiom (this assignment's specific ask)
.then().headers(
    "Content-Type",   containsString("json"),
    "Server",         notNullValue(),
    "Content-Length", notNullValue());

// 2. Map overload
Map<String, Object> expected = new LinkedHashMap<>();
expected.put("Content-Type", containsString("json"));
expected.put("Server",       notNullValue());
.then().headers(expected);

// 3. Mix of literals and matchers (literals are auto-wrapped in equalTo)
.then().headers(
    "Content-Type",   "application/json; charset=utf-8",
    "Server",         notNullValue());

// 4. Equivalent in chained .header() form
.then()
    .header("Content-Type",   containsString("json"))
    .header("Server",         notNullValue())
    .header("Content-Length", notNullValue());
```

## Postman → REST Assured Mapping

| Postman step                                | REST Assured equivalent                              |
|---------------------------------------------|------------------------------------------------------|
| Open Postman → workspace → collection       | Maven project + test class                           |
| Add a new request, set POST + URL + body    | `given().body(...).when().post(...)`                 |
| In Tests tab: multiple `pm.response.to.have.header()` | `.then().headers(name1, m1, name2, m2, ...)`     |

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- **Hamcrest `2.2`** - the matcher library

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=ValidateMultipleHeadersTest#validateMultipleHeadersWithVariadicMethod
```

## Expected Output (abridged)

```
[TEST START] validateMultipleHeadersWithVariadicMethod
Request URL    : https://restful-booker.herokuapp.com/booking
Status code    : 200
Status line    : HTTP/1.1 200 OK

--- Headers that were validated by .headers(...) ---
  Content-Type   : application/json; charset=utf-8
  Server         : Cowboy
  Content-Length : 168
  Connection     : keep-alive

--- Pretty-printed response body ---
{
    "bookingid": 4271,
    "booking": { ... }
}
[TEST PASSED] 4 headers validated in one .headers(...) call.

[TEST START] validateMultipleHeadersUsingMap
Validated 3 headers via the Map overload.
[TEST PASSED] Map-form .headers(...) succeeded.

[TEST START] contrastVariadicVsChainedSingleHeaderCalls
Form 1: chained .header(name, matcher) - Hands-On 7 style
Form 2: single .headers(name, matcher, ...) - Hands-On 8 style
Both forms validate the same 3 headers identically.
[TEST PASSED] Functional equivalence demonstrated.

===============================================
Total tests run: 5, Passes: 5, Failures: 0
===============================================
```

## The Complete REST Assured Header API (Hands-On 5-8)

| Hands-On | Method                              | Purpose                            |
|----------|-------------------------------------|------------------------------------|
| 5        | `Response.header(name)`             | **Read** a single header           |
| 6        | `Response.headers()`                | **Read all** headers (iterable)    |
| 7        | `.then().header(name, matcher)`     | **Validate** a single header       |
| 8        | `.then().headers(name1, m1, ...)`   | **Validate multiple** headers      |

## Notes

- POST /booking on Restful Booker returns **200 OK**, not 201 Created.
- Header names are **case-insensitive** per HTTP RFC, and REST Assured
  follows that rule.
- The variadic `.headers(...)` accepts both `Matcher<?>` instances and
  literal `String` values for the matcher position. Literals are wrapped
  in `equalTo()` automatically.
- If the network is unavailable, all tests will fail with connection
  errors - this is an infrastructure issue, not a code defect.
