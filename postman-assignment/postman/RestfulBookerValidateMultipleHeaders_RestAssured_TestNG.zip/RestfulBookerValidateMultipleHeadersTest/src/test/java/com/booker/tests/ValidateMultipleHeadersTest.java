package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.notNullValue;
import static org.hamcrest.Matchers.startsWith;

/**
 * Hands-On 8: Validating multiple headers in REST Assured.
 *
 * Scenario:
 *   Method   : POST
 *   URL      : https://restful-booker.herokuapp.com/booking
 *   Auth     : none
 *   Body     : { firstname, lastname, totalprice, depositpaid,
 *                bookingdates: { checkin, checkout },
 *                additionalneeds }
 *   Goal     : Validate MULTIPLE response headers AT ONCE using REST
 *              Assured's variadic headers(...) method.
 *
 * Steps covered:
 *  1. POST /booking sent through REST Assured with the given body.
 *  2. Multiple headers validated in a SINGLE .headers(...) call using
 *     name/matcher pairs.
 *  3. Response printed to the console.
 *
 * About REST Assured's headers(name, matcher, ...) method:
 *
 *   The ValidatableResponse interface (returned by .then()) exposes:
 *
 *     ValidatableResponse headers(
 *         String firstHeaderName,
 *         Matcher<?> firstMatcher,
 *         Object... additionalHeaderNameMatcherPairs);
 *
 *   This validates multiple headers in a SINGLE call using interleaved
 *   name/matcher pairs:
 *
 *     .then().headers(
 *         "Content-Type",   containsString("json"),
 *         "Server",         equalTo("Cowboy"),
 *         "Content-Length", notNullValue());
 *
 *   The varargs come in (String, Matcher) pairs - alternating. There is
 *   also a Map overload:
 *
 *     ValidatableResponse headers(Map<String, ?> expectedHeaders);
 *
 *   Both forms validate every pair against the response and throw an
 *   AssertionError if any expectation fails.
 *
 *   Compare to .header(name, matcher) (Hands-On 7) which validates ONE
 *   header at a time.
 *
 * About the API:
 *   POST /booking on Restful Booker returns 200 OK with typical headers:
 *      Content-Type     : application/json; charset=utf-8
 *      Server           : Cowboy
 *      Connection       : keep-alive
 *      Date             : <timestamp>
 *      X-Powered-By     : Express
 *      Content-Length   : <number>
 */
public class ValidateMultipleHeadersTest {

    private static final String BASE_URI = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT = "/booking";

    /** Step 1 - The exact request body specified in the assignment. */
    private static final String BOOKING_BODY = "{\n"
            + "  \"firstname\":  \"Jim\",\n"
            + "  \"lastname\":   \"Brown\",\n"
            + "  \"totalprice\": 111,\n"
            + "  \"depositpaid\": true,\n"
            + "  \"bookingdates\": {\n"
            + "    \"checkin\":  \"2018-01-01\",\n"
            + "    \"checkout\": \"2019-01-01\"\n"
            + "  },\n"
            + "  \"additionalneeds\": \"Breakfast\"\n"
            + "}";

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Steps 2-3 - Validate MULTIPLE headers in one .headers(...) call,
     * then print the response.
     *
     * The variadic form: .headers(name1, matcher1, name2, matcher2, ...).
     * REST Assured pairs them up internally and validates each.
     */
    @Test(priority = 1,
          description = "POST /booking - validate multiple headers in ONE .headers(...) call + print response")
    public void validateMultipleHeadersWithVariadicMethod() {

        System.out.println("\n[TEST START] validateMultipleHeadersWithVariadicMethod");

        // Step 1 - Send the POST and validate ALL these headers in ONE call.
        // .extract().response() gives us the response for printing afterwards.
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .header("Accept",       "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    // Step 2 - validate FOUR headers in a SINGLE .headers(...)
                    .headers(
                        "Content-Type",   containsString("json"),
                        "Server",         notNullValue(),
                        "Content-Length", notNullValue(),
                        "Connection",     notNullValue())
                    .extract()
                    .response();

        // Step 3 - Print the response for console visibility
        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Status code    : " + response.getStatusCode());
        System.out.println("Status line    : " + response.getStatusLine());

        System.out.println("\n--- Headers that were validated by .headers(...) ---");
        System.out.println("  Content-Type   : " + response.header("Content-Type"));
        System.out.println("  Server         : " + response.header("Server"));
        System.out.println("  Content-Length : " + response.header("Content-Length"));
        System.out.println("  Connection     : " + response.header("Connection"));

        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        System.out.println("[TEST PASSED] 4 headers validated in one .headers(...) call.\n");
    }

    /**
     * Bonus - the Map overload of .headers(...). Sometimes preferred when
     * the expected headers are built dynamically (e.g. from a config file
     * or test data provider).
     */
    @Test(priority = 2,
          description = "POST /booking - validate multiple headers using the Map overload of .headers(...)")
    public void validateMultipleHeadersUsingMap() {

        System.out.println("\n[TEST START] validateMultipleHeadersUsingMap");

        // Build a map of expected name -> matcher.
        // LinkedHashMap preserves insertion order, useful for clear logs
        // when an assertion fails.
        Map<String, Object> expected = new LinkedHashMap<>();
        expected.put("Content-Type",   containsString("json"));
        expected.put("Content-Type",   startsWith("application/"));   // overrides previous!
        expected.put("Server",         notNullValue());
        expected.put("Content-Length", notNullValue());

        // Note: a Map can only hold ONE matcher per header name. If you
        // need multiple expectations on the same header, use the variadic
        // form instead (or chain multiple .header(name, matcher) calls).

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    .headers(expected);                    // Map overload

        System.out.println("Validated " + expected.size() + " headers via the Map overload.");
        System.out.println("[TEST PASSED] Map-form .headers(...) succeeded.\n");
    }

    /**
     * Bonus - same scenario but the matcher value in the variadic call is
     * a literal String instead of a Matcher. The variadic .headers(...)
     * method accepts BOTH literal Strings and Matcher instances as the
     * "value" position; literals are wrapped in equalTo() automatically.
     */
    @Test(priority = 3,
          description = "POST /booking - .headers(...) supports literal String values as well as Matchers")
    public void validateMultipleHeadersWithMixedLiteralsAndMatchers() {

        System.out.println("\n[TEST START] validateMultipleHeadersWithMixedLiteralsAndMatchers");

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .statusCode(200)
                    // Mix of Matcher and literal-String "values":
                    .headers(
                        "Content-Type",   "application/json; charset=utf-8",  // literal String -> equalTo
                        "Server",         notNullValue(),                      // Matcher
                        "Content-Length", notNullValue());                     // Matcher

        System.out.println("Validated headers using a mix of literal Strings and Matchers.");
        System.out.println("[TEST PASSED] Mixed-form .headers(...) succeeded.\n");
    }

    /**
     * Bonus - contrast .headers(...) (this assignment) with .header(...)
     * chained N times (Hands-On 7). Both produce identical results; the
     * variadic form is more compact when you have multiple checks.
     */
    @Test(priority = 4,
          description = "POST /booking - contrast .headers(...) vs N x .header(...)")
    public void contrastVariadicVsChainedSingleHeaderCalls() {

        System.out.println("\n[TEST START] contrastVariadicVsChainedSingleHeaderCalls");

        // Form 1 - chained .header(name, matcher) calls (Hands-On 7 style)
        System.out.println("Form 1: chained .header(name, matcher) - Hands-On 7 style");
        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .header("Content-Type",   containsString("json"))
                    .header("Server",         notNullValue())
                    .header("Content-Length", notNullValue());

        // Form 2 - single .headers(name, matcher, ...) call (this assignment)
        System.out.println("Form 2: single .headers(name, matcher, ...) - Hands-On 8 style");
        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .headers(
                        "Content-Type",   containsString("json"),
                        "Server",         notNullValue(),
                        "Content-Length", notNullValue());

        System.out.println("Both forms validate the same 3 headers identically.");
        System.out.println(".headers(...) is more compact; .header(...) reads better one-by-one.");
        System.out.println("[TEST PASSED] Functional equivalence demonstrated.\n");
    }

    /**
     * Bonus - the plain Map (not LinkedHashMap) form. The order of
     * validation may not be insertion-order, but the assertion outcome
     * is the same.
     */
    @Test(priority = 5,
          description = "POST /booking - .headers(Map) with plain HashMap")
    public void validateMultipleHeadersWithPlainHashMap() {

        System.out.println("\n[TEST START] validateMultipleHeadersWithPlainHashMap");

        Map<String, Object> expected = new HashMap<>();
        expected.put("Content-Type", containsString("json"));
        expected.put("Server",       notNullValue());

        RestAssured
                .given()
                    .header("Content-Type", "application/json")
                    .body(BOOKING_BODY)
                .when()
                    .post(ENDPOINT)
                .then()
                    .headers(expected);

        System.out.println("[TEST PASSED] Plain HashMap form .headers(...) succeeded.\n");
    }
}
