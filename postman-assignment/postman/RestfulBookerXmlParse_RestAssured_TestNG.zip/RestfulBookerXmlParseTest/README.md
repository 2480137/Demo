# Restful Booker XML Parse - REST Assured + TestNG

Maven-based Java project that uses **REST Assured** and **TestNG** to call the
`GET /booking/:id` endpoint of the public Restful Booker API with
`Accept: application/xml`, retrieve the XML body, parse it, and print the
values to the console.

## Scenario

Send a **GET** request to:

```
https://restful-booker.herokuapp.com/booking/119
```

with both `Content-Type` and `Accept` set to **application/xml**, then parse
the XML response using REST Assured's `XmlPath` and print every field value.

## About the Response

When the request includes `Accept: application/xml`, Restful Booker returns
an XML payload such as:

```xml
<booking>
    <firstname>John</firstname>
    <lastname>Smith</lastname>
    <totalprice>111</totalprice>
    <depositpaid>true</depositpaid>
    <bookingdates>
        <checkin>2018-01-01</checkin>
        <checkout>2019-01-01</checkout>
    </bookingdates>
    <additionalneeds>Breakfast</additionalneeds>
</booking>
```

REST Assured exposes this through `XmlPath` (parallel to `JsonPath` for JSON):

```java
XmlPath xmlPath = response.xmlPath();

String  firstname   = xmlPath.getString("booking.firstname");
Integer totalprice  = xmlPath.getInt   ("booking.totalprice");
Boolean depositpaid = xmlPath.getBoolean("booking.depositpaid");
String  checkin     = xmlPath.getString("booking.bookingdates.checkin");
```

## Important - Booking id 119

Restful Booker resets its data **every 10 minutes**, so the assignment-specified
id **119** may not exist when the test runs. The test method first probes id
119; if it returns 404, it transparently falls back to the first available
booking id (logged to the console). Either way, the XML parsing demonstration
runs end-to-end.

## Project Structure

```
RestfulBookerXmlParseTest/
├── pom.xml                          # Maven dependencies (incl. xml-path)
├── testng.xml                       # TestNG suite file
├── README.md
└── src/
    └── test/
        └── java/
            └── com/
                └── booker/
                    └── tests/
                        └── RestfulBookerXmlParseTest.java
```

## What the Test Class Does

The `RestfulBookerXmlParseTest` class contains three test methods:

| # | Method                              | Purpose                                                                          |
|---|-------------------------------------|----------------------------------------------------------------------------------|
| 1 | `getBookingAsXmlAndPrintValues`     | Main: GETs /booking/{id} as XML, parses with `XmlPath`, prints every field.      |
| 2 | `verifyXmlValuesWithFluentStyle`    | Bonus - same checks expressed with REST Assured's fluent `then().body()` style.  |
| 3 | `iterateXmlChildrenDynamically`     | Bonus - dynamically lists every child of `<booking>` and prints each one.        |

## Key REST Assured Patterns Used

```java
// 1. Send GET with XML Accept header
Response response = given()
        .header("Content-Type", "application/xml")
        .header("Accept", "application/xml")
        .when().get("/booking/" + bookingId)
        .then().extract().response();

// 2. Parse to XML
XmlPath xmlPath = response.xmlPath();

// 3. Extract simple values
String firstname  = xmlPath.getString("booking.firstname");

// 4. Extract typed values
Integer totalprice  = xmlPath.getInt    ("booking.totalprice");
Boolean depositpaid = xmlPath.getBoolean("booking.depositpaid");

// 5. Extract nested values (dotted path)
String checkin = xmlPath.getString("booking.bookingdates.checkin");

// 6. Iterate children dynamically
List<String> kids = xmlPath.getList("booking.children().list().name()");
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- **XML Path `5.3.2`** (the parser used for the XML response)
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open the project as a Maven project (select `pom.xml`), wait for dependencies
to download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=RestfulBookerXmlParseTest#getBookingAsXmlAndPrintValues
```

## Expected Output (abridged)

```
[TEST START] getBookingAsXmlAndPrintValues
Booking id 119 returned status 404 - falling back to the first available booking id.
Fallback booking id selected: 1
Using booking id: 1
Status code    : 200
Content-Type   : application/xml; charset=utf-8

--- Raw XML response body ---
<booking>
    <firstname>John</firstname>
    <lastname>Smith</lastname>
    <totalprice>111</totalprice>
    <depositpaid>true</depositpaid>
    <bookingdates>
        <checkin>2018-01-01</checkin>
        <checkout>2019-01-01</checkout>
    </bookingdates>
    <additionalneeds>Breakfast</additionalneeds>
</booking>

--- Field-by-field values from parsed XML ---
firstname        : John
lastname         : Smith
totalprice (raw) : 111   (typed int    -> 111)
depositpaid (raw): true  (typed boolean -> true)
bookingdates.checkin  : 2018-01-01
bookingdates.checkout : 2019-01-01
additionalneeds  : Breakfast
[TEST PASSED] XML response parsed and printed successfully.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- Restful Booker resets booking ids every 10 minutes - the live id pool
  is small and constantly changes. The test transparently falls back to a
  live id when the assignment-specific id has been wiped.
- No authentication is required for the GET endpoint used here.
- Some bookings on the server do not include the `<additionalneeds>`
  element at all - in that case the parsed value will be empty, which the
  bonus child-iteration test handles cleanly.
