package com.booker.tests;

import io.restassured.RestAssured;
import io.restassured.path.xml.XmlPath;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

/**
 * Hands-On 7: Get the API response in XML in REST Assured.
 *
 * Scenario:
 *  Send a GET request to https://restful-booker.herokuapp.com/booking/119
 *  with Content-Type and Accept set to application/xml, retrieve the XML
 *  response body, parse it, and print the values.
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. GET request sent through RestAssured to /booking/{id} with id = 119.
 *  4. Content-Type and Accept set to application/xml.
 *  5. Response values printed to the console.
 *
 * About the response:
 *  When Accept is application/xml, Restful Booker returns XML such as:
 *
 *      <booking>
 *          <firstname>John</firstname>
 *          <lastname>Smith</lastname>
 *          <totalprice>111</totalprice>
 *          <depositpaid>true</depositpaid>
 *          <bookingdates>
 *              <checkin>2018-01-01</checkin>
 *              <checkout>2019-01-01</checkout>
 *          </bookingdates>
 *          <additionalneeds>Breakfast</additionalneeds>
 *      </booking>
 *
 *  REST Assured exposes XmlPath (parallel to JsonPath) for navigating it.
 *
 * Important - bookingid resolution:
 *  Restful Booker resets its data every 10 minutes, so the hardcoded
 *  id 119 may not exist when the test runs. The test method first tries
 *  id 119 as the assignment specifies; if it returns 404, the test falls
 *  back to the first available bookingid so the XML parsing demonstration
 *  still runs end-to-end. The fallback is logged clearly to the console.
 */
public class RestfulBookerXmlParseTest {

    private static final String BASE_URI    = "https://restful-booker.herokuapp.com";
    private static final String ENDPOINT    = "/booking";
    private static final int    ASSIGNMENT_ID = 119;

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI once for the whole class
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 3 + 4 + 5 - Send GET with XML headers, retrieve the XML body,
     * parse it, and print the values.
     */
    @Test(priority = 1,
          description = "GET /booking/119 with Accept application/xml - parse and print XML values")
    public void getBookingAsXmlAndPrintValues() {

        System.out.println("\n[TEST START] getBookingAsXmlAndPrintValues");

        // Decide which id to actually use - try 119 first, fall back if missing
        int bookingId = resolveBookingId(ASSIGNMENT_ID);
        System.out.println("Using booking id: " + bookingId);

        // Step 3 + 4 - Send GET with application/xml headers
        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/xml")
                    .header("Accept", "application/xml")
                .when()
                    .get(ENDPOINT + "/" + bookingId)
                .then()
                    .extract()
                    .response();

        int statusCode = response.getStatusCode();
        String contentType = response.getContentType();

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT + "/" + bookingId);
        System.out.println("Status code    : " + statusCode);
        System.out.println("Content-Type   : " + contentType);
        System.out.println("Response time  : " + response.getTime() + " ms");

        // Status must be 200 - we have already verified the id exists
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK but got " + statusCode);

        // Confirm the server actually replied with XML
        Assert.assertNotNull(contentType,
                "FAILED: response Content-Type was null");
        Assert.assertTrue(contentType.toLowerCase().contains("xml"),
                "FAILED: expected an XML response, got Content-Type: " + contentType);

        // Step 5a - Print the raw XML body
        String rawBody = response.getBody().asString();
        System.out.println("\n--- Raw XML response body ---");
        System.out.println(rawBody);

        // Step 5b - Parse the XML and pull individual values out
        XmlPath xmlPath = response.xmlPath();

        // Field-level extraction (note - paths are rooted at the document element)
        String firstname       = xmlPath.getString("booking.firstname");
        String lastname        = xmlPath.getString("booking.lastname");
        String totalpriceStr   = xmlPath.getString("booking.totalprice");
        String depositpaidStr  = xmlPath.getString("booking.depositpaid");
        String checkin         = xmlPath.getString("booking.bookingdates.checkin");
        String checkout        = xmlPath.getString("booking.bookingdates.checkout");
        String additionalneeds = xmlPath.getString("booking.additionalneeds");

        // Use the typed accessors where useful
        Integer totalprice  = xmlPath.getInt("booking.totalprice");
        Boolean depositpaid = xmlPath.getBoolean("booking.depositpaid");

        System.out.println("\n--- Field-by-field values from parsed XML ---");
        System.out.println("firstname        : " + firstname);
        System.out.println("lastname         : " + lastname);
        System.out.println("totalprice (raw) : " + totalpriceStr
                + "   (typed int    -> " + totalprice + ")");
        System.out.println("depositpaid (raw): " + depositpaidStr
                + "   (typed boolean -> " + depositpaid + ")");
        System.out.println("bookingdates.checkin  : " + checkin);
        System.out.println("bookingdates.checkout : " + checkout);
        System.out.println("additionalneeds  : " + additionalneeds);

        // Sanity assertions on the parsed values
        Assert.assertNotNull(firstname,
                "FAILED: firstname was null - XML may not have parsed correctly");
        Assert.assertNotNull(lastname,
                "FAILED: lastname was null - XML may not have parsed correctly");
        Assert.assertNotNull(totalprice,
                "FAILED: totalprice was null");
        Assert.assertTrue(totalprice >= 0,
                "FAILED: totalprice was negative: " + totalprice);
        Assert.assertNotNull(checkin,
                "FAILED: checkin date was null");
        Assert.assertNotNull(checkout,
                "FAILED: checkout date was null");

        System.out.println("[TEST PASSED] XML response parsed and printed successfully.\n");
    }

    /**
     * Bonus - same scenario using REST Assured's fluent matcher style.
     * Demonstrates the more concise idiom commonly used in real test suites.
     */
    @Test(priority = 2,
          description = "Verify XML response with fluent then().body() Hamcrest matchers")
    public void verifyXmlValuesWithFluentStyle() {

        System.out.println("\n[TEST START] verifyXmlValuesWithFluentStyle");

        int bookingId = resolveBookingId(ASSIGNMENT_ID);
        System.out.println("Using booking id: " + bookingId);

        RestAssured
                .given()
                    .header("Content-Type", "application/xml")
                    .header("Accept", "application/xml")
                .when()
                    .get(ENDPOINT + "/" + bookingId)
                .then()
                    .assertThat()
                    .statusCode(200)
                    .contentType(org.hamcrest.Matchers.containsString("xml"))
                    .body("booking.firstname", org.hamcrest.Matchers.notNullValue())
                    .body("booking.lastname",  org.hamcrest.Matchers.notNullValue());

        System.out.println("[TEST PASSED] Fluent-style XML assertions succeeded.\n");
    }

    /**
     * Bonus - iterate every leaf element under <booking> dynamically using
     * XmlPath. Useful when the XML schema is not known ahead of time.
     */
    @Test(priority = 3,
          description = "Iterate XML children of <booking> dynamically and print each one")
    public void iterateXmlChildrenDynamically() {

        System.out.println("\n[TEST START] iterateXmlChildrenDynamically");

        int bookingId = resolveBookingId(ASSIGNMENT_ID);
        System.out.println("Using booking id: " + bookingId);

        Response response = RestAssured
                .given()
                    .header("Content-Type", "application/xml")
                    .header("Accept", "application/xml")
                .when()
                    .get(ENDPOINT + "/" + bookingId)
                .then()
                    .extract()
                    .response();

        // Pull the names of every direct child of <booking>
        List<String> childNames = response.xmlPath().getList("booking.children().list().name()");
        System.out.println("\n--- Direct children of <booking> ---");
        for (String childName : childNames) {
            // Read the text content of each child as a string for printing
            String value = response.xmlPath().getString("booking." + childName);
            System.out.println("  <" + childName + ">: " + value);
        }

        Assert.assertFalse(childNames.isEmpty(),
                "FAILED: no children found under <booking>");

        System.out.println("[TEST PASSED] XML children iterated and printed.\n");
    }

    // ------------------------------------------------------------------
    // Helper - try the assignment id first; fall back to a live one if the
    // assignment id has been wiped by Restful Booker's 10-minute reset.
    // ------------------------------------------------------------------
    private int resolveBookingId(int preferredId) {

        int probeStatus = RestAssured
                .given()
                    .header("Accept", "application/xml")
                .when()
                    .get(ENDPOINT + "/" + preferredId)
                .then()
                    .extract()
                    .statusCode();

        if (probeStatus == 200) {
            System.out.println("Booking id " + preferredId + " is alive on the server.");
            return preferredId;
        }

        System.out.println("Booking id " + preferredId
                + " returned status " + probeStatus
                + " - falling back to the first available booking id.");

        List<Integer> ids = RestAssured
                .given()
                    .header("Accept", "application/json")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .jsonPath()
                    .getList("bookingid");

        Assert.assertFalse(ids == null || ids.isEmpty(),
                "FAILED: cannot fall back - GET /booking returned no booking ids");

        int fallback = ids.get(0);
        System.out.println("Fallback booking id selected: " + fallback);
        return fallback;
    }
}
