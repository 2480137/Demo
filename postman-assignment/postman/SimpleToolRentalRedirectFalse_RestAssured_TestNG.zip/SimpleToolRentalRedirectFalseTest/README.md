# Redirect False - REST Assured + TestNG

GET https://simple-tool-rental-api.glitch.me/status with redirects disabled.

## Idiom

```java
.given()
    .redirects().follow(false)        // disable redirect following
.when()
    .get("/status")
```

Alternative (config-based):
```java
.given()
    .config(RestAssuredConfig.config()
        .redirect(RedirectConfig.redirectConfig().followRedirects(false)))
```

## Test Methods

| # | Method                                    | Purpose                                           |
|---|-------------------------------------------|---------------------------------------------------|
| 1 | `getStatusWithRedirectsDisabled`          | GET /status with `.redirects().follow(false)`.    |
| 2 | `getStatusWithAltRedirectIdiom`           | Same with config-based idiom.                     |
| 3 | `compareRedirectFollowOnOffAgainst302`    | Hits a known 302 - shows 200 (followed) vs 302 (not followed). |

## Run

```bash
mvn clean test
```
