package com.toolrental.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hands-On 24: Utilize the redirect-false command in REST Assured.
 *
 * URL : GET https://simple-tool-rental-api.glitch.me/status
 *
 * Disable redirect following per-request:
 *     given().redirects().follow(false)...
 *
 * When redirects are followed (default), 3xx responses get auto-followed
 * to their destination, and the test sees only the final 2xx. To validate
 * a 3xx response itself, redirects must be disabled.
 *
 * For /status (which normally returns 200), disabling redirects has no
 * visible effect, but the configuration is exercised. The bonus tests
 * hit the-internet.herokuapp.com/redirect (a known 302) to demonstrate
 * the actual difference.
 */
public class RedirectFalseTest {

    private static final String BASE_URI = "https://simple-tool-rental-api.glitch.me";

    @BeforeClass
    public void setUp() {
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI = " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Steps 2-4: GET /status with redirects disabled, validate, print.
     */
    @Test(priority = 1, description = "GET /status with redirects().follow(false) - validate + print")
    public void getStatusWithRedirectsDisabled() {

        System.out.println("\n[TEST START] getStatusWithRedirectsDisabled");

        Response response = RestAssured
                .given()
                    .redirects().follow(false)              // disable redirect following
                .when()
                    .get("/status")
                .then()
                    .extract().response();

        int sc = response.getStatusCode();
        // Glitch apps cold-start - first request can be slow but should be 200 or 503.
        // Accept 200 as the success case.
        System.out.println("Request URL : " + BASE_URI + "/status");
        System.out.println("Method      : GET (redirects disabled)");
        System.out.println("Status code : " + sc);
        System.out.println("Response time : " + response.getTime() + " ms");
        System.out.println("\n--- Pretty-printed response body ---");
        System.out.println(response.getBody().asPrettyString());

        Assert.assertEquals(sc, 200, "FAILED: expected 200 from /status, got " + sc);

        System.out.println("[TEST PASSED] /status returned 200 with redirects disabled.\n");
    }

    /**
     * Bonus - same call with redirects().follow(false) chained with the
     * full method-chain spelling. Demonstrates the alternate idiom.
     */
    @Test(priority = 2, description = "GET /status - alt idiom: .redirects().follow(false)")
    public void getStatusWithAltRedirectIdiom() {

        System.out.println("\n[TEST START] getStatusWithAltRedirectIdiom");

        int sc = RestAssured
                .given()
                    .config(io.restassured.config.RestAssuredConfig.config()
                            .redirect(io.restassured.config.RedirectConfig
                                    .redirectConfig().followRedirects(false)))
                .when()
                    .get("/status")
                .then()
                    .extract().statusCode();

        System.out.println("Status code : " + sc);
        Assert.assertEquals(sc, 200, "FAILED");
        System.out.println("[TEST PASSED] Alt-idiom redirect-disable succeeded.\n");
    }

    /**
     * Bonus - compare WITH and WITHOUT follow(false) against a known
     * 302 endpoint (the-internet.herokuapp.com/redirect).
     *
     *  - With redirects ON  : final status is 200 (after auto-follow)
     *  - With redirects OFF : status is 302 (the redirect itself)
     */
    @Test(priority = 3, description = "Compare follow(true) vs follow(false) on a known 302 endpoint")
    public void compareRedirectFollowOnOffAgainst302() {

        System.out.println("\n[TEST START] compareRedirectFollowOnOffAgainst302");

        final String redirectUrl = "https://the-internet.herokuapp.com/redirect";

        // 1) follow ON (default) - status will be 200
        int withFollow = RestAssured
                .given()
                    .redirects().follow(true)
                .when()
                    .get(redirectUrl)
                .then()
                    .extract().statusCode();
        System.out.println("redirects().follow(true)  -> status " + withFollow + " (final destination)");

        // 2) follow OFF - status will be 302
        int withoutFollow = RestAssured
                .given()
                    .redirects().follow(false)
                .when()
                    .get(redirectUrl)
                .then()
                    .extract().statusCode();
        System.out.println("redirects().follow(false) -> status " + withoutFollow + " (the redirect itself)");

        Assert.assertEquals(withFollow,    200, "FAILED: with-follow should land on 200");
        Assert.assertEquals(withoutFollow, 302, "FAILED: without-follow should be the 302 itself");

        System.out.println("[TEST PASSED] Difference between follow(true) and follow(false) demonstrated.\n");
    }
}
