# Simple Tool Rental Status - REST Assured + TestNG

Maven-based Java project that automates the **"Send the first API request"**
scenario using **REST Assured** and **TestNG**. The test sends a GET request
to the public Simple Tool Rental status endpoint, asserts the status code is
**200 OK**, and prints the response body to the console.

This is the **REST Assured automated equivalent** of the manual Postman
walkthrough (open Postman → workspace → collection → add request → set GET
method → set URL → click Send).

## Scenario

Send a **GET** request to:

```
https://simple-tool-rental-api.glitch.me/status
```

Verify status code is **200** and inspect the response body.

## Postman → REST Assured Mapping

The original assignment is described as a Postman UI walkthrough. Here is how
each Postman step maps to its REST Assured equivalent in this project:

| Postman step                         | REST Assured equivalent                          |
|--------------------------------------|--------------------------------------------------|
| Open Postman                         | Maven project setup (`pom.xml`, this codebase)   |
| Go to the right workspace            | (workspace concept does not exist in code)       |
| Go to the right collection           | Test class / TestNG suite                        |
| Add a new request                    | New `@Test` method                               |
| Give the request a meaningful name   | Method name + `@Test(description=...)`           |
| Set the method to GET                | `given().when().get(ENDPOINT)`                   |
| Set the URL                          | `RestAssured.baseURI` + endpoint path            |
| Click Send                           | Execution of the `@Test` method                  |
| Verify the response                  | TestNG `Assert.assertEquals(...)`                |

## Project Structure

```
SimpleToolRentalStatusTest/
├── pom.xml                                   # Maven dependencies
├── testng.xml                                # TestNG suite file
├── README.md
└── src/test/java/com/toolrental/tests/
    └── SimpleToolRentalStatusTest.java
```

## What the Test Class Does

The `SimpleToolRentalStatusTest` class contains three test methods:

| # | Method                              | Purpose                                                                       |
|---|-------------------------------------|-------------------------------------------------------------------------------|
| 1 | `sendFirstApiRequest`               | Main: GETs `/status`, prints all response details, asserts 200 OK.            |
| 2 | `verifyStatusUsingFluentStyle`      | Bonus - same 200 assertion in REST Assured's fluent matcher style.            |
| 3 | `verifyResponseTimeIsAcceptable`    | Bonus - asserts the response completes within 5 seconds (cold-start tolerant).|

## Key REST Assured Pattern

```java
// Once at class level
RestAssured.baseURI = "https://simple-tool-rental-api.glitch.me";

// Per-test
Response response = given()
        .header("Accept", "application/json")
    .when()
        .get("/status")
    .then()
        .extract()
        .response();

assertEquals(response.getStatusCode(), 200);
```

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open as a Maven project (select `pom.xml`), wait for dependencies to
download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=SimpleToolRentalStatusTest#sendFirstApiRequest
```

## Expected Output (abridged)

```
[TEST START] sendFirstApiRequest
Request URL    : https://simple-tool-rental-api.glitch.me/status
Status code    : 200
Content-Type   : application/json; charset=utf-8
Response time  : 312 ms
Response size  : 16 chars

--- Response body ---
{"status":"OK"}

--- Pretty-printed JSON ---
{
    "status": "OK"
}

status field   : OK
[TEST PASSED] First API request sent and verified.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Notes

- `simple-tool-rental-api.glitch.me` is a Glitch-hosted demo API used in
  many Postman/QA tutorials. It requires no authentication.
- Glitch's free tier puts idle instances to sleep after a few minutes of
  inactivity. The first request after a cold start can take a few extra
  seconds while the instance wakes up. The bonus response-time test uses a
  generous 5-second threshold to accommodate this.
- The `/status` endpoint typically returns `{"status":"OK"}`. The test
  parses it as JSON when the Content-Type indicates JSON, but is forgiving
  if the response shape evolves - it always prints the raw body and only
  asserts on the status code.
- If the network is unavailable, all tests will fail with connection errors
  - this is an infrastructure issue, not a code defect.
