package com.toolrental.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hands-On 3: Send the first API request - automated with REST Assured.
 *
 * Postman scenario (automated equivalent below):
 *   Method   : GET
 *   URL      : https://simple-tool-rental-api.glitch.me/status
 *   Action   : Click Send and verify the response
 *
 * REST Assured equivalent of each Postman step:
 *   Postman step                              | REST Assured equivalent
 *   ------------------------------------------|---------------------------------------------
 *   Open Postman                              | Maven project setup (this codebase)
 *   Go to the right workspace                 | (workspace concept does not exist in code)
 *   Go to the right collection                | Test class / TestNG suite
 *   Add a new request                         | New @Test method
 *   Give the request a meaningful name        | Method name + @Test description
 *   Set the method to GET                     | given().when().get(...)
 *   Set the URL                               | RestAssured.baseURI + endpoint
 *   Click Send                                | Execution of the @Test method
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. baseURI configured to https://simple-tool-rental-api.glitch.me
 *  4. GET request sent to /status using RestAssured.
 *  5. Status code asserted to be 200 OK.
 *  6. Response body printed to the console.
 */
public class SimpleToolRentalStatusTest {

    private static final String BASE_URI = "https://simple-tool-rental-api.glitch.me";
    private static final String ENDPOINT = "/status";

    @BeforeClass
    public void setUp() {
        // Step 3 - Configure baseURI globally for this class
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Steps 4-6 - Send GET to /status, verify status code, print response.
     */
    @Test(priority = 1,
          description = "GET /status - send the first API request and inspect the response")
    public void sendFirstApiRequest() {

        System.out.println("\n[TEST START] sendFirstApiRequest");

        // Step 4 - Send the GET request through RestAssured.
        // This is the automated equivalent of clicking 'Send' in Postman.
        Response response = RestAssured
                .given()
                    .header("Accept", "application/json")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int    statusCode  = response.getStatusCode();
        String contentType = response.getContentType();
        long   responseTime = response.getTime();
        String body        = response.getBody().asString();

        // Step 6a - Print every piece of information about the response
        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Status code    : " + statusCode);
        System.out.println("Content-Type   : " + contentType);
        System.out.println("Response time  : " + responseTime + " ms");
        System.out.println("Response size  : " + body.length() + " chars");
        System.out.println("\n--- Response body ---");
        System.out.println(body);

        // Step 5 - Verify the status code is 200 OK (the typical 'all healthy'
        // response from a status endpoint)
        Assert.assertEquals(statusCode, 200,
                "FAILED: expected 200 OK but got " + statusCode);

        // Sanity check that we actually received a body
        Assert.assertNotNull(body,
                "FAILED: response body was null");
        Assert.assertFalse(body.trim().isEmpty(),
                "FAILED: response body was empty");

        // Step 6b - If the body is JSON, parse and pretty-print it.
        // The API typically returns something like {"status":"OK"} but the
        // shape may evolve, so we treat JSON parsing as best-effort.
        if (contentType != null && contentType.toLowerCase().contains("json")) {
            try {
                System.out.println("\n--- Pretty-printed JSON ---");
                System.out.println(response.getBody().asPrettyString());

                String statusValue = response.jsonPath().getString("status");
                if (statusValue != null) {
                    System.out.println("\nstatus field   : " + statusValue);
                    Assert.assertFalse(statusValue.isEmpty(),
                            "FAILED: 'status' field was empty");
                }
            } catch (Exception e) {
                System.out.println("(Body did not parse as JSON: " + e.getMessage() + ")");
            }
        }

        System.out.println("[TEST PASSED] First API request sent and verified.\n");
    }

    /**
     * Bonus - same assertion using REST Assured's fluent matcher style.
     * This is the more concise idiom typically used in real test code.
     */
    @Test(priority = 2,
          description = "GET /status - verify 200 using the fluent then().statusCode() style")
    public void verifyStatusUsingFluentStyle() {

        System.out.println("\n[TEST START] verifyStatusUsingFluentStyle");

        RestAssured
                .given()
                .when()
                    .get(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(200);

        System.out.println("[TEST PASSED] Fluent style 200 assertion succeeded.\n");
    }

    /**
     * Bonus - verify that response time is within an acceptable threshold.
     * A simple SLO-style assertion that catches sluggish endpoints.
     */
    @Test(priority = 3,
          description = "GET /status - verify response time is reasonable (< 5 seconds)")
    public void verifyResponseTimeIsAcceptable() {

        System.out.println("\n[TEST START] verifyResponseTimeIsAcceptable");

        long timeMillis = RestAssured
                .given()
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .time();

        System.out.println("Response time : " + timeMillis + " ms");

        // Glitch.me free instances can sleep when idle - first hit may be slow.
        // 5 seconds is a generous threshold that accommodates a cold start.
        Assert.assertTrue(timeMillis < 5000,
                "FAILED: response time " + timeMillis + " ms exceeds 5000 ms threshold");

        System.out.println("[TEST PASSED] Response time within acceptable range.\n");
    }
}
