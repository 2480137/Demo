# Status Code 200 Validation - REST Assured + TestNG

Maven-based Java project that uses **REST Assured** and **TestNG** to validate
that the `GET /status_codes/200` endpoint of `the-internet.herokuapp.com`
returns HTTP **200 OK**.

## Scenario

Send a **GET** request to:

```
https://the-internet.herokuapp.com/status_codes/200
```

and assert that the response status code is **200**.

## Project Structure

```
StatusCode200ValidationTest/
├── pom.xml                          # Maven dependencies
├── testng.xml                       # TestNG suite file
├── README.md
└── src/
    └── test/
        └── java/
            └── com/
                └── herokuapp/
                    └── tests/
                        └── StatusCode200ValidationTest.java
```

## What the Test Class Does

The `StatusCode200ValidationTest` class contains three test methods:

| # | Method                              | Purpose                                                                   |
|---|-------------------------------------|---------------------------------------------------------------------------|
| 1 | `verifyStatusCodeIs200`             | Sends GET, extracts the response, asserts status is 200 with TestNG.      |
| 2 | `verifyResponseBodyContains200Text` | Bonus - asserts the response body contains the page's confirmation text.  |
| 3 | `verifyStatusCodeWithFluentStyle`   | Bonus - shows the same assertion using REST Assured's fluent matcher API. |

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection (test calls a live page)

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open the project as a Maven project (select `pom.xml`), wait for dependencies
to download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=StatusCode200ValidationTest#verifyStatusCodeIs200
```

## Expected Output

```
[TEST START] verifyStatusCodeIs200
Request URL    : https://the-internet.herokuapp.com/status_codes/200
Status code    : 200
[TEST PASSED] Status code 200 verified successfully.

[TEST START] verifyResponseBodyContains200Text
Body length    : 4xxx chars
[TEST PASSED] Response body content verified.

[TEST START] verifyStatusCodeWithFluentStyle
[TEST PASSED] Fluent style 200 assertion succeeded.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Reports

After execution, reports are generated under:

- `target/surefire-reports/index.html`
- `target/surefire-reports/emailable-report.html`

## Notes

- `the-internet.herokuapp.com` is a public test site for browser/UI/API
  practice. The `/status_codes/{code}` endpoint always returns the requested
  HTTP status code, making it ideal for validation tests.
- No authentication is required.
- If the site is unreachable, all tests will fail with connection errors -
  this is an infrastructure issue rather than a code defect.
