# Status Code 301 Validation - REST Assured + TestNG

Maven-based Java project that uses **REST Assured** and **TestNG** to validate
that the `GET /status_codes/301` endpoint of `the-internet.herokuapp.com`
returns HTTP **301 Moved Permanently**.

## Scenario

Send a **GET** request to:

```
https://the-internet.herokuapp.com/status_codes/301
```

and assert that the response status code is **301**.

## Important - Redirect Handling

REST Assured (and the underlying Apache HttpClient) **follow HTTP redirects
automatically by default**. With redirect-following enabled, a 301 response
would be transparently followed to the redirect target and the test would
observe a final status of **200**, not 301.

To make the 301 visible to the test, this project disables redirect-following
globally in `@BeforeClass`:

```java
RestAssured.config = RestAssuredConfig.config()
        .redirect(RedirectConfig.redirectConfig().followRedirects(false));
```

## Project Structure

```
StatusCode301ValidationTest/
├── pom.xml                          # Maven dependencies
├── testng.xml                       # TestNG suite file
├── README.md
└── src/
    └── test/
        └── java/
            └── com/
                └── herokuapp/
                    └── tests/
                        └── StatusCode301ValidationTest.java
```

## What the Test Class Does

The `StatusCode301ValidationTest` class contains three test methods:

| # | Method                               | Purpose                                                                           |
|---|--------------------------------------|-----------------------------------------------------------------------------------|
| 1 | `verifyStatusCodeIs301`              | Sends GET, extracts the response, asserts status is 301 with TestNG.              |
| 2 | `verifyLocationHeaderIsPresent`      | Bonus - asserts the 301 response carries a non-empty `Location` header (per HTTP).|
| 3 | `verifyStatusCodeWithFluentStyle`    | Bonus - shows the same assertion using REST Assured's fluent matcher API.         |

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open the project as a Maven project (select `pom.xml`), wait for dependencies
to download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=StatusCode301ValidationTest#verifyStatusCodeIs301
```

## Expected Output

```
[TEST START] verifyStatusCodeIs301
Request URL    : https://the-internet.herokuapp.com/status_codes/301
Status code    : 301
Location header: /status_codes
[TEST PASSED] Status code 301 verified successfully.

[TEST START] verifyLocationHeaderIsPresent
Location header: /status_codes
[TEST PASSED] Location header verified.

[TEST START] verifyStatusCodeWithFluentStyle
[TEST PASSED] Fluent style 301 assertion succeeded.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Reports

After execution, reports are generated under:

- `target/surefire-reports/index.html`
- `target/surefire-reports/emailable-report.html`

## Notes

- `the-internet.herokuapp.com/status_codes/{code}` is a public test page
  that always returns the requested HTTP status code, ideal for status-code
  assertion tests.
- No authentication is required.
- A 301 response indicates the resource has been **moved permanently** to a
  new URL. RFC 7231 mandates that the response includes a `Location` header
  with the new URL, which the bonus test verifies.
