package com.herokuapp.tests;

import io.restassured.RestAssured;
import io.restassured.config.RedirectConfig;
import io.restassured.config.RestAssuredConfig;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hands-On 3: Validate the 301 status code in REST Assured.
 *
 * Scenario:
 *  Send a GET request to https://the-internet.herokuapp.com/status_codes/301
 *  using REST Assured and verify that the response status code is 301.
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. GET request sent through RestAssured to
 *     https://the-internet.herokuapp.com/status_codes/301
 *  4. Status code asserted to be 301 using TestNG.
 *
 * IMPORTANT
 *  By default REST Assured (and the underlying Apache HttpClient) automatically
 *  follows HTTP redirects. If left enabled, a 301 response would be transparently
 *  followed to the redirect target and the test would observe a 200 instead.
 *  This test therefore disables redirect-following so the 301 is actually visible.
 */
public class StatusCode301ValidationTest {

    private static final String BASE_URI    = "https://the-internet.herokuapp.com";
    private static final String ENDPOINT    = "/status_codes/301";
    private static final int    EXPECTED_SC = 301;

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI once for the whole class
        RestAssured.baseURI = BASE_URI;

        // Disable redirect-following globally so 3xx responses surface as-is
        RestAssured.config = RestAssuredConfig.config()
                .redirect(RedirectConfig.redirectConfig().followRedirects(false));

        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("            Redirect-following  -> DISABLED");
        System.out.println("=========================================================");
    }

    /**
     * Step 4 - Verify status code 301 using TestNG assertion.
     */
    @Test(priority = 1,
          description = "Verify GET /status_codes/301 returns HTTP 301")
    public void verifyStatusCodeIs301() {

        System.out.println("\n[TEST START] verifyStatusCodeIs301");

        // Step 3 - Send GET request through RestAssured
        Response response = RestAssured
                .given()
                    .header("Accept", "text/html")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int actualStatusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("Status code    : " + actualStatusCode);
        System.out.println("Location header: " + response.getHeader("Location"));

        // Step 4 - TestNG assertion on status code
        Assert.assertEquals(actualStatusCode, EXPECTED_SC,
                "FAILED: expected status code " + EXPECTED_SC + " but got " + actualStatusCode);

        System.out.println("[TEST PASSED] Status code 301 verified successfully.\n");
    }

    /**
     * Bonus: a 301 response is required by HTTP to include a Location header
     * pointing to the new resource. Verify the header is present.
     */
    @Test(priority = 2,
          description = "Verify the 301 response includes a Location header")
    public void verifyLocationHeaderIsPresent() {

        System.out.println("\n[TEST START] verifyLocationHeaderIsPresent");

        Response response = RestAssured
                .given()
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        Assert.assertEquals(response.getStatusCode(), EXPECTED_SC,
                "Pre-condition failed: status code is not 301");

        String location = response.getHeader("Location");
        System.out.println("Location header: " + location);

        Assert.assertNotNull(location,
                "FAILED: 301 response did not include a Location header");
        Assert.assertFalse(location.isEmpty(),
                "FAILED: Location header was empty");

        System.out.println("[TEST PASSED] Location header verified.\n");
    }

    /**
     * Bonus alternative: same assertion using REST Assured's fluent matcher style.
     */
    @Test(priority = 3,
          description = "Verify status 301 using fluent then().statusCode() style")
    public void verifyStatusCodeWithFluentStyle() {

        System.out.println("\n[TEST START] verifyStatusCodeWithFluentStyle");

        RestAssured
                .given()
                .when()
                    .get(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(EXPECTED_SC);

        System.out.println("[TEST PASSED] Fluent style 301 assertion succeeded.\n");
    }
}
