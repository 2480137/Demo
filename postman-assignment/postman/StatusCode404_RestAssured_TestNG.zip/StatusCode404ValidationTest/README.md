# Status Code 404 Validation - REST Assured + TestNG

Maven-based Java project that uses **REST Assured** and **TestNG** to validate
that the `GET /status_codes/404` endpoint of `the-internet.herokuapp.com`
returns HTTP **404 Not Found**.

## Scenario

Send a **GET** request to:

```
https://the-internet.herokuapp.com/status_codes/404
```

and assert that the response status code is **404**.

## Project Structure

```
StatusCode404ValidationTest/
├── pom.xml                          # Maven dependencies
├── testng.xml                       # TestNG suite file
├── README.md
└── src/
    └── test/
        └── java/
            └── com/
                └── herokuapp/
                    └── tests/
                        └── StatusCode404ValidationTest.java
```

## What the Test Class Does

The `StatusCode404ValidationTest` class contains three test methods:

| # | Method                              | Purpose                                                                   |
|---|-------------------------------------|---------------------------------------------------------------------------|
| 1 | `verifyStatusCodeIs404`             | Sends GET, extracts the response, asserts status is 404 with TestNG.      |
| 2 | `verifyResponseBodyContains404Text` | Bonus - asserts the response body contains the page's confirmation text.  |
| 3 | `verifyStatusCodeWithFluentStyle`   | Bonus - shows the same assertion using REST Assured's fluent matcher API. |

## Prerequisites

- Java JDK **11** or higher
- Apache Maven **3.6+**
- Active internet connection

## Dependencies (in pom.xml)

- TestNG `7.8.0`
- REST Assured `5.3.2`
- JSON Path `5.3.2`
- JSON Schema Validator `5.3.2`
- Hamcrest `2.2`

## How to Run

### Option 1 - Maven

```bash
mvn clean test
```

### Option 2 - From IDE

Open the project as a Maven project (select `pom.xml`), wait for dependencies
to download, then right-click `testng.xml` → **Run 'testng.xml'**.

### Option 3 - Run a single test method

```bash
mvn clean test -Dtest=StatusCode404ValidationTest#verifyStatusCodeIs404
```

## Expected Output

```
[TEST START] verifyStatusCodeIs404
Request URL    : https://the-internet.herokuapp.com/status_codes/404
Status code    : 404
[TEST PASSED] Status code 404 verified successfully.

[TEST START] verifyResponseBodyContains404Text
Body length    : 4xxx chars
[TEST PASSED] Response body content verified.

[TEST START] verifyStatusCodeWithFluentStyle
[TEST PASSED] Fluent style 404 assertion succeeded.

===============================================
Total tests run: 3, Passes: 3, Failures: 0
===============================================
```

## Reports

After execution, reports are generated under:

- `target/surefire-reports/index.html`
- `target/surefire-reports/emailable-report.html`

## Notes

- `the-internet.herokuapp.com/status_codes/{code}` is a public test page
  that always returns the requested HTTP status code, ideal for status-code
  assertion tests.
- No authentication is required.
- A **404 Not Found** response indicates the requested resource does not
  exist on the server. The page still renders an HTML body with the
  confirmation text, which the bonus test asserts.
