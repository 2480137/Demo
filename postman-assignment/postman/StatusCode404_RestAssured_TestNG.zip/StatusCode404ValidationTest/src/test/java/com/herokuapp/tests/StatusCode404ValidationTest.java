package com.herokuapp.tests;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

/**
 * Hands-On 4: Validate the 404 status code in REST Assured.
 *
 * Scenario:
 *  Send a GET request to https://the-internet.herokuapp.com/status_codes/404
 *  using REST Assured and verify that the response status code is 404.
 *
 * Steps covered:
 *  1. Maven project with TestNG and RestAssured dependencies (pom.xml).
 *  2. Test class created in the rest-assured framework (this file).
 *  3. GET request sent through RestAssured to
 *     https://the-internet.herokuapp.com/status_codes/404
 *  4. Status code asserted to be 404 using TestNG.
 */
public class StatusCode404ValidationTest {

    private static final String BASE_URI    = "https://the-internet.herokuapp.com";
    private static final String ENDPOINT    = "/status_codes/404";
    private static final int    EXPECTED_SC = 404;

    @BeforeClass
    public void setUp() {
        // Configure RestAssured base URI once for the whole class
        RestAssured.baseURI = BASE_URI;
        System.out.println("=========================================================");
        System.out.println("Test setup: Base URI configured -> " + BASE_URI);
        System.out.println("=========================================================");
    }

    /**
     * Step 4 - Verify status code 404 using TestNG assertion.
     */
    @Test(priority = 1,
          description = "Verify GET /status_codes/404 returns HTTP 404")
    public void verifyStatusCodeIs404() {

        System.out.println("\n[TEST START] verifyStatusCodeIs404");

        // Step 3 - Send GET request through RestAssured
        Response response = RestAssured
                .given()
                    .header("Accept", "text/html")
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        int actualStatusCode = response.getStatusCode();

        System.out.println("Request URL    : " + BASE_URI + ENDPOINT);
        System.out.println("Response time  : " + response.getTime() + " ms");
        System.out.println("Status code    : " + actualStatusCode);
        System.out.println("Content-Type   : " + response.getContentType());

        // Step 4 - TestNG assertion on status code
        Assert.assertEquals(actualStatusCode, EXPECTED_SC,
                "FAILED: expected status code " + EXPECTED_SC + " but got " + actualStatusCode);

        System.out.println("[TEST PASSED] Status code 404 verified successfully.\n");
    }

    /**
     * Bonus: validate the response body contains the expected page text.
     * the-internet.herokuapp.com renders a small HTML page that confirms
     * the returned status code.
     */
    @Test(priority = 2,
          description = "Verify the response body contains the 404 confirmation text")
    public void verifyResponseBodyContains404Text() {

        System.out.println("\n[TEST START] verifyResponseBodyContains404Text");

        Response response = RestAssured
                .given()
                .when()
                    .get(ENDPOINT)
                .then()
                    .extract()
                    .response();

        // Pre-condition - status must still be 404
        Assert.assertEquals(response.getStatusCode(), EXPECTED_SC,
                "Pre-condition failed: status code is not 404");

        String body = response.getBody().asString();
        System.out.println("Body length    : " + body.length() + " chars");

        // Page contains text such as 'This page returned a 404 status code'
        Assert.assertTrue(body.contains("404 status code")
                          || body.contains("Status Codes"),
                "FAILED: response body does not contain expected confirmation text");

        System.out.println("[TEST PASSED] Response body content verified.\n");
    }

    /**
     * Bonus alternative: same assertion using REST Assured's fluent matcher style.
     * Demonstrates the more concise idiom typically used in real test code.
     */
    @Test(priority = 3,
          description = "Verify status 404 using fluent then().statusCode() style")
    public void verifyStatusCodeWithFluentStyle() {

        System.out.println("\n[TEST START] verifyStatusCodeWithFluentStyle");

        RestAssured
                .given()
                .when()
                    .get(ENDPOINT)
                .then()
                    .assertThat()
                    .statusCode(EXPECTED_SC);

        System.out.println("[TEST PASSED] Fluent style 404 assertion succeeded.\n");
    }
}
